
export interface GameRule {
  id: string;
  name: string;
  description: string;
  defaultValue?: string;
  options?: string[];
}

export interface Game {
  id: string;
  name: string;
  logo: string;
  genre: string;
  platforms: string[];
  rules?: GameRule[];
  defaultRules?: string;
}

export interface Platform {
  id: string;
  name: string;
  logo: string;
}

export interface Genre {
  id: string;
  name: string;
  icon: string;
}

export const GENRES: Genre[] = [
  { id: 'fighting', name: 'Combat', icon: '🥊' },
  { id: 'fps', name: 'FPS', icon: '🎯' },
  { id: 'sports', name: 'Sports', icon: '⚽' },
  { id: 'racing', name: 'Course', icon: '🏎️' },
  { id: 'party', name: 'Party', icon: '🎉' },
  { id: 'moba', name: 'MOBA', icon: '🏰' },
  { id: 'strategy', name: 'Stratégie', icon: '♟️' },
  { id: 'other', name: 'Autre', icon: '🎮' }
];

export const PLATFORMS: Platform[] = [
  {
    id: 'ps5',
    name: 'PlayStation 5',
    logo: 'https://seeklogo.com/images/P/playstation-5-logo-99C5082B4F-seeklogo.com.png'
  },
  {
    id: 'ps4',
    name: 'PlayStation 4',
    logo: 'https://www.wallpaperbetter.com/wallpaper/636/270/540/playstation-4-logo-sony-1080P-wallpaper.jpg'
  },
  {
    id: 'xbox',
    name: 'Xbox Series X/S',
    logo: 'https://www.citypng.com/public/uploads/preview/black-xbox-series-x-logo-70175169479043431m4nfad3l.png'
  },
  {
    id: 'pc',
    name: 'PC',
    logo: 'https://cdn-icons-png.flaticon.com/512/9379/9379111.png'
  },
  {
    id: 'switch',
    name: 'Nintendo Switch',
    logo: 'https://logos-world.net/wp-content/uploads/2021/09/Nintendo-Switch-Logo.png'
  }
];

export const GAMES: Game[] = [
  // Sports
  {
    id: 'eafc25',
    name: 'EA FC 25',
    logo: 'https://gmedia.playstation.com/is/image/SIEPDC/fc-25-logo-dark-01-en-04jul24?$native$',
    genre: 'sports',
    platforms: ['ps5', 'ps4', 'xbox'],
    defaultRules: '1v1 Ultimate Team, 6 minutes par mi-temps'
  },
  {
    id: 'nba2k25',
    name: 'NBA 2K25',
    logo: 'https://cdn.wikimg.net/en/strategywiki/images/3/35/NBA_2K25_logo.png',
    genre: 'sports',
    platforms: ['ps5', 'ps4', 'xbox'],
    defaultRules: '1v1 MyTeam, 4 quart-temps de 5 minutes'
  },
  
  // FPS
  {
    id: 'codmw3',
    name: 'Call of Duty: Modern Warfare III',
    logo: 'https://seeklogo.com/images/C/call-of-duty-modern-warfare-ii-logo-28DD453EFD-seeklogo.com.png',
    genre: 'fps',
    platforms: ['ps5', 'ps4', 'xbox', 'pc'],
    defaultRules: 'Duel 1v1, mode privé, armes au choix'
  },
  {
    id: 'r6siege',
    name: 'Rainbow Six: Siege',
    logo: 'https://toppng.com/uploads/preview/rainbow-six-siege-logo-png-graphics-11562886231zjcchuppwh.png',
    genre: 'fps',
    platforms: ['xbox', 'pc'],
    defaultRules: '1v1 Custom game, Best of 3 rounds'
  },
  
  // Fighting
  {
    id: 'tekken8',
    name: 'Tekken 8',
    logo: 'https://i.ytimg.com/vi/Vz8nUmX63c0/maxresdefault.jpg',
    genre: 'fighting',
    platforms: ['ps5', 'ps4'],
    defaultRules: 'Best of 3, tous les personnages autorisés'
  },
  {
    id: 'dbfz',
    name: 'Dragon Ball FighterZ',
    logo: 'https://www.pngplay.com/wp-content/uploads/10/Dragon-Ball-FighterZ-Logo-PNG-Background.png',
    genre: 'fighting',
    platforms: ['ps4', 'switch', 'xbox'],
    defaultRules: 'Best of 3, équipes de 3 personnages'
  },
  {
    id: 'sf6',
    name: 'Street Fighter 6',
    logo: 'https://www.streetfighter.com/6/assets/images/index/logo_text.png',
    genre: 'fighting',
    platforms: ['ps5', 'ps4', 'xbox', 'pc'],
    defaultRules: 'Ranked match, FT3'
  },
  {
    id: 'mk1',
    name: 'Mortal Kombat 1',
    logo: 'https://i.pinimg.com/originals/df/15/4d/df154d8a4e20ca1d9b454d7c9955591a.png',
    genre: 'fighting',
    platforms: ['ps5', 'ps4', 'xbox', 'pc'],
    defaultRules: 'Best of 3, Kameo fighters autorisés'
  },
  
  // Racing
  {
    id: 'gt7',
    name: 'Gran Turismo 7',
    logo: 'https://seeklogo.com/images/G/gran-turismo-7-logo-D5418FE004-seeklogo.com.png',
    genre: 'racing',
    platforms: ['ps5', 'ps4'],
    defaultRules: 'Course de 5 tours, voitures de même catégorie'
  },
  {
    id: 'mariokart8',
    name: 'Mario Kart 8 Deluxe',
    logo: 'https://i.ytimg.com/vi/as7zG7Gu0ew/maxresdefault.jpg',
    genre: 'racing',
    platforms: ['switch'],
    rules: [
      {
        id: 'rounds',
        name: 'Nombre de courses',
        description: 'Choisir le nombre de courses',
        defaultValue: '3',
        options: ['1', '3', '5']
      },
      {
        id: 'speed',
        name: 'Vitesse',
        description: 'Classe de vitesse',
        defaultValue: '150cc',
        options: ['150cc', '200cc']
      },
      {
        id: 'items',
        name: 'Objets',
        description: 'Activer ou désactiver les objets',
        defaultValue: 'ON',
        options: ['ON', 'OFF']
      }
    ],
    defaultRules: 'Best of 3 courses, 150cc, Objets activés'
  },
  
  // Nintendo Switch Fighting
  {
    id: 'smashbros',
    name: 'Super Smash Bros. Ultimate',
    logo: 'https://i.ytimg.com/vi/ImZT-u7StQk/maxresdefault.jpg',
    genre: 'fighting',
    platforms: ['switch'],
    rules: [
      {
        id: 'format',
        name: 'Format',
        description: 'Type de combat',
        defaultValue: '1v1',
        options: ['1v1']
      },
      {
        id: 'rounds',
        name: 'Nombre de manches',
        description: 'Best of combien',
        defaultValue: '3',
        options: ['1', '3', '5']
      },
      {
        id: 'stocks',
        name: 'Stocks',
        description: 'Nombre de vies',
        defaultValue: '3',
        options: ['2', '3', '4']
      },
      {
        id: 'time',
        name: 'Temps',
        description: 'Durée du combat',
        defaultValue: '7',
        options: ['6', '7', '8']
      },
      {
        id: 'items',
        name: 'Objets',
        description: 'Activer les objets',
        defaultValue: 'OFF',
        options: ['ON', 'OFF']
      },
      {
        id: 'stages',
        name: 'Stages',
        description: 'Types de stages autorisés',
        defaultValue: 'Legal',
        options: ['Legal', 'Final Destination', 'Battlefield']
      }
    ],
    defaultRules: '1v1, Best of 3, 3 stocks, 7 minutes, Objets désactivés, Stages légaux'
  },
  
  // Other games
  {
    id: 'fortnite',
    name: 'Fortnite',
    logo: 'https://pngimg.com/d/fortnite_PNG97.png',
    genre: 'other',
    platforms: ['ps5', 'ps4', 'xbox', 'pc', 'switch'],
    defaultRules: '1v1 Creative, build fight'
  },
  {
    id: 'ufc5',
    name: 'UFC 5',
    logo: 'https://pngimg.com/d/ufc_PNG63.png',
    genre: 'fighting',
    platforms: ['ps5', 'xbox'],
    defaultRules: 'Combat de 3 rounds, toutes catégories'
  },
  {
    id: 'naruto4',
    name: 'Naruto Ultimate Ninja Storm 4',
    logo: 'https://i.pinimg.com/originals/ae/ff/10/aeff10efc79a63d67392bd6b26b5c6c6.png',
    genre: 'fighting',
    platforms: ['ps4', 'xbox', 'pc'],
    defaultRules: 'Best of 3, tous les personnages autorisés'
  },
  {
    id: 'clashroyale',
    name: 'Clash Royale',
    logo: 'https://www.pngarts.com/files/13/Clash-Royale-Logo-Transparent-Image.png',
    genre: 'strategy',
    platforms: ['other'],
    defaultRules: 'Best of 3, deck au choix'
  }
];

export const BET_STATUS_LABELS = {
  OPEN: 'Ouvert',
  ACTIVE: 'En cours',
  PENDING_RESULT: 'Résultat en attente',
  COMPLETED: 'Terminé',
  CANCELLED: 'Annulé'
};

export const getGameById = (id: string): Game | undefined => 
  GAMES.find(game => game.id === id);

export const getPlatformById = (id: string): Platform | undefined => 
  PLATFORMS.find(platform => platform.id === id);

export const getGenreById = (id: string): Genre | undefined => 
  GENRES.find(genre => genre.id === id);

export const getGamesByGenre = (genreId: string): Game[] => 
  GAMES.filter(game => game.genre === genreId);

export const getGamesByPlatform = (platformId: string): Game[] => 
  GAMES.filter(game => game.platforms.includes(platformId));

export const getCompatiblePlatforms = (gameId: string): Platform[] => {
  const game = getGameById(gameId);
  if (!game) return [];
  return PLATFORMS.filter(platform => game.platforms.includes(platform.id));
};

export const getGameRules = (gameId: string): GameRule[] => {
  const game = getGameById(gameId);
  return game?.rules || [];
};

export const formatGameRules = (gameId: string, rulesData?: any): string => {
  const game = getGameById(gameId);
  if (!game) return '';
  
  if (!rulesData && game.defaultRules) {
    return game.defaultRules;
  }
  
  if (!game.rules || !rulesData) {
    return game.defaultRules || '';
  }
  
  const ruleStrings = game.rules.map(rule => {
    const value = rulesData[rule.id] || rule.defaultValue;
    return `${rule.name}: ${value}`;
  });
  
  return ruleStrings.join(', ');
};
