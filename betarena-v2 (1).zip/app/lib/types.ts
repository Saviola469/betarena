
import { User, Bet, Transaction, Message, Screenshot, Tournament, TournamentParticipant, TournamentMatch, Conversation, DirectMessage, PlayerStats, Challenge, Clan, ClanMember, ClanInvitation, ClanMessage, ClanMatch } from '@prisma/client';

export interface ExtendedUser extends User {
  betsCreated: Bet[];
  betsJoined: Bet[];
  transactions: Transaction[];
  messages: Message[];
}

export interface ExtendedBet extends Bet {
  creator: {
    id: string;
    username: string;
    avatar: string | null;
    rank: number;
  };
  opponent?: {
    id: string;
    username: string;
    avatar: string | null;
    rank: number;
  } | null;
  messages: (Message & {
    user: {
      id: string;
      username: string;
      avatar: string | null;
    };
  })[];
  screenshots: Screenshot[];
}

export interface WalletData {
  total: number;
  escrow: number;
  available: number;
}

export interface LeaderboardUser {
  id: string;
  username: string;
  avatar: string | null;
  rank: number;
  gamesPlayed: number;
  gamesWon: number;
  totalEarnings: number;
  winRate: number;
}

export type BetStatus = 'OPEN' | 'ACTIVE' | 'PENDING_RESULT' | 'COMPLETED' | 'CANCELLED';
export type TransactionType = 'DEPOSIT' | 'WITHDRAWAL' | 'BET_ESCROW' | 'BET_PAYOUT';
export type TransactionStatus = 'PENDING' | 'COMPLETED' | 'FAILED';

// Tournament types
export type TournamentType = 'SINGLE_ELIMINATION' | 'DOUBLE_ELIMINATION' | 'ROUND_ROBIN';
export type TournamentStatus = 'OPEN' | 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
export type TournamentMatchStatus = 'PENDING' | 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
export type TournamentFormat = 'SINGLE_ELIMINATION' | 'DOUBLE_ELIMINATION' | 'ROUND_ROBIN' | 'BO1' | 'BO3' | 'BO5';

export interface ExtendedTournament extends Tournament {
  creator: {
    id: string;
    username: string;
    avatar: string | null;
    rank: number;
  };
  participants: (TournamentParticipant & {
    user: {
      id: string;
      username: string;
      avatar: string | null;
      rank: number;
    };
  })[];
  matches: (TournamentMatch & {
    playerA?: {
      id: string;
      username: string;
      avatar: string | null;
    } | null;
    playerB?: {
      id: string;
      username: string;
      avatar: string | null;
    } | null;
    winner?: {
      id: string;
      username: string;
      avatar: string | null;
    } | null;
  })[];
}

export interface ExtendedTournamentParticipant extends TournamentParticipant {
  user: {
    id: string;
    username: string;
    avatar: string | null;
    rank: number;
  };
  tournament: {
    id: string;
    name: string;
    game: string;
    platform: string;
  };
}

export interface ExtendedTournamentMatch extends TournamentMatch {
  tournament: {
    id: string;
    name: string;
    game: string;
    platform: string;
  };
  playerA?: {
    id: string;
    username: string;
    avatar: string | null;
  } | null;
  playerB?: {
    id: string;
    username: string;
    avatar: string | null;
  } | null;
  winner?: {
    id: string;
    username: string;
    avatar: string | null;
  } | null;
}

// Messaging types
export interface ExtendedConversation extends Conversation {
  userA: {
    id: string;
    username: string;
    avatar: string | null;
  };
  userB: {
    id: string;
    username: string;
    avatar: string | null;
  };
  otherUser?: {
    id: string;
    username: string;
    avatar: string | null;
  };
  messages: (DirectMessage & {
    sender: {
      id: string;
      username: string;
      avatar: string | null;
    };
  })[];
  lastMessageObject?: DirectMessage | null;
}

export interface ExtendedDirectMessage extends DirectMessage {
  sender: {
    id: string;
    username: string;
    avatar: string | null;
  };
  conversation: {
    id: string;
    userAId: string;
    userBId: string;
  };
}

// Leaderboard types
export interface ExtendedLeaderboardUser extends User {
  playerStats: PlayerStats[];
  globalRank?: number;
  gameSpecificStats?: {
    wins: number;
    losses: number;
    tournamentWins: number;
    score: number;
    totalEarnings: number;
    winRate: number;
    gamesPlayed: number;
    lastPlayed?: Date;
  };
}

export interface LeaderboardFilters {
  game?: string;
  platform?: string;
  page?: number;
  limit?: number;
  search?: string;
}

// Player stats types
export interface ExtendedPlayerStats extends PlayerStats {
  user: {
    id: string;
    username: string;
    avatar: string | null;
    country: string | null;
  };
  rank?: number;
  winRate: number;
  gamesPlayed: number;
}

// Challenge types
export type ChallengeStatus = 'PENDING' | 'ACCEPTED' | 'DECLINED' | 'EXPIRED' | 'COMPLETED';

export interface ExtendedChallenge extends Challenge {
  sender: {
    id: string;
    username: string;
    avatar: string | null;
    country: string | null;
  };
  receiver: {
    id: string;
    username: string;
    avatar: string | null;
    country: string | null;
  };
}

export interface ChallengeFilters {
  status?: ChallengeStatus;
  game?: string;
  platform?: string;
  page?: number;
  limit?: number;
}

// Public profile types
export interface PublicProfile {
  id: string;
  username: string;
  avatar: string | null;
  country: string | null;
  rank: number;
  score: number;
  wins: number;
  losses: number;
  tournamentWins: number;
  winRate: number;
  gamesPlayed: number;
  createdAt: Date;
  isProfilePublic: boolean;
  playerStats: ExtendedPlayerStats[];
  recentGames: {
    game: string;
    platform: string;
    lastPlayed: Date;
    wins: number;
    losses: number;
    winRate: number;
  }[];
}

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      email: string;
      username: string;
      avatar?: string | null;
    };
  }

  interface User {
    username: string;
    avatar?: string | null;
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    username: string;
    avatar?: string | null;
  }
}

// Clan types
export type ClanRole = 'CAPTAIN' | 'CO_LEADER' | 'MEMBER';
export type ClanType = 'PUBLIC' | 'PRIVATE';
export type InvitationStatus = 'PENDING' | 'ACCEPTED' | 'DECLINED' | 'EXPIRED';
export type MessageType = 'TEXT' | 'SYSTEM' | 'MATCH_RESULT';
export type ClanMatchType = 'CHALLENGE' | 'TOURNAMENT' | 'FRIENDLY';
export type ClanMatchStatus = 'PENDING' | 'ACCEPTED' | 'ACTIVE' | 'COMPLETED' | 'CANCELLED';

export interface ExtendedClan extends Clan {
  creator: {
    id: string;
    username: string;
    avatar: string | null;
  };
  members: (User & {
    clanMembership?: ClanMember;
  })[];
  memberships: (ClanMember & {
    user: {
      id: string;
      username: string;
      avatar: string | null;
      rank: number;
    };
  })[];
  invitations: (ClanInvitation & {
    sender: {
      id: string;
      username: string;
      avatar: string | null;
    };
    receiver: {
      id: string;
      username: string;
      avatar: string | null;
    };
  })[];
  messages: (ClanMessage & {
    sender: {
      id: string;
      username: string;
      avatar: string | null;
    };
  })[];
  matchesA: ExtendedClanMatch[];
  matchesB: ExtendedClanMatch[];
  matchesWon: ExtendedClanMatch[];
  // Statistiques calculées
  winRate: number;
  memberCount: number;
  recentActivity: {
    type: 'match' | 'member_joined' | 'member_left' | 'message';
    description: string;
    timestamp: Date;
  }[];
}

export interface ExtendedClanMember extends ClanMember {
  user: {
    id: string;
    username: string;
    avatar: string | null;
    rank: number;
    country: string | null;
  };
  clan: {
    id: string;
    name: string;
    tag: string;
    logo: string | null;
    platform: string;
  };
  winRate: number;
  gamesPlayed: number;
}

export interface ExtendedClanInvitation extends ClanInvitation {
  clan: {
    id: string;
    name: string;
    tag: string;
    logo: string | null;
    platform: string;
    clanType: ClanType;
    memberCount: number;
  };
  sender: {
    id: string;
    username: string;
    avatar: string | null;
    clanRole: ClanRole | null;
  };
  receiver: {
    id: string;
    username: string;
    avatar: string | null;
  };
}

export interface ExtendedClanMessage extends ClanMessage {
  sender: {
    id: string;
    username: string;
    avatar: string | null;
    clanRole: ClanRole | null;
  };
  clan: {
    id: string;
    name: string;
    tag: string;
  };
}

export interface ExtendedClanMatch extends ClanMatch {
  clanA: {
    id: string;
    name: string;
    tag: string;
    logo: string | null;
    platform: string;
  };
  clanB: {
    id: string;
    name: string;
    tag: string;
    logo: string | null;
    platform: string;
  };
  winner?: {
    id: string;
    name: string;
    tag: string;
    logo: string | null;
  } | null;
  playerA?: {
    id: string;
    username: string;
    avatar: string | null;
  } | null;
  playerB?: {
    id: string;
    username: string;
    avatar: string | null;
  } | null;
}

// Clan filters and search
export interface ClanFilters {
  platform?: string;
  clanType?: ClanType;
  search?: string;
  minMembers?: number;
  maxMembers?: number;
  sortBy?: 'name' | 'members' | 'winRate' | 'totalEarnings' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface ClanLeaderboardEntry {
  id: string;
  name: string;
  tag: string;
  logo: string | null;
  platform: string;
  memberCount: number;
  totalWins: number;
  totalLosses: number;
  totalMatches: number;
  winRate: number;
  totalEarnings: number;
  rank: number;
  creator: {
    id: string;
    username: string;
    avatar: string | null;
  };
}

export interface ClanMatchFilters {
  clanId?: string;
  game?: string;
  platform?: string;
  matchType?: ClanMatchType;
  status?: ClanMatchStatus;
  page?: number;
  limit?: number;
}

export interface ClanInvitationFilters {
  clanId?: string;
  receiverId?: string;
  status?: InvitationStatus;
  page?: number;
  limit?: number;
}

export interface ClanStats {
  totalClans: number;
  totalMatches: number;
  totalMembers: number;
  averageWinRate: number;
  mostActiveClans: {
    id: string;
    name: string;
    tag: string;
    logo: string | null;
    totalMatches: number;
  }[];
  topEarningClans: {
    id: string;
    name: string;
    tag: string;
    logo: string | null;
    totalEarnings: number;
  }[];
}
