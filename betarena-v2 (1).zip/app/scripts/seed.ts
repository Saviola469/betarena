
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Début du seeding...');

  // Créer le compte de démonstration
  const hashedPassword = await bcrypt.hash('johndoe123', 12);
  
  const demoUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      username: 'JohnDoe',
      password: hashedPassword,
      avatar: 'https://cdn.abacus.ai/images/da82a881-e5e0-4c08-b191-70cd501da1e1.png',
      rank: 1500,
      walletTotal: 500.0,
      walletEscrow: 0.0,
      gamesPlayed: 25,
      gamesWon: 18,
      // Nouveaux champs pour le classement
      wins: 28,
      losses: 7,
      tournamentWins: 3,
      score: 107, // (28 × 3) + (3 × 10) - (7 × 1) = 84 + 30 - 7 = 107
      country: 'France',
      isProfilePublic: true,
    },
  });

  // Créer quelques utilisateurs de test
  const users = await Promise.all([
    prisma.user.upsert({
      where: { email: 'gamer1@test.com' },
      update: {},
      create: {
        email: 'gamer1@test.com',
        username: 'ProGamer88',
        password: hashedPassword,
        avatar: 'https://cdn.abacus.ai/images/da82a881-e5e0-4c08-b191-70cd501da1e1.png',
        rank: 1200,
        walletTotal: 250.0,
        walletEscrow: 0.0,
        gamesPlayed: 15,
        gamesWon: 10,
        // Nouveaux champs pour le classement
        wins: 22,
        losses: 8,
        tournamentWins: 2,
        score: 78, // (22 × 3) + (2 × 10) - (8 × 1) = 66 + 20 - 8 = 78
        country: 'Canada',
        isProfilePublic: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'player2@test.com' },
      update: {},
      create: {
        email: 'player2@test.com',
        username: 'GameMaster',
        password: hashedPassword,
        avatar: 'https://cdn.abacus.ai/images/da82a881-e5e0-4c08-b191-70cd501da1e1.png',
        rank: 1800,
        walletTotal: 750.0,
        walletEscrow: 0.0,
        gamesPlayed: 30,
        gamesWon: 22,
        // Nouveaux champs pour le classement
        wins: 35,
        losses: 5,
        tournamentWins: 5,
        score: 150, // (35 × 3) + (5 × 10) - (5 × 1) = 105 + 50 - 5 = 150
        country: 'Belgique',
        isProfilePublic: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'challenger@test.com' },
      update: {},
      create: {
        email: 'challenger@test.com',
        username: 'Challenger',
        password: hashedPassword,
        avatar: 'https://cdn.abacus.ai/images/da82a881-e5e0-4c08-b191-70cd501da1e1.png',
        rank: 1000,
        walletTotal: 100.0,
        walletEscrow: 0.0,
        gamesPlayed: 8,
        gamesWon: 5,
        // Nouveaux champs pour le classement
        wins: 12,
        losses: 15,
        tournamentWins: 1,
        score: 31, // (12 × 3) + (1 × 10) - (15 × 1) = 36 + 10 - 15 = 31
        country: 'Suisse',
        isProfilePublic: true,
      },
    }),
  ]);

  // Créer des paris de test avec les nouveaux jeux
  const bets = await Promise.all([
    // Sports
    prisma.bet.create({
      data: {
        game: 'eafc25',
        platform: 'ps5',
        amount: 25.0,
        rules: '1v1 Ultimate Team, 6 minutes par mi-temps',
        status: 'OPEN',
        creatorId: users[0].id,
      },
    }),
    prisma.bet.create({
      data: {
        game: 'nba2k25',
        platform: 'xbox',
        amount: 30.0,
        rules: '1v1 MyTeam, 4 quart-temps de 5 minutes',
        status: 'OPEN',
        creatorId: users[1].id,
      },
    }),
    // FPS
    prisma.bet.create({
      data: {
        game: 'codmw3',
        platform: 'pc',
        amount: 50.0,
        rules: 'Duel 1v1, mode privé, armes au choix',
        status: 'OPEN',
        creatorId: users[2].id,
      },
    }),
    prisma.bet.create({
      data: {
        game: 'r6siege',
        platform: 'pc',
        amount: 40.0,
        rules: '1v1 Custom game, Best of 3 rounds',
        status: 'OPEN',
        creatorId: demoUser.id,
      },
    }),
    // Fighting
    prisma.bet.create({
      data: {
        game: 'tekken8',
        platform: 'ps5',
        amount: 15.0,
        rules: 'Best of 3, tous les personnages autorisés',
        status: 'OPEN',
        creatorId: users[0].id,
      },
    }),
    prisma.bet.create({
      data: {
        game: 'dbfz',
        platform: 'switch',
        amount: 20.0,
        rules: 'Best of 3, équipes de 3 personnages',
        status: 'OPEN',
        creatorId: users[1].id,
      },
    }),
    prisma.bet.create({
      data: {
        game: 'sf6',
        platform: 'ps5',
        amount: 35.0,
        rules: 'Ranked match, FT3',
        status: 'OPEN',
        creatorId: users[2].id,
      },
    }),
    // Nintendo Switch exclusives
    prisma.bet.create({
      data: {
        game: 'mariokart8',
        platform: 'switch',
        amount: 25.0,
        rules: 'Best of 3 courses, 150cc, Objets activés',
        status: 'OPEN',
        creatorId: demoUser.id,
      },
    }),
    prisma.bet.create({
      data: {
        game: 'smashbros',
        platform: 'switch',
        amount: 30.0,
        rules: '1v1, Best of 3, 3 stocks, 7 minutes, Objets désactivés, Stages légaux',
        status: 'OPEN',
        creatorId: users[0].id,
      },
    }),
    // Racing
    prisma.bet.create({
      data: {
        game: 'gt7',
        platform: 'ps5',
        amount: 45.0,
        rules: 'Course de 5 tours, voitures de même catégorie',
        status: 'OPEN',
        creatorId: users[1].id,
      },
    }),
    // Other
    prisma.bet.create({
      data: {
        game: 'fortnite',
        platform: 'pc',
        amount: 35.0,
        rules: '1v1 Creative, build fight',
        status: 'OPEN',
        creatorId: users[2].id,
      },
    }),
    prisma.bet.create({
      data: {
        game: 'ufc5',
        platform: 'xbox',
        amount: 40.0,
        rules: 'Combat de 3 rounds, toutes catégories',
        status: 'OPEN',
        creatorId: demoUser.id,
      },
    }),
  ]);

  // Créer quelques transactions de test
  await Promise.all([
    prisma.transaction.create({
      data: {
        userId: demoUser.id,
        type: 'DEPOSIT',
        amount: 500.0,
        status: 'COMPLETED',
      },
    }),
    prisma.transaction.create({
      data: {
        userId: users[0].id,
        type: 'DEPOSIT',
        amount: 250.0,
        status: 'COMPLETED',
      },
    }),
    prisma.transaction.create({
      data: {
        userId: users[1].id,
        type: 'DEPOSIT',
        amount: 750.0,
        status: 'COMPLETED',
      },
    }),
    prisma.transaction.create({
      data: {
        userId: users[2].id,
        type: 'DEPOSIT',
        amount: 100.0,
        status: 'COMPLETED',
      },
    }),
  ]);

  // Créer des tournois de test
  const tournaments = await Promise.all([
    prisma.tournament.create({
      data: {
        name: 'Tournoi EA FC 25 - Élimination Simple',
        game: 'eafc25',
        platform: 'ps5',
        maxParticipants: 8,
        entryFee: 10.0,
        format: 'BO1',
        tournamentType: 'SINGLE_ELIMINATION',
        status: 'OPEN',
        isPrivate: false,
        creatorId: demoUser.id,
      },
    }),
    prisma.tournament.create({
      data: {
        name: 'Super Smash Bros Ultimate Championship',
        game: 'smashbros',
        platform: 'switch',
        maxParticipants: 16,
        entryFee: 15.0,
        format: 'BO3',
        tournamentType: 'DOUBLE_ELIMINATION',
        status: 'OPEN',
        isPrivate: false,
        creatorId: users[0].id,
      },
    }),
    prisma.tournament.create({
      data: {
        name: 'Call of Duty MW3 - Tournoi Privé',
        game: 'codmw3',
        platform: 'pc',
        maxParticipants: 4,
        entryFee: 25.0,
        format: 'BO3',
        tournamentType: 'SINGLE_ELIMINATION',
        status: 'OPEN',
        isPrivate: true,
        creatorId: users[1].id,
      },
    }),
    prisma.tournament.create({
      data: {
        name: 'NBA 2K25 League',
        game: 'nba2k25',
        platform: 'xbox',
        maxParticipants: 6,
        entryFee: 20.0,
        format: 'BO1',
        tournamentType: 'ROUND_ROBIN',
        status: 'ACTIVE',
        isPrivate: false,
        creatorId: users[2].id,
      },
    }),
    prisma.tournament.create({
      data: {
        name: 'Rainbow Six Siege Pro Series',
        game: 'r6siege',
        platform: 'pc',
        maxParticipants: 8,
        entryFee: 30.0,
        format: 'BO3',
        tournamentType: 'DOUBLE_ELIMINATION',
        status: 'COMPLETED',
        isPrivate: false,
        creatorId: demoUser.id,
      },
    }),
  ]);

  // Ajouter des participants aux tournois
  const tournamentParticipants = await Promise.all([
    // Tournoi EA FC 25
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[0].id,
        userId: demoUser.id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[0].id,
        userId: users[0].id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[0].id,
        userId: users[1].id,
      },
    }),
    // Tournoi Smash Bros
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[1].id,
        userId: users[0].id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[1].id,
        userId: users[1].id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[1].id,
        userId: users[2].id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[1].id,
        userId: demoUser.id,
      },
    }),
    // Tournoi NBA 2K25 (actif)
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[3].id,
        userId: users[2].id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[3].id,
        userId: demoUser.id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[3].id,
        userId: users[0].id,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[3].id,
        userId: users[1].id,
      },
    }),
    // Tournoi R6 Siege (terminé)
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[4].id,
        userId: demoUser.id,
        eliminated: false,
        placement: 1,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[4].id,
        userId: users[0].id,
        eliminated: true,
        placement: 2,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[4].id,
        userId: users[1].id,
        eliminated: true,
        placement: 3,
      },
    }),
    prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournaments[4].id,
        userId: users[2].id,
        eliminated: true,
        placement: 4,
      },
    }),
  ]);

  // Créer quelques matches de tournoi
  const tournamentMatches = await Promise.all([
    // Matches pour le tournoi NBA 2K25 (actif)
    prisma.tournamentMatch.create({
      data: {
        tournamentId: tournaments[3].id,
        round: 1,
        playerAId: users[2].id,
        playerBId: demoUser.id,
        winnerId: demoUser.id,
        status: 'COMPLETED',
      },
    }),
    prisma.tournamentMatch.create({
      data: {
        tournamentId: tournaments[3].id,
        round: 1,
        playerAId: users[0].id,
        playerBId: users[1].id,
        status: 'ACTIVE',
      },
    }),
    // Matches pour le tournoi R6 Siege (terminé)
    prisma.tournamentMatch.create({
      data: {
        tournamentId: tournaments[4].id,
        round: 1,
        playerAId: demoUser.id,
        playerBId: users[0].id,
        winnerId: demoUser.id,
        status: 'COMPLETED',
      },
    }),
    prisma.tournamentMatch.create({
      data: {
        tournamentId: tournaments[4].id,
        round: 1,
        playerAId: users[1].id,
        playerBId: users[2].id,
        winnerId: users[1].id,
        status: 'COMPLETED',
      },
    }),
    prisma.tournamentMatch.create({
      data: {
        tournamentId: tournaments[4].id,
        round: 2,
        playerAId: demoUser.id,
        playerBId: users[1].id,
        winnerId: demoUser.id,
        status: 'COMPLETED',
      },
    }),
  ]);

  // Créer des conversations entre utilisateurs
  const conversations = await Promise.all([
    prisma.conversation.upsert({
      where: {
        userAId_userBId: {
          userAId: demoUser.id,
          userBId: users[0].id,
        },
      },
      update: {
        lastMessage: 'Salut ! Prêt pour le tournoi ?',
        lastMessageAt: new Date(),
      },
      create: {
        userAId: demoUser.id,
        userBId: users[0].id,
        lastMessage: 'Salut ! Prêt pour le tournoi ?',
        lastMessageAt: new Date(),
      },
    }),
    prisma.conversation.upsert({
      where: {
        userAId_userBId: {
          userAId: users[1].id,
          userBId: users[2].id,
        },
      },
      update: {
        lastMessage: 'GG pour le match !',
        lastMessageAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      },
      create: {
        userAId: users[1].id,
        userBId: users[2].id,
        lastMessage: 'GG pour le match !',
        lastMessageAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      },
    }),
    prisma.conversation.upsert({
      where: {
        userAId_userBId: {
          userAId: demoUser.id,
          userBId: users[2].id,
        },
      },
      update: {
        lastMessage: 'On refait une partie ?',
        lastMessageAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      },
      create: {
        userAId: demoUser.id,
        userBId: users[2].id,
        lastMessage: 'On refait une partie ?',
        lastMessageAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      },
    }),
  ]);

  // Créer des messages directs
  const directMessages = await Promise.all([
    // Conversation entre demoUser et users[0]
    prisma.directMessage.create({
      data: {
        conversationId: conversations[0].id,
        senderId: demoUser.id,
        content: 'Salut ! Tu participes au tournoi EA FC 25 ?',
        createdAt: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
      },
    }),
    prisma.directMessage.create({
      data: {
        conversationId: conversations[0].id,
        senderId: users[0].id,
        content: 'Salut ! Oui, j\'ai hâte ! Tu as déjà une stratégie ?',
        createdAt: new Date(Date.now() - 1000 * 60 * 10), // 10 minutes ago
      },
    }),
    prisma.directMessage.create({
      data: {
        conversationId: conversations[0].id,
        senderId: demoUser.id,
        content: 'Salut ! Prêt pour le tournoi ?',
        createdAt: new Date(),
      },
    }),
    // Conversation entre users[1] et users[2]
    prisma.directMessage.create({
      data: {
        conversationId: conversations[1].id,
        senderId: users[1].id,
        content: 'Excellent match ! Tu as bien joué',
        createdAt: new Date(Date.now() - 1000 * 60 * 35), // 35 minutes ago
      },
    }),
    prisma.directMessage.create({
      data: {
        conversationId: conversations[1].id,
        senderId: users[2].id,
        content: 'Merci ! J\'ai eu de la chance sur la fin',
        createdAt: new Date(Date.now() - 1000 * 60 * 32), // 32 minutes ago
      },
    }),
    prisma.directMessage.create({
      data: {
        conversationId: conversations[1].id,
        senderId: users[1].id,
        content: 'GG pour le match !',
        createdAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      },
    }),
    // Conversation entre demoUser et users[2]
    prisma.directMessage.create({
      data: {
        conversationId: conversations[2].id,
        senderId: users[2].id,
        content: 'Salut ! Belle victoire au tournoi !',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
      },
    }),
    prisma.directMessage.create({
      data: {
        conversationId: conversations[2].id,
        senderId: demoUser.id,
        content: 'Merci ! C\'était serré',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2.5), // 2.5 hours ago
      },
    }),
    prisma.directMessage.create({
      data: {
        conversationId: conversations[2].id,
        senderId: demoUser.id,
        content: 'On refait une partie ?',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      },
    }),
  ]);

  // Créer des statistiques de joueur par jeu/plateforme
  const playerStats = await Promise.all([
    // Stats pour JohnDoe
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: demoUser.id,
          game: 'eafc25',
          platform: 'ps5'
        }
      },
      update: {},
      create: {
        userId: demoUser.id,
        game: 'eafc25',
        platform: 'ps5',
        wins: 12,
        losses: 3,
        tournamentWins: 2,
        score: 59, // (12 × 3) + (2 × 10) - (3 × 1) = 36 + 20 - 3 = 53
        totalEarnings: 420.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 heures
      },
    }),
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: demoUser.id,
          game: 'codmw3',
          platform: 'pc'
        }
      },
      update: {},
      create: {
        userId: demoUser.id,
        game: 'codmw3',
        platform: 'pc',
        wins: 8,
        losses: 2,
        tournamentWins: 1,
        score: 32, // (8 × 3) + (1 × 10) - (2 × 1) = 24 + 10 - 2 = 32
        totalEarnings: 180.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 6), // 6 heures
      },
    }),
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: demoUser.id,
          game: 'smashbros',
          platform: 'switch'
        }
      },
      update: {},
      create: {
        userId: demoUser.id,
        game: 'smashbros',
        platform: 'switch',
        wins: 8,
        losses: 2,
        tournamentWins: 0,
        score: 22, // (8 × 3) + (0 × 10) - (2 × 1) = 24 + 0 - 2 = 22
        totalEarnings: 140.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 12), // 12 heures
      },
    }),
    // Stats pour ProGamer88
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: users[0].id,
          game: 'nba2k25',
          platform: 'xbox'
        }
      },
      update: {},
      create: {
        userId: users[0].id,
        game: 'nba2k25',
        platform: 'xbox',
        wins: 15,
        losses: 5,
        tournamentWins: 1,
        score: 50, // (15 × 3) + (1 × 10) - (5 × 1) = 45 + 10 - 5 = 50
        totalEarnings: 320.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 1), // 1 heure
      },
    }),
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: users[0].id,
          game: 'tekken8',
          platform: 'ps5'
        }
      },
      update: {},
      create: {
        userId: users[0].id,
        game: 'tekken8',
        platform: 'ps5',
        wins: 7,
        losses: 3,
        tournamentWins: 1,
        score: 28, // (7 × 3) + (1 × 10) - (3 × 1) = 21 + 10 - 3 = 28
        totalEarnings: 95.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 4), // 4 heures
      },
    }),
    // Stats pour GameMaster
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: users[1].id,
          game: 'eafc25',
          platform: 'ps5'
        }
      },
      update: {},
      create: {
        userId: users[1].id,
        game: 'eafc25',
        platform: 'ps5',
        wins: 20,
        losses: 3,
        tournamentWins: 3,
        score: 87, // (20 × 3) + (3 × 10) - (3 × 1) = 60 + 30 - 3 = 87
        totalEarnings: 680.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes
      },
    }),
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: users[1].id,
          game: 'r6siege',
          platform: 'pc'
        }
      },
      update: {},
      create: {
        userId: users[1].id,
        game: 'r6siege',
        platform: 'pc',
        wins: 15,
        losses: 2,
        tournamentWins: 2,
        score: 63, // (15 × 3) + (2 × 10) - (2 × 1) = 45 + 20 - 2 = 63
        totalEarnings: 450.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 heures
      },
    }),
    // Stats pour Challenger
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: users[2].id,
          game: 'fortnite',
          platform: 'pc'
        }
      },
      update: {},
      create: {
        userId: users[2].id,
        game: 'fortnite',
        platform: 'pc',
        wins: 8,
        losses: 12,
        tournamentWins: 0,
        score: 12, // (8 × 3) + (0 × 10) - (12 × 1) = 24 + 0 - 12 = 12
        totalEarnings: 45.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 8), // 8 heures
      },
    }),
    prisma.playerStats.upsert({
      where: {
        userId_game_platform: {
          userId: users[2].id,
          game: 'mariokart8',
          platform: 'switch'
        }
      },
      update: {},
      create: {
        userId: users[2].id,
        game: 'mariokart8',
        platform: 'switch',
        wins: 4,
        losses: 3,
        tournamentWins: 1,
        score: 19, // (4 × 3) + (1 × 10) - (3 × 1) = 12 + 10 - 3 = 19
        totalEarnings: 65.0,
        lastPlayed: new Date(Date.now() - 1000 * 60 * 60 * 24), // 24 heures
      },
    }),
  ]);

  // Créer des défis entre utilisateurs
  const challenges = await Promise.all([
    // Défi en attente de JohnDoe vers ProGamer88
    prisma.challenge.create({
      data: {
        senderId: demoUser.id,
        receiverId: users[0].id,
        game: 'eafc25',
        platform: 'ps5',
        amount: 25.0,
        rules: '1v1 Ultimate Team, 6 minutes par mi-temps',
        message: 'Salut ! Prêt pour un match FIFA ?',
        status: 'PENDING',
        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24), // 24 heures
      },
    }),
    // Défi accepté entre GameMaster et Challenger
    prisma.challenge.create({
      data: {
        senderId: users[1].id,
        receiverId: users[2].id,
        game: 'codmw3',
        platform: 'pc',
        amount: 30.0,
        rules: '1v1 Custom game, Best of 3',
        message: 'Tu veux tenter ta chance ?',
        status: 'ACCEPTED',
        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 12), // 12 heures
      },
    }),
    // Défi refusé de ProGamer88 vers GameMaster
    prisma.challenge.create({
      data: {
        senderId: users[0].id,
        receiverId: users[1].id,
        game: 'nba2k25',
        platform: 'xbox',
        amount: 40.0,
        rules: '1v1 MyTeam, 4 quart-temps',
        message: 'Allez, on se fait un match !',
        status: 'DECLINED',
        expiresAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // expiré il y a 2 heures
      },
    }),
    // Défi terminé entre Challenger et JohnDoe
    prisma.challenge.create({
      data: {
        senderId: users[2].id,
        receiverId: demoUser.id,
        game: 'smashbros',
        platform: 'switch',
        amount: 15.0,
        rules: 'Best of 3, 3 stocks, objets désactivés',
        message: 'Tu es prêt pour Smash ?',
        status: 'COMPLETED',
        expiresAt: new Date(Date.now() - 1000 * 60 * 60 * 48), // expiré il y a 48 heures
      },
    }),
    // Défi expiré
    prisma.challenge.create({
      data: {
        senderId: users[1].id,
        receiverId: demoUser.id,
        game: 'r6siege',
        platform: 'pc',
        amount: 35.0,
        rules: 'Ranked 1v1, Best of 5',
        message: 'Défi R6 Siege !',
        status: 'EXPIRED',
        expiresAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // expiré il y a 24 heures
      },
    }),
  ]);

  // Créer des clans de test
  const clans = await Promise.all([
    // Clan 1: The Wolves (JohnDoe captain)
    prisma.clan.upsert({
      where: { tag: 'WOLF' },
      update: {},
      create: {
        name: 'The Wolves',
        tag: 'WOLF',
        description: 'Clan de joueurs expérimentés spécialisés dans les FPS et les jeux de sport. Nous privilégions le fair-play et l\'esprit d\'équipe.',
        logo: 'https://i.pinimg.com/originals/83/cf/27/83cf279dfeccea726d509302d549939d.png',
        platform: 'PS5',
        clanType: 'PUBLIC',
        maxMembers: 30,
        totalWins: 15,
        totalLosses: 3,
        totalMatches: 18,
        totalEarnings: 850.0,
        walletBalance: 120.0,
        creatorId: demoUser.id,
      },
    }),
    // Clan 2: Pro Gamers (ProGamer88 captain)
    prisma.clan.upsert({
      where: { tag: 'PRO' },
      update: {},
      create: {
        name: 'Pro Gamers Elite',
        tag: 'PRO',
        description: 'Clan élite pour les joueurs professionnels. Participation obligatoire aux tournois.',
        logo: 'https://i.pinimg.com/736x/91/e0/ba/91e0badabd6751939ccf06e645b859c0.jpg',
        platform: 'PC',
        clanType: 'PRIVATE',
        maxMembers: 20,
        totalWins: 22,
        totalLosses: 5,
        totalMatches: 27,
        totalEarnings: 1250.0,
        walletBalance: 200.0,
        creatorId: users[0].id,
      },
    }),
    // Clan 3: Game Masters (GameMaster captain)
    prisma.clan.upsert({
      where: { tag: 'GM' },
      update: {},
      create: {
        name: 'Game Masters',
        tag: 'GM',
        description: 'Clan ouvert à tous les niveaux. Nous aidons nos membres à s\'améliorer et à progresser ensemble.',
        logo: 'https://i.pinimg.com/originals/f1/b0/78/f1b078e33e3dafb138e5afa5fd9435cd.jpg',
        platform: 'ALL',
        clanType: 'PUBLIC',
        maxMembers: 50,
        totalWins: 12,
        totalLosses: 8,
        totalMatches: 20,
        totalEarnings: 675.0,
        walletBalance: 85.0,
        creatorId: users[1].id,
      },
    }),
    // Clan 4: The Challengers (Challenger captain)
    prisma.clan.upsert({
      where: { tag: 'CHALL' },
      update: {},
      create: {
        name: 'The Challengers',
        tag: 'CHALL',
        description: 'Nouveau clan en formation. Nous cherchons des membres motivés pour grandir ensemble !',
        logo: 'https://i.pinimg.com/736x/8c/78/db/8c78dbaee4411eced09b2554dd1751f7.jpg',
        platform: 'XBOX',
        clanType: 'PUBLIC',
        maxMembers: 25,
        totalWins: 5,
        totalLosses: 7,
        totalMatches: 12,
        totalEarnings: 180.0,
        walletBalance: 25.0,
        creatorId: users[2].id,
      },
    }),
    // Clan 5: Shadow Ninjas (clan sans membres pour test)
    prisma.clan.upsert({
      where: { tag: 'NINJA' },
      update: {},
      create: {
        name: 'Shadow Ninjas',
        tag: 'NINJA',
        description: 'Clan mystérieux spécialisé dans les jeux de combat et les stratégies avancées.',
        logo: 'https://cdn.pixabay.com/photo/2022/05/20/22/27/ninja-7210338_1280.png',
        platform: 'SWITCH',
        clanType: 'PRIVATE',
        maxMembers: 15,
        totalWins: 0,
        totalLosses: 0,
        totalMatches: 0,
        totalEarnings: 0.0,
        walletBalance: 0.0,
        creatorId: demoUser.id,
      },
    }),
  ]);

  // Mettre à jour les utilisateurs avec leur clan
  await Promise.all([
    // JohnDoe rejoint The Wolves comme captain
    prisma.user.update({
      where: { id: demoUser.id },
      data: {
        clanId: clans[0].id,
        clanRole: 'CAPTAIN',
      },
    }),
    // ProGamer88 rejoint Pro Gamers Elite comme captain
    prisma.user.update({
      where: { id: users[0].id },
      data: {
        clanId: clans[1].id,
        clanRole: 'CAPTAIN',
      },
    }),
    // GameMaster rejoint Game Masters comme captain
    prisma.user.update({
      where: { id: users[1].id },
      data: {
        clanId: clans[2].id,
        clanRole: 'CAPTAIN',
      },
    }),
    // Challenger rejoint The Challengers comme captain
    prisma.user.update({
      where: { id: users[2].id },
      data: {
        clanId: clans[3].id,
        clanRole: 'CAPTAIN',
      },
    }),
  ]);

  // Créer des membres de clan
  const clanMembers = await Promise.all([
    // Membres pour The Wolves
    prisma.clanMember.create({
      data: {
        clanId: clans[0].id,
        userId: demoUser.id,
        role: 'CAPTAIN',
        wins: 8,
        losses: 1,
        totalMatches: 9,
        earnings: 420.0,
      },
    }),
    // Membres pour Pro Gamers Elite
    prisma.clanMember.create({
      data: {
        clanId: clans[1].id,
        userId: users[0].id,
        role: 'CAPTAIN',
        wins: 12,
        losses: 2,
        totalMatches: 14,
        earnings: 680.0,
      },
    }),
    // Membres pour Game Masters
    prisma.clanMember.create({
      data: {
        clanId: clans[2].id,
        userId: users[1].id,
        role: 'CAPTAIN',
        wins: 7,
        losses: 4,
        totalMatches: 11,
        earnings: 385.0,
      },
    }),
    // Membres pour The Challengers
    prisma.clanMember.create({
      data: {
        clanId: clans[3].id,
        userId: users[2].id,
        role: 'CAPTAIN',
        wins: 3,
        losses: 5,
        totalMatches: 8,
        earnings: 120.0,
      },
    }),
  ]);

  // Créer des invitations de clan
  const clanInvitations = await Promise.all([
    // Invitation en attente de The Wolves vers un utilisateur fictif
    prisma.clanInvitation.create({
      data: {
        clanId: clans[0].id,
        senderId: demoUser.id,
        receiverId: users[1].id,
        message: 'Salut ! Nous aimerions t\'inviter à rejoindre The Wolves. Tu corresponds parfaitement à notre style de jeu !',
        status: 'PENDING',
        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7), // 7 jours
      },
    }),
    // Invitation refusée
    prisma.clanInvitation.create({
      data: {
        clanId: clans[1].id,
        senderId: users[0].id,
        receiverId: users[2].id,
        message: 'Rejoins Pro Gamers Elite pour participer aux tournois les plus compétitifs !',
        status: 'DECLINED',
        expiresAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // expiré il y a 1 jour
      },
    }),
    // Invitation expirée
    prisma.clanInvitation.create({
      data: {
        clanId: clans[2].id,
        senderId: users[1].id,
        receiverId: demoUser.id,
        message: 'Viens rejoindre Game Masters ! Nous avons besoin de joueurs expérimentés.',
        status: 'EXPIRED',
        expiresAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3), // expiré il y a 3 jours
      },
    }),
  ]);

  // Créer des messages de clan
  const clanMessages = await Promise.all([
    // Messages pour The Wolves
    prisma.clanMessage.create({
      data: {
        clanId: clans[0].id,
        senderId: demoUser.id,
        content: 'Salut à tous ! Nouveau tournoi EA FC 25 ce week-end, qui est partant ?',
        messageType: 'TEXT',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 heures
      },
    }),
    prisma.clanMessage.create({
      data: {
        clanId: clans[0].id,
        senderId: demoUser.id,
        content: 'Félicitations à toute l\'équipe pour notre victoire en clan match !',
        messageType: 'MATCH_RESULT',
        createdAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes
      },
    }),
    // Messages pour Pro Gamers Elite
    prisma.clanMessage.create({
      data: {
        clanId: clans[1].id,
        senderId: users[0].id,
        content: 'Entraînement obligatoire demain soir 20h. Soyez à l\'heure !',
        messageType: 'TEXT',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 4), // 4 heures
      },
    }),
    prisma.clanMessage.create({
      data: {
        clanId: clans[1].id,
        senderId: users[0].id,
        content: 'Nouveau membre rejoint le clan',
        messageType: 'SYSTEM',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 1), // 1 heure
      },
    }),
    // Messages pour Game Masters
    prisma.clanMessage.create({
      data: {
        clanId: clans[2].id,
        senderId: users[1].id,
        content: 'Bienvenue dans Game Masters ! N\'hésitez pas à poser vos questions.',
        messageType: 'TEXT',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 6), // 6 heures
      },
    }),
    prisma.clanMessage.create({
      data: {
        clanId: clans[2].id,
        senderId: users[1].id,
        content: 'Quelqu\'un pour un match Call of Duty ce soir ?',
        messageType: 'TEXT',
        createdAt: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes
      },
    }),
    // Messages pour The Challengers
    prisma.clanMessage.create({
      data: {
        clanId: clans[3].id,
        senderId: users[2].id,
        content: 'Nouveau clan en formation ! Recrutement ouvert à tous les niveaux.',
        messageType: 'TEXT',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8), // 8 heures
      },
    }),
    prisma.clanMessage.create({
      data: {
        clanId: clans[3].id,
        senderId: users[2].id,
        content: 'Première victoire du clan ! Bravo à tous !',
        messageType: 'MATCH_RESULT',
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 heures
      },
    }),
  ]);

  // Créer des matchs de clan
  const clanMatches = await Promise.all([
    // Match terminé entre The Wolves et Pro Gamers Elite
    prisma.clanMatch.create({
      data: {
        clanAId: clans[0].id,
        clanBId: clans[1].id,
        game: 'eafc25',
        platform: 'ps5',
        matchType: 'CHALLENGE',
        format: '2v2',
        amount: 100.0,
        rules: 'Match 2v2 Ultimate Team, 2 x 6 minutes',
        status: 'COMPLETED',
        winnerId: clans[0].id,
        playerAId: demoUser.id,
        playerBId: users[0].id,
        scoreA: 3,
        scoreB: 1,
        screenshotUrl: 'https://i.ytimg.com/vi/_Y2EAMuwztA/maxresdefault.jpg',
        startedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 jours
        completedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 45), // 2 jours + 45 min
      },
    }),
    // Match en cours entre Game Masters et The Challengers
    prisma.clanMatch.create({
      data: {
        clanAId: clans[2].id,
        clanBId: clans[3].id,
        game: 'codmw3',
        platform: 'pc',
        matchType: 'FRIENDLY',
        format: '3v3',
        amount: 0.0,
        rules: 'Match amical 3v3, mode Team Deathmatch',
        status: 'ACTIVE',
        playerAId: users[1].id,
        playerBId: users[2].id,
        scoreA: 0,
        scoreB: 0,
        scheduledAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes
        startedAt: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes
      },
    }),
    // Match en attente entre The Wolves et Game Masters
    prisma.clanMatch.create({
      data: {
        clanAId: clans[0].id,
        clanBId: clans[2].id,
        game: 'r6siege',
        platform: 'pc',
        matchType: 'CHALLENGE',
        format: '5v5',
        amount: 200.0,
        rules: 'Match 5v5 compétitif, mode Bomb',
        status: 'PENDING',
        playerAId: demoUser.id,
        playerBId: users[1].id,
        scoreA: 0,
        scoreB: 0,
        scheduledAt: new Date(Date.now() + 1000 * 60 * 60 * 24), // dans 24 heures
      },
    }),
    // Match annulé
    prisma.clanMatch.create({
      data: {
        clanAId: clans[1].id,
        clanBId: clans[3].id,
        game: 'nba2k25',
        platform: 'xbox',
        matchType: 'TOURNAMENT',
        format: '1v1',
        amount: 50.0,
        rules: 'Match de tournoi 1v1 MyTeam',
        status: 'CANCELLED',
        playerAId: users[0].id,
        playerBId: users[2].id,
        scoreA: 0,
        scoreB: 0,
        scheduledAt: new Date(Date.now() - 1000 * 60 * 60 * 48), // 48 heures
      },
    }),
  ]);

  console.log('✅ Seeding terminé!');
  console.log('👤 Compte de démonstration créé:');
  console.log('   Email: john@doe.com');
  console.log('   Mot de passe: johndoe123');
  console.log(`📊 ${users.length + 1} utilisateurs créés`);
  console.log(`🎯 ${bets.length} paris créés`);
  console.log(`🏆 ${tournaments.length} tournois créés`);
  console.log(`👥 ${tournamentParticipants.length} participants aux tournois`);
  console.log(`⚔️ ${tournamentMatches.length} matchs de tournoi créés`);
  console.log(`💬 ${conversations.length} conversations créées`);
  console.log(`📨 ${directMessages.length} messages directs créés`);
  console.log(`📈 ${playerStats.length} statistiques de joueur créées`);
  console.log(`🎮 ${challenges.length} défis créés`);
  console.log(`🛡️ ${clans.length} clans créés`);
  console.log(`👑 ${clanMembers.length} membres de clan créés`);
  console.log(`📧 ${clanInvitations.length} invitations de clan créées`);
  console.log(`💬 ${clanMessages.length} messages de clan créés`);
  console.log(`⚔️ ${clanMatches.length} matchs de clan créés`);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
