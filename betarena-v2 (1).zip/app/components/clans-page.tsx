
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  Shield, 
  Users, 
  Plus, 
  Search, 
  Trophy, 
  Target, 
  Crown,
  Filter,
  ChevronRight,
  Gamepad2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { ExtendedClan } from '@/lib/types';

const PLATFORMS = [
  { value: 'all', label: 'Toutes les plateformes' },
  { value: 'PS5', label: 'PlayStation 5' },
  { value: 'XBOX', label: 'Xbox Series X/S' },
  { value: 'PC', label: 'PC' },
  { value: 'SWITCH', label: 'Nintendo Switch' },
  { value: 'PS4', label: 'PlayStation 4' },
];

const CLAN_TYPES = [
  { value: 'all', label: 'Tous les types' },
  { value: 'PUBLIC', label: 'Public' },
  { value: 'PRIVATE', label: 'Privé' },
];

const SORT_OPTIONS = [
  { value: 'createdAt', label: 'Plus récents' },
  { value: 'members', label: 'Plus de membres' },
  { value: 'winRate', label: 'Taux de victoire' },
  { value: 'totalEarnings', label: 'Gains totaux' },
  { value: 'name', label: 'Nom (A-Z)' },
];

export default function ClansPage() {
  const [clans, setClans] = useState<ExtendedClan[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [platform, setPlatform] = useState('all');
  const [clanType, setClanType] = useState('all');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const router = useRouter();

  const fetchClans = async (resetPage = false) => {
    try {
      setLoading(true);
      const currentPage = resetPage ? 1 : page;
      
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: '12',
        sortBy,
        sortOrder,
        ...(platform !== 'all' && { platform }),
        ...(clanType !== 'all' && { clanType }),
        ...(searchTerm && { search: searchTerm }),
      });

      const response = await fetch(`/api/clans?${params}`);
      const data = await response.json();

      if (response.ok) {
        if (resetPage) {
          setClans(data.clans);
          setPage(1);
        } else {
          setClans(prev => [...prev, ...data.clans]);
        }
        
        setHasMore(data.pagination.page < data.pagination.totalPages);
      } else {
        console.error('Erreur lors du chargement des clans:', data.error);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des clans:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/clans/leaderboard?limit=5');
      const data = await response.json();

      if (response.ok) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des statistiques:', error);
    }
  };

  useEffect(() => {
    fetchClans(true);
    fetchStats();
  }, [platform, clanType, sortBy, sortOrder, searchTerm]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchClans(true);
  };

  const loadMore = () => {
    setPage(prev => prev + 1);
    fetchClans();
  };

  const joinClan = async (clanId: string) => {
    try {
      const response = await fetch(`/api/clans/${clanId}/join`, {
        method: 'POST',
      });

      if (response.ok) {
        router.push(`/clans/${clanId}`);
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'adhésion au clan');
      }
    } catch (error) {
      console.error('Erreur lors de l\'adhésion au clan:', error);
      alert('Erreur lors de l\'adhésion au clan');
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'PS5':
      case 'PS4':
        return '🎮';
      case 'XBOX':
        return '🎮';
      case 'PC':
        return '💻';
      case 'SWITCH':
        return '🎮';
      default:
        return '🎮';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Shield className="h-8 w-8 text-blue-400" />
            <h1 className="text-4xl font-bold text-white">Clans & Équipes</h1>
          </div>
          <p className="text-gray-300 text-lg mb-6">
            Rejoignez ou créez votre clan pour dominer les compétitions
          </p>
          <Link href="/clans/create">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Créer un clan
            </Button>
          </Link>
        </motion.div>

        {/* Stats Cards */}
        {stats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8"
          >
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Clans totaux</p>
                    <p className="text-2xl font-bold text-white">{stats.totalClans}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Membres totaux</p>
                    <p className="text-2xl font-bold text-white">{stats.totalMembers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Matchs totaux</p>
                    <p className="text-2xl font-bold text-white">{stats.totalMatches}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Taux de victoire moyen</p>
                    <p className="text-2xl font-bold text-white">{stats.averageWinRate.toFixed(1)}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Filter className="h-5 w-5" />
                Filtres & Recherche
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <form onSubmit={handleSearch} className="flex gap-2">
                  <Input
                    placeholder="Rechercher un clan..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                  <Button type="submit" size="icon" className="bg-blue-600 hover:bg-blue-700">
                    <Search className="h-4 w-4" />
                  </Button>
                </form>
                <Select value={platform} onValueChange={setPlatform}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PLATFORMS.map(p => (
                      <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={clanType} onValueChange={setClanType}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CLAN_TYPES.map(t => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SORT_OPTIONS.map(s => (
                      <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sortOrder} onValueChange={setSortOrder}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="desc">Décroissant</SelectItem>
                    <SelectItem value="asc">Croissant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Clans Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8"
        >
          {clans.map((clan, index) => (
            <motion.div
              key={clan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-colors group">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={clan.logo || undefined} alt={clan.name} />
                        <AvatarFallback className="bg-blue-600 text-white">
                          {clan.tag || clan.name.substring(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-white group-hover:text-blue-400 transition-colors">
                          {clan.name}
                        </h3>
                        <p className="text-sm text-gray-400">[{clan.tag}]</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={clan.clanType === 'PUBLIC' ? 'default' : 'secondary'}>
                        {clan.clanType === 'PUBLIC' ? 'Public' : 'Privé'}
                      </Badge>
                      <span className="text-lg">{getPlatformIcon(clan.platform)}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-gray-300 mb-4 line-clamp-2">
                    {clan.description || 'Aucune description disponible'}
                  </p>
                  
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-400">Membres</span>
                      </div>
                      <span className="text-white font-semibold">{clan.memberCount || 0}</span>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Trophy className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-400">Victoires</span>
                      </div>
                      <span className="text-white font-semibold">{clan.totalWins}</span>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <Target className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-400">Taux</span>
                      </div>
                      <span className="text-white font-semibold">
                        {clan.winRate ? clan.winRate.toFixed(1) : '0'}%
                      </span>
                    </div>
                  </div>

                  <Separator className="my-4 bg-slate-700" />

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={clan.creator.avatar || undefined} alt={clan.creator.username} />
                        <AvatarFallback className="bg-purple-600 text-white text-xs">
                          {clan.creator.username.substring(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm text-gray-400">{clan.creator.username}</span>
                    </div>
                    <div className="flex gap-2">
                      <Link href={`/clans/${clan.id}`}>
                        <Button variant="outline" size="sm" className="border-slate-600 text-white hover:bg-slate-700">
                          Voir
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      </Link>
                      {clan.clanType === 'PUBLIC' && (
                        <Button
                          size="sm"
                          onClick={() => joinClan(clan.id)}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Rejoindre
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Load More */}
        {!loading && hasMore && (
          <div className="text-center">
            <Button
              onClick={loadMore}
              variant="outline"
              className="border-slate-600 text-white hover:bg-slate-700"
            >
              Charger plus de clans
            </Button>
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
            <p className="text-gray-400 mt-4">Chargement des clans...</p>
          </div>
        )}

        {/* Empty State */}
        {!loading && clans.length === 0 && (
          <div className="text-center py-12">
            <Gamepad2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-400 text-lg mb-4">Aucun clan trouvé</p>
            <p className="text-gray-500 mb-6">
              Essayez de modifier vos filtres ou créez le premier clan !
            </p>
            <Link href="/clans/create">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="h-4 w-4 mr-2" />
                Créer un clan
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
