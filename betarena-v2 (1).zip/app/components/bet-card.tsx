
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { getGameById, getPlatformById, getGenreById } from '@/lib/games';
import { Eye, Euro, Clock, User, Gamepad2 } from 'lucide-react';
import { motion } from 'framer-motion';
import Image from 'next/image';

interface BetCardProps {
  bet: any;
  onJoin: (betId: string) => void;
  onView: (betId: string) => void;
  currentUserId: string;
}

export default function BetCard({ bet, onJoin, onView, currentUserId }: BetCardProps) {
  const [isJoining, setIsJoining] = useState(false);
  const game = getGameById(bet.game);
  const platform = getPlatformById(bet.platform);
  const genre = getGenreById(game?.genre || '');

  const handleJoin = async () => {
    setIsJoining(true);
    await onJoin(bet.id);
    setIsJoining(false);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const canJoin = bet.status === 'OPEN' && bet.creatorId !== currentUserId;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      whileHover={{ y: -5 }}
      className="h-full"
    >
      <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10 h-full flex flex-col">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative w-12 h-12 bg-gray-700 rounded-lg flex items-center justify-center">
                {game?.logo ? (
                  <Image
                    src={game.logo}
                    alt={game.name}
                    width={32}
                    height={32}
                    className="object-contain"
                  />
                ) : (
                  <Gamepad2 className="w-6 h-6 text-gray-400" />
                )}
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold text-sm leading-tight">
                  {game?.name || 'Jeu inconnu'}
                </h3>
                <div className="flex items-center space-x-2 mt-1">
                  {genre && (
                    <Badge variant="outline" className="text-xs">
                      {genre.icon} {genre.name}
                    </Badge>
                  )}
                  <Badge variant="outline" className="text-xs">
                    {platform?.name || 'Plateforme inconnue'}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center text-green-400 font-bold">
                <Euro className="w-4 h-4 mr-1" />
                {bet.amount}
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Avatar className="w-6 h-6">
                <AvatarImage src={bet.creator?.avatar} />
                <AvatarFallback className="bg-gray-700 text-gray-300 text-xs">
                  {bet.creator?.username?.[0]?.toUpperCase() || '?'}
                </AvatarFallback>
              </Avatar>
              <span className="text-gray-300 text-sm">{bet.creator?.username || 'Utilisateur inconnu'}</span>
            </div>
            
            {bet.rules && (
              <div className="bg-gray-700 rounded p-2">
                <p className="text-gray-300 text-sm line-clamp-2">
                  {bet.rules}
                </p>
              </div>
            )}
            
            <div className="flex items-center text-gray-400 text-xs">
              <Clock className="w-3 h-3 mr-1" />
              {formatDate(bet.createdAt)}
            </div>
          </div>
          
          <div className="flex gap-2 mt-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onView(bet.id)}
              className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Eye className="w-4 h-4 mr-1" />
              Voir
            </Button>
            
            {canJoin && (
              <Button
                size="sm"
                onClick={handleJoin}
                disabled={isJoining}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isJoining ? 'En cours...' : 'Rejoindre'}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
