
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, 
  Users, 
  Globe, 
  Lock, 
  ArrowLeft,
  Info,
  CheckCircle
} from 'lucide-react';
import { motion } from 'framer-motion';

const PLATFORMS = [
  { value: 'PS5', label: 'PlayStation 5', icon: '🎮' },
  { value: 'XBOX', label: 'Xbox Series X/S', icon: '🎮' },
  { value: 'PC', label: 'PC', icon: '💻' },
  { value: 'SWITCH', label: 'Nintendo Switch', icon: '🎮' },
  { value: 'PS4', label: 'PlayStation 4', icon: '🎮' },
  { value: 'ALL', label: 'Toutes plateformes', icon: '🌐' },
];

export default function CreateClanPage() {
  const [formData, setFormData] = useState({
    name: '',
    tag: '',
    description: '',
    platform: '',
    clanType: 'PUBLIC',
    maxMembers: 50,
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<any>({});
  const router = useRouter();

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev: any) => ({
        ...prev,
        [field]: undefined
      }));
    }
  };

  const validateForm = () => {
    const newErrors: any = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Le nom du clan est requis';
    } else if (formData.name.length < 3) {
      newErrors.name = 'Le nom doit contenir au moins 3 caractères';
    } else if (formData.name.length > 50) {
      newErrors.name = 'Le nom ne peut pas dépasser 50 caractères';
    }

    if (!formData.tag.trim()) {
      newErrors.tag = 'Le tag du clan est requis';
    } else if (formData.tag.length < 2) {
      newErrors.tag = 'Le tag doit contenir au moins 2 caractères';
    } else if (formData.tag.length > 10) {
      newErrors.tag = 'Le tag ne peut pas dépasser 10 caractères';
    } else if (!/^[A-Z0-9]+$/.test(formData.tag)) {
      newErrors.tag = 'Le tag ne peut contenir que des lettres majuscules et chiffres';
    }

    if (!formData.platform) {
      newErrors.platform = 'La plateforme est requise';
    }

    if (formData.description && formData.description.length > 500) {
      newErrors.description = 'La description ne peut pas dépasser 500 caractères';
    }

    if (formData.maxMembers < 5 || formData.maxMembers > 100) {
      newErrors.maxMembers = 'Le nombre de membres doit être entre 5 et 100';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/clans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        router.push(`/clans/${data.id}`);
      } else {
        setErrors({ submit: data.error });
      }
    } catch (error) {
      setErrors({ submit: 'Une erreur est survenue lors de la création du clan' });
    } finally {
      setLoading(false);
    }
  };

  const handleTagChange = (value: string) => {
    const uppercaseValue = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    handleInputChange('tag', uppercaseValue);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="text-white hover:bg-slate-800 mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour
          </Button>
          <div className="flex items-center gap-3 mb-4">
            <Shield className="h-8 w-8 text-blue-400" />
            <h1 className="text-4xl font-bold text-white">Créer un clan</h1>
          </div>
          <p className="text-gray-300 text-lg">
            Créez votre propre clan et rassemblez les meilleurs joueurs
          </p>
        </motion.div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Informations du clan</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name & Tag */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-white">
                      Nom du clan *
                    </Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Entrez le nom du clan"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className={`mt-2 bg-slate-700 border-slate-600 text-white ${
                        errors.name ? 'border-red-500' : ''
                      }`}
                      maxLength={50}
                    />
                    {errors.name && (
                      <p className="text-red-400 text-sm mt-1">{errors.name}</p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="tag" className="text-white">
                      Tag du clan *
                    </Label>
                    <Input
                      id="tag"
                      type="text"
                      placeholder="EX: WOLF"
                      value={formData.tag}
                      onChange={(e) => handleTagChange(e.target.value)}
                      className={`mt-2 bg-slate-700 border-slate-600 text-white ${
                        errors.tag ? 'border-red-500' : ''
                      }`}
                      maxLength={10}
                    />
                    {errors.tag && (
                      <p className="text-red-400 text-sm mt-1">{errors.tag}</p>
                    )}
                    <p className="text-gray-400 text-sm mt-1">
                      Majuscules et chiffres uniquement
                    </p>
                  </div>
                </div>

                {/* Preview */}
                {formData.name && formData.tag && (
                  <div className="bg-slate-700/50 p-4 rounded-lg">
                    <Label className="text-white">Aperçu :</Label>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className="bg-blue-600">[{formData.tag}]</Badge>
                      <span className="text-white font-semibold">{formData.name}</span>
                    </div>
                  </div>
                )}

                {/* Description */}
                <div>
                  <Label htmlFor="description" className="text-white">
                    Description du clan
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="Décrivez votre clan, votre style de jeu, vos objectifs..."
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    className={`mt-2 bg-slate-700 border-slate-600 text-white ${
                      errors.description ? 'border-red-500' : ''
                    }`}
                    rows={4}
                    maxLength={500}
                  />
                  {errors.description && (
                    <p className="text-red-400 text-sm mt-1">{errors.description}</p>
                  )}
                  <p className="text-gray-400 text-sm mt-1">
                    {formData.description.length}/500 caractères
                  </p>
                </div>

                {/* Platform */}
                <div>
                  <Label className="text-white">Plateforme principale *</Label>
                  <Select value={formData.platform} onValueChange={(value) => handleInputChange('platform', value)}>
                    <SelectTrigger className={`mt-2 bg-slate-700 border-slate-600 text-white ${
                      errors.platform ? 'border-red-500' : ''
                    }`}>
                      <SelectValue placeholder="Sélectionnez une plateforme" />
                    </SelectTrigger>
                    <SelectContent>
                      {PLATFORMS.map(platform => (
                        <SelectItem key={platform.value} value={platform.value}>
                          <div className="flex items-center gap-2">
                            <span>{platform.icon}</span>
                            <span>{platform.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.platform && (
                    <p className="text-red-400 text-sm mt-1">{errors.platform}</p>
                  )}
                </div>

                {/* Clan Type */}
                <div>
                  <Label className="text-white">Type de clan</Label>
                  <RadioGroup
                    value={formData.clanType}
                    onValueChange={(value) => handleInputChange('clanType', value)}
                    className="mt-2"
                  >
                    <div className="flex items-center space-x-2 p-3 rounded-lg border border-slate-600 bg-slate-700/30">
                      <RadioGroupItem value="PUBLIC" id="public" />
                      <Label htmlFor="public" className="text-white cursor-pointer flex items-center gap-2">
                        <Globe className="h-4 w-4" />
                        Public
                      </Label>
                      <div className="flex-1">
                        <p className="text-gray-400 text-sm">
                          N'importe qui peut rejoindre directement
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-3 rounded-lg border border-slate-600 bg-slate-700/30">
                      <RadioGroupItem value="PRIVATE" id="private" />
                      <Label htmlFor="private" className="text-white cursor-pointer flex items-center gap-2">
                        <Lock className="h-4 w-4" />
                        Privé
                      </Label>
                      <div className="flex-1">
                        <p className="text-gray-400 text-sm">
                          Les joueurs doivent être invités ou faire une candidature
                        </p>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                {/* Max Members */}
                <div>
                  <Label htmlFor="maxMembers" className="text-white">
                    Nombre maximum de membres
                  </Label>
                  <Input
                    id="maxMembers"
                    type="number"
                    min="5"
                    max="100"
                    value={formData.maxMembers}
                    onChange={(e) => handleInputChange('maxMembers', parseInt(e.target.value))}
                    className={`mt-2 bg-slate-700 border-slate-600 text-white ${
                      errors.maxMembers ? 'border-red-500' : ''
                    }`}
                  />
                  {errors.maxMembers && (
                    <p className="text-red-400 text-sm mt-1">{errors.maxMembers}</p>
                  )}
                  <p className="text-gray-400 text-sm mt-1">
                    Entre 5 et 100 membres
                  </p>
                </div>

                <Separator className="bg-slate-700" />

                {/* Info Box */}
                <div className="bg-blue-900/20 border border-blue-800 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Info className="h-5 w-5 text-blue-400 mt-0.5" />
                    <div>
                      <h4 className="text-blue-400 font-semibold mb-2">
                        Informations importantes
                      </h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Vous serez automatiquement le capitaine du clan</li>
                        <li>• Le nom et le tag du clan doivent être uniques</li>
                        <li>• Vous pouvez modifier ces informations plus tard</li>
                        <li>• Seul le capitaine peut supprimer le clan</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Submit Error */}
                {errors.submit && (
                  <div className="bg-red-900/20 border border-red-800 rounded-lg p-4">
                    <p className="text-red-400">{errors.submit}</p>
                  </div>
                )}

                {/* Submit Button */}
                <div className="flex gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => router.back()}
                    className="border-slate-600 text-white hover:bg-slate-700"
                  >
                    Annuler
                  </Button>
                  <Button
                    type="submit"
                    disabled={loading}
                    className="bg-blue-600 hover:bg-blue-700 text-white flex-1"
                  >
                    {loading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Création en cours...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Créer le clan
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
