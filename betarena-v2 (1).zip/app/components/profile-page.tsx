
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import Sidebar from '@/components/sidebar';
import { getGameById, getPlatformById, BET_STATUS_LABELS } from '@/lib/games';
import { User, Trophy, Target, Wallet, Calendar, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';

interface ProfilePageProps {
  user: any;
}

export default function ProfilePage({ user }: ProfilePageProps) {
  const router = useRouter();
  const allBets = [...user.betsCreated, ...user.betsJoined];
  const winRate = user.gamesPlayed > 0 ? (user.gamesWon / user.gamesPlayed) * 100 : 0;
  const availableBalance = user.walletTotal - user.walletEscrow;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN': return 'bg-green-500';
      case 'ACTIVE': return 'bg-blue-500';
      case 'PENDING_RESULT': return 'bg-yellow-500';
      case 'COMPLETED': return 'bg-gray-500';
      case 'CANCELLED': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getWinRateColor = (winRate: number) => {
    if (winRate >= 80) return 'text-green-500';
    if (winRate >= 60) return 'text-yellow-500';
    if (winRate >= 40) return 'text-orange-500';
    return 'text-red-500';
  };

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="flex items-center space-x-6">
              <Avatar className="w-24 h-24">
                <AvatarImage src={user.avatar || undefined} />
                <AvatarFallback className="text-2xl">
                  {user.username.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-3xl font-bold text-white">{user.username}</h1>
                <p className="text-gray-400 mt-2">
                  Membre depuis {formatDistanceToNow(new Date(user.createdAt), { 
                    addSuffix: true, 
                    locale: fr 
                  })}
                </p>
                <div className="flex items-center space-x-4 mt-4">
                  <Badge className="bg-blue-600 text-white">
                    Rang {user.rank}
                  </Badge>
                  <Badge className={`${getWinRateColor(winRate)} bg-gray-800`}>
                    {winRate.toFixed(1)}% victoires
                  </Badge>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Statistiques */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center">
                  <Target className="w-5 h-5 mr-2 text-blue-500" />
                  Parties Jouées
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {user.gamesPlayed}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-green-500" />
                  Victoires
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {user.gamesWon}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center">
                  <Wallet className="w-5 h-5 mr-2 text-yellow-500" />
                  Solde Total
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {user.walletTotal.toFixed(2)}€
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center">
                  <User className="w-5 h-5 mr-2 text-purple-500" />
                  Disponible
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {availableBalance.toFixed(2)}€
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Actions rapides */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap gap-4 mb-8"
          >
            <Button
              onClick={() => router.push('/bets/create')}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Créer un pari
            </Button>
            <Button
              onClick={() => router.push('/bets')}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              Parcourir les paris
            </Button>
            <Button
              onClick={() => router.push('/wallet')}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              Gérer le portefeuille
            </Button>
          </motion.div>

          {/* Historique des paris */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Historique des paris</CardTitle>
                <CardDescription className="text-gray-400">
                  Vos derniers paris et défis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allBets.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      Aucun pari pour le moment
                    </div>
                  ) : (
                    allBets.map((bet) => {
                      const game = getGameById(bet.game);
                      const platform = getPlatformById(bet.platform);
                      const isCreator = bet.creatorId === user.id;
                      const opponent = isCreator ? bet.opponent : bet.creator;

                      return (
                        <div
                          key={bet.id}
                          className="flex items-center justify-between p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                        >
                          <div className="flex items-center space-x-4">
                            <div className="text-2xl">
                              {game?.name === 'NBA 2K25' && '🏀'}
                              {game?.name === 'EA FC 25' && '⚽'}
                              {game?.name === 'Call of Duty: Modern Warfare II' && '🔫'}
                              {game?.name === 'Fortnite' && '🎮'}
                              {game?.name === 'Tekken 8' && '👊'}
                              {game?.name === 'Street Fighter 6' && '🥊'}
                              {!['NBA 2K25', 'EA FC 25', 'Call of Duty: Modern Warfare II', 'Fortnite', 'Tekken 8', 'Street Fighter 6'].includes(game?.name || '') && '🎯'}
                            </div>
                            <div>
                              <div className="font-semibold text-white">
                                {game?.name} - {platform?.name}
                              </div>
                              <div className="text-sm text-gray-400">
                                {opponent ? `vs ${opponent.username}` : 'En attente d\'adversaire'}
                              </div>
                              <div className="text-sm text-gray-400">
                                {formatDistanceToNow(new Date(bet.createdAt), { 
                                  addSuffix: true, 
                                  locale: fr 
                                })}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4">
                            <div className="text-right">
                              <div className="font-semibold text-white">{bet.amount}€</div>
                              <Badge className={`${getStatusColor(bet.status)} text-white`}>
                                {BET_STATUS_LABELS[bet.status as keyof typeof BET_STATUS_LABELS]}
                              </Badge>
                            </div>
                            <Button
                              onClick={() => router.push(`/bets/${bet.id}`)}
                              size="sm"
                              variant="outline"
                              className="border-gray-600 text-gray-300 hover:bg-gray-800"
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
