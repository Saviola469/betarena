
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Trophy, 
  Users, 
  Calendar, 
  ArrowLeft, 
  Crown, 
  Target, 
  Play, 
  CheckCircle,
  Clock,
  MessageSquare 
} from 'lucide-react';
import { ExtendedTournament } from '@/lib/types';
import { GAMES } from '@/lib/games';
import Link from 'next/link';
import { motion } from 'framer-motion';

interface TournamentDetailsPageProps {
  tournamentId: string;
}

export default function TournamentDetailsPage({ tournamentId }: TournamentDetailsPageProps) {
  const { data: session } = useSession();
  const [tournament, setTournament] = useState<ExtendedTournament | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTournament();
  }, [tournamentId]);

  const fetchTournament = async () => {
    try {
      const response = await fetch(`/api/tournaments/${tournamentId}`);
      if (response.ok) {
        const data = await response.json();
        setTournament(data);
      }
    } catch (error) {
      console.error('Erreur lors de la récupération du tournoi:', error);
    } finally {
      setLoading(false);
    }
  };

  const joinTournament = async () => {
    try {
      const response = await fetch(`/api/tournaments/${tournamentId}/join`, {
        method: 'POST',
      });

      if (response.ok) {
        fetchTournament();
      } else {
        const error = await response.json();
        alert(error.error || 'Erreur lors de l\'inscription');
      }
    } catch (error) {
      console.error('Erreur lors de l\'inscription:', error);
      alert('Erreur lors de l\'inscription');
    }
  };

  const startTournament = async () => {
    try {
      const response = await fetch(`/api/tournaments/${tournamentId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'start' }),
      });

      if (response.ok) {
        fetchTournament();
      } else {
        const error = await response.json();
        alert(error.error || 'Erreur lors du démarrage');
      }
    } catch (error) {
      console.error('Erreur lors du démarrage:', error);
      alert('Erreur lors du démarrage');
    }
  };

  const completeMatch = async (matchId: string, winnerId: string) => {
    try {
      const response = await fetch(`/api/tournaments/${tournamentId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'complete_match', matchId, winnerId }),
      });

      if (response.ok) {
        fetchTournament();
      } else {
        const error = await response.json();
        alert(error.error || 'Erreur lors de la finalisation');
      }
    } catch (error) {
      console.error('Erreur lors de la finalisation:', error);
      alert('Erreur lors de la finalisation');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center text-white">Chargement du tournoi...</div>
        </div>
      </div>
    );
  }

  if (!tournament) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center text-white">Tournoi non trouvé</div>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN': return 'bg-green-500';
      case 'ACTIVE': return 'bg-blue-500';
      case 'COMPLETED': return 'bg-gray-500';
      case 'CANCELLED': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'OPEN': return 'Ouvert';
      case 'ACTIVE': return 'En cours';
      case 'COMPLETED': return 'Terminé';
      case 'CANCELLED': return 'Annulé';
      default: return status;
    }
  };

  const getGameDisplayName = (gameId: string) => {
    const game = GAMES.find((g: any) => g.id === gameId);
    return game?.name || gameId;
  };

  const isParticipating = () => {
    return tournament.participants.some(p => p.userId === session?.user?.id);
  };

  const isCreator = () => {
    return tournament.creatorId === session?.user?.id;
  };

  const getMatchStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'ACTIVE': return <Play className="w-4 h-4 text-blue-400" />;
      case 'COMPLETED': return <CheckCircle className="w-4 h-4 text-green-400" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const organizeBracket = () => {
    const rounds: { [key: number]: any[] } = {};
    
    tournament.matches.forEach(match => {
      if (!rounds[match.round]) {
        rounds[match.round] = [];
      }
      rounds[match.round].push(match);
    });

    return rounds;
  };

  const rounds = organizeBracket();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link href="/tournaments">
            <Button variant="ghost" size="icon" className="text-white">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-white mb-2">{tournament.name}</h1>
            <div className="flex items-center gap-4">
              <Badge className={`${getStatusColor(tournament.status)} text-white`}>
                {getStatusText(tournament.status)}
              </Badge>
              {tournament.isPrivate && (
                <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                  Privé
                </Badge>
              )}
            </div>
          </div>
          <div className="flex gap-2">
            {tournament.status === 'OPEN' && !isParticipating() && (
              <Button
                onClick={joinTournament}
                className="bg-blue-600 hover:bg-blue-700"
                disabled={tournament.participants.length >= tournament.maxParticipants}
              >
                {tournament.participants.length >= tournament.maxParticipants ? 'Complet' : 'Rejoindre'}
              </Button>
            )}
            {tournament.status === 'OPEN' && isCreator() && tournament.participants.length >= 2 && (
              <Button
                onClick={startTournament}
                className="bg-green-600 hover:bg-green-700"
              >
                Démarrer le tournoi
              </Button>
            )}
          </div>
        </motion.div>

        {/* Tournament Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Target className="w-5 h-5" />
                Informations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Jeu:</span>
                <span className="text-white">{getGameDisplayName(tournament.game)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Plateforme:</span>
                <span className="text-white">{tournament.platform.toUpperCase()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Format:</span>
                <span className="text-white">{tournament.format}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Type:</span>
                <span className="text-white">
                  {tournament.tournamentType === 'SINGLE_ELIMINATION' ? 'Élimination simple' : 
                   tournament.tournamentType === 'DOUBLE_ELIMINATION' ? 'Élimination double' : 'Round Robin'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Frais d'entrée:</span>
                <span className="text-white">
                  {tournament.entryFee > 0 ? `${tournament.entryFee}€` : 'Gratuit'}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="w-5 h-5" />
                Participants
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Inscrits:</span>
                <span className="text-white">{tournament.participants.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Maximum:</span>
                <span className="text-white">{tournament.maxParticipants}</span>
              </div>
              <Progress 
                value={(tournament.participants.length / tournament.maxParticipants) * 100} 
                className="w-full"
              />
              <div className="flex items-center gap-2">
                <Avatar className="w-6 h-6">
                  <AvatarImage src={tournament.creator.avatar || undefined} />
                  <AvatarFallback>{tournament.creator.username[0]}</AvatarFallback>
                </Avatar>
                <span className="text-gray-300">Créé par {tournament.creator.username}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Crown className="w-5 h-5" />
                Prix
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Distribution:</span>
                <span className="text-white">{tournament.prizeDistribution}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Total:</span>
                <span className="text-white">
                  {tournament.entryFee > 0 
                    ? `${tournament.entryFee * tournament.participants.length}€`
                    : 'Gloire'
                  }
                </span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="participants" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="participants">Participants</TabsTrigger>
              <TabsTrigger value="bracket">Bracket</TabsTrigger>
              <TabsTrigger value="matches">Matches</TabsTrigger>
            </TabsList>

            <TabsContent value="participants" className="space-y-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Liste des participants</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {tournament.participants.map(participant => (
                      <div key={participant.id} className="flex items-center gap-3 p-3 bg-slate-700 rounded-lg">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={participant.user.avatar || undefined} />
                          <AvatarFallback>{participant.user.username[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="text-white font-medium">{participant.user.username}</div>
                          <div className="text-gray-400 text-sm">Rang: {participant.user.rank}</div>
                        </div>
                        {participant.placement && (
                          <Badge className="bg-yellow-600 text-white">
                            #{participant.placement}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="bracket" className="space-y-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Bracket du tournoi</CardTitle>
                </CardHeader>
                <CardContent>
                  {Object.keys(rounds).length > 0 ? (
                    <div className="space-y-8">
                      {Object.entries(rounds).map(([round, matches]) => (
                        <div key={round} className="space-y-4">
                          <h3 className="text-xl font-bold text-white">
                            {round === '1' ? 'Premier tour' : 
                             round === '2' ? 'Deuxième tour' : 
                             round === '3' ? 'Demi-finale' : 
                             round === '4' ? 'Finale' : `Round ${round}`}
                          </h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {matches.map(match => (
                              <div key={match.id} className="bg-slate-700 rounded-lg p-4">
                                <div className="flex justify-between items-center mb-2">
                                  <div className="flex items-center gap-2">
                                    {getMatchStatusIcon(match.status)}
                                    <span className="text-white text-sm">
                                      Match {match.id.slice(-4)}
                                    </span>
                                  </div>
                                  {match.status === 'ACTIVE' && isCreator() && (
                                    <Button size="sm" variant="outline">
                                      Gérer
                                    </Button>
                                  )}
                                </div>
                                <div className="space-y-2">
                                  <div className={`flex items-center justify-between p-2 rounded ${
                                    match.winnerId === match.playerAId ? 'bg-green-600' : 'bg-slate-600'
                                  }`}>
                                    <div className="flex items-center gap-2">
                                      <Avatar className="w-6 h-6">
                                        <AvatarImage src={match.playerA?.avatar || undefined} />
                                        <AvatarFallback>{match.playerA?.username?.[0] || '?'}</AvatarFallback>
                                      </Avatar>
                                      <span className="text-white text-sm">
                                        {match.playerA?.username || 'TBD'}
                                      </span>
                                    </div>
                                    {match.winnerId === match.playerAId && (
                                      <Trophy className="w-4 h-4 text-yellow-400" />
                                    )}
                                  </div>
                                  <div className={`flex items-center justify-between p-2 rounded ${
                                    match.winnerId === match.playerBId ? 'bg-green-600' : 'bg-slate-600'
                                  }`}>
                                    <div className="flex items-center gap-2">
                                      <Avatar className="w-6 h-6">
                                        <AvatarImage src={match.playerB?.avatar || undefined} />
                                        <AvatarFallback>{match.playerB?.username?.[0] || '?'}</AvatarFallback>
                                      </Avatar>
                                      <span className="text-white text-sm">
                                        {match.playerB?.username || 'TBD'}
                                      </span>
                                    </div>
                                    {match.winnerId === match.playerBId && (
                                      <Trophy className="w-4 h-4 text-yellow-400" />
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Trophy className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-400">
                        {tournament.status === 'OPEN' 
                          ? 'Le bracket sera généré une fois le tournoi démarré'
                          : 'Aucun match disponible'
                        }
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="matches" className="space-y-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Historique des matches</CardTitle>
                </CardHeader>
                <CardContent>
                  {tournament.matches.length > 0 ? (
                    <div className="space-y-4">
                      {tournament.matches.map(match => (
                        <div key={match.id} className="bg-slate-700 rounded-lg p-4">
                          <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center gap-2">
                              {getMatchStatusIcon(match.status)}
                              <span className="text-white">
                                Round {match.round} - {match.status === 'COMPLETED' ? 'Terminé' : 'En cours'}
                              </span>
                            </div>
                            <span className="text-gray-400 text-sm">
                              {new Date(match.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="grid grid-cols-3 gap-4 items-center">
                            <div className="text-center">
                              <div className="flex items-center justify-center gap-2">
                                <Avatar className="w-8 h-8">
                                  <AvatarImage src={match.playerA?.avatar || undefined} />
                                  <AvatarFallback>{match.playerA?.username?.[0] || '?'}</AvatarFallback>
                                </Avatar>
                                <span className="text-white">
                                  {match.playerA?.username || 'TBD'}
                                </span>
                              </div>
                            </div>
                            <div className="text-center">
                              <span className="text-gray-400">vs</span>
                            </div>
                            <div className="text-center">
                              <div className="flex items-center justify-center gap-2">
                                <Avatar className="w-8 h-8">
                                  <AvatarImage src={match.playerB?.avatar || undefined} />
                                  <AvatarFallback>{match.playerB?.username?.[0] || '?'}</AvatarFallback>
                                </Avatar>
                                <span className="text-white">
                                  {match.playerB?.username || 'TBD'}
                                </span>
                              </div>
                            </div>
                          </div>
                          {match.winnerId && (
                            <div className="mt-3 text-center">
                              <div className="flex items-center justify-center gap-2">
                                <Trophy className="w-4 h-4 text-yellow-400" />
                                <span className="text-green-400">
                                  Vainqueur: {match.winner?.username}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Clock className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-400">Aucun match n'a encore été joué</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
