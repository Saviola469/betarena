
'use client';

import { useState } from 'react';
import { usePathname } from 'next/navigation';
import { useSession, signOut } from 'next-auth/react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, 
  Swords, 
  PlusCircle, 
  Trophy, 
  Wallet, 
  User, 
  LogOut, 
  Menu,
  X,
  MessageSquare,
  Crown,
  Shield
} from 'lucide-react';

const navigation = [
  { name: 'Accueil', href: '/', icon: LayoutDashboard },
  { name: 'Parcourir les Paris', href: '/bets', icon: Swords },
  { name: 'Créer un Pari', href: '/bets/create', icon: PlusCircle },
  { name: 'Tournois', href: '/tournaments', icon: Trophy },
  { name: 'Clans', href: '/clans', icon: Shield },
  { name: 'Messages', href: '/messages', icon: MessageSquare },
  { name: 'Classement', href: '/leaderboard', icon: Crown },
  { name: 'Portefeuille', href: '/wallet', icon: Wallet },
];

export default function Sidebar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const { data: session } = useSession();

  const handleSignOut = () => {
    signOut({ callbackUrl: '/login' });
  };

  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden">
        <Button
          variant="ghost"
          size="icon"
          className="fixed top-4 left-4 z-50 text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Mobile menu overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-gray-900 transform transition-transform duration-300 ease-in-out
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:inset-0
      `}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-center py-8 px-4">
            <div className="relative w-32 h-12">
              <Image
                src="https://cdn.abacus.ai/images/de3f90ab-d77d-4f33-b453-a7bfe157732a.png"
                alt="Betarena"
                fill
                className="object-contain"
              />
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 space-y-2">
            {navigation.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`
                    flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors
                    ${isActive 
                      ? 'bg-blue-600 text-white' 
                      : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                    }
                  `}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.name}
                </Link>
              );
            })}
          </nav>

          {/* User section */}
          {session && (
            <div className="p-4 border-t border-gray-800">
              <Link
                href="/profile"
                className="flex items-center px-4 py-3 text-sm font-medium text-gray-300 hover:bg-gray-800 hover:text-white rounded-lg transition-colors mb-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <User className="mr-3 h-5 w-5" />
                Mon Profil
              </Link>
              <Button
                variant="ghost"
                className="w-full justify-start px-4 py-3 text-sm font-medium text-gray-300 hover:bg-gray-800 hover:text-white rounded-lg"
                onClick={handleSignOut}
              >
                <LogOut className="mr-3 h-5 w-5" />
                Déconnexion
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
