
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Trophy, ArrowLeft, Users, Calendar, Settings, Crown } from 'lucide-react';
import { GAMES } from '@/lib/games';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default function CreateTournamentPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    game: '',
    platform: '',
    maxParticipants: 8,
    entryFee: 0,
    format: 'BO1',
    tournamentType: 'SINGLE_ELIMINATION',
    isPrivate: false,
    startDate: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/tournaments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const tournament = await response.json();
        router.push(`/tournaments/${tournament.id}`);
      } else {
        const error = await response.json();
        alert(error.error || 'Erreur lors de la création du tournoi');
      }
    } catch (error) {
      console.error('Erreur lors de la création du tournoi:', error);
      alert('Erreur lors de la création du tournoi');
    } finally {
      setLoading(false);
    }
  };

  const supportedGames = GAMES.filter((game: any) => 
    ['eafc25', 'nba2k25', 'codmw3', 'r6siege', 'smashbros'].includes(game.id)
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link href="/tournaments">
            <Button variant="ghost" size="icon" className="text-white">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <Trophy className="w-8 h-8 text-yellow-400" />
            <h1 className="text-3xl font-bold text-white">Créer un tournoi</h1>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Configuration du tournoi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Informations de base */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-white">
                      Nom du tournoi *
                    </Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: Championnat EA FC 25"
                      required
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="game" className="text-white">
                      Jeu *
                    </Label>
                    <Select value={formData.game} onValueChange={(value) => setFormData({ ...formData, game: value })}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Sélectionner un jeu" />
                      </SelectTrigger>
                      <SelectContent>
                        {supportedGames.map((game: any) => (
                          <SelectItem key={game.id} value={game.id}>
                            {game.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="platform" className="text-white">
                      Plateforme *
                    </Label>
                    <Select value={formData.platform} onValueChange={(value) => setFormData({ ...formData, platform: value })}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Sélectionner une plateforme" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ps5">PlayStation 5</SelectItem>
                        <SelectItem value="ps4">PlayStation 4</SelectItem>
                        <SelectItem value="xbox">Xbox</SelectItem>
                        <SelectItem value="pc">PC</SelectItem>
                        <SelectItem value="switch">Nintendo Switch</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxParticipants" className="text-white">
                      Nombre maximum de participants *
                    </Label>
                    <Select 
                      value={formData.maxParticipants.toString()} 
                      onValueChange={(value) => setFormData({ ...formData, maxParticipants: parseInt(value) })}
                    >
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="4">4 participants</SelectItem>
                        <SelectItem value="8">8 participants</SelectItem>
                        <SelectItem value="16">16 participants</SelectItem>
                        <SelectItem value="32">32 participants</SelectItem>
                        <SelectItem value="64">64 participants</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Configuration avancée */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="entryFee" className="text-white">
                      Frais d'entrée (€)
                    </Label>
                    <Input
                      id="entryFee"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.entryFee}
                      onChange={(e) => setFormData({ ...formData, entryFee: parseFloat(e.target.value) || 0 })}
                      placeholder="0.00"
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="format" className="text-white">
                      Format des matches
                    </Label>
                    <Select value={formData.format} onValueChange={(value) => setFormData({ ...formData, format: value })}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BO1">Best of 1</SelectItem>
                        <SelectItem value="BO3">Best of 3</SelectItem>
                        <SelectItem value="BO5">Best of 5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tournamentType" className="text-white">
                      Type de tournoi
                    </Label>
                    <Select value={formData.tournamentType} onValueChange={(value) => setFormData({ ...formData, tournamentType: value })}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="SINGLE_ELIMINATION">Élimination simple</SelectItem>
                        <SelectItem value="DOUBLE_ELIMINATION">Élimination double</SelectItem>
                        <SelectItem value="ROUND_ROBIN">Round Robin (futur)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="startDate" className="text-white">
                      Date de début (optionnel)
                    </Label>
                    <Input
                      id="startDate"
                      type="datetime-local"
                      value={formData.startDate}
                      onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>

                {/* Options */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <Label className="text-white">Tournoi privé</Label>
                      <p className="text-sm text-gray-400">
                        Seuls les utilisateurs invités peuvent rejoindre le tournoi
                      </p>
                    </div>
                    <Switch
                      checked={formData.isPrivate}
                      onCheckedChange={(checked) => setFormData({ ...formData, isPrivate: checked })}
                    />
                  </div>
                </div>

                {/* Récapitulatif */}
                <div className="bg-slate-700 rounded-lg p-4 space-y-2">
                  <h3 className="font-semibold text-white mb-2">Récapitulatif</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-400" />
                      <span className="text-gray-300">
                        {formData.maxParticipants} participants max
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Crown className="w-4 h-4 text-yellow-400" />
                      <span className="text-gray-300">
                        {formData.entryFee > 0 ? `${formData.entryFee}€ d'entrée` : 'Gratuit'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy className="w-4 h-4 text-purple-400" />
                      <span className="text-gray-300">
                        {formData.tournamentType === 'SINGLE_ELIMINATION' ? 'Élimination simple' : 
                         formData.tournamentType === 'DOUBLE_ELIMINATION' ? 'Élimination double' : 'Round Robin'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-green-400" />
                      <span className="text-gray-300">
                        {formData.startDate ? new Date(formData.startDate).toLocaleDateString() : 'Pas de date fixée'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Boutons */}
                <div className="flex gap-4">
                  <Link href="/tournaments" className="flex-1">
                    <Button variant="outline" className="w-full">
                      Annuler
                    </Button>
                  </Link>
                  <Button 
                    type="submit" 
                    disabled={loading || !formData.name || !formData.game || !formData.platform}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    {loading ? 'Création...' : 'Créer le tournoi'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
