
'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import Sidebar from '@/components/sidebar';
import { getGameById, getPlatformById, BET_STATUS_LABELS } from '@/lib/games';
import { ArrowLeft, MessageCircle, Upload, Send, Swords, Clock, Euro, Camera, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import Image from 'next/image';

interface BetDetailsPageProps {
  bet: any;
  currentUserId: string;
}

export default function BetDetailsPage({ bet, currentUserId }: BetDetailsPageProps) {
  const [newMessage, setNewMessage] = useState('');
  const [messages, setMessages] = useState(bet.messages || []);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const { toast } = useToast();

  const game = getGameById(bet.game);
  const platform = getPlatformById(bet.platform);
  const isCreator = bet.creatorId === currentUserId;
  const isOpponent = bet.opponentId === currentUserId;
  const isParticipant = isCreator || isOpponent;

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleJoinBet = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/bets/${bet.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'join' }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erreur lors de la jointure du pari');
      }

      toast({
        title: 'Pari rejoint!',
        description: 'Vous avez rejoint le pari avec succès.',
      });

      router.refresh();
    } catch (error) {
      toast({
        title: 'Erreur',
        description: error instanceof Error ? error.message : 'Une erreur est survenue',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      const response = await fetch(`/api/bets/${bet.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: newMessage }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erreur lors de l\'envoi du message');
      }

      const message = await response.json();
      setMessages([...messages, message]);
      setNewMessage('');
    } catch (error) {
      toast({
        title: 'Erreur',
        description: error instanceof Error ? error.message : 'Une erreur est survenue',
        variant: 'destructive',
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN': return 'bg-green-500';
      case 'ACTIVE': return 'bg-blue-500';
      case 'PENDING_RESULT': return 'bg-yellow-500';
      case 'COMPLETED': return 'bg-gray-500';
      case 'CANCELLED': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'OPEN': return <Clock className="w-4 h-4" />;
      case 'ACTIVE': return <Swords className="w-4 h-4" />;
      case 'PENDING_RESULT': return <Upload className="w-4 h-4" />;
      case 'COMPLETED': return <Badge className="w-4 h-4" />;
      case 'CANCELLED': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <Button
              onClick={() => router.back()}
              variant="outline"
              className="mb-4 border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {game && (
                  <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-gray-700">
                    <Image
                      src={game.logo}
                      alt={game.name}
                      fill
                      className="object-contain"
                    />
                  </div>
                )}
                <div>
                  <h1 className="text-2xl font-bold text-white">{game?.name}</h1>
                  <p className="text-gray-400">{platform?.name}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Badge className={`${getStatusColor(bet.status)} text-white`}>
                  {getStatusIcon(bet.status)}
                  <span className="ml-1">
                    {BET_STATUS_LABELS[bet.status as keyof typeof BET_STATUS_LABELS]}
                  </span>
                </Badge>
                <div className="text-right">
                  <div className="text-2xl font-bold text-white flex items-center">
                    <Euro className="w-6 h-6 mr-1 text-green-500" />
                    {bet.amount}€
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Informations principales */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="lg:col-span-2 space-y-6"
            >
              {/* Détails du pari */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Détails du pari</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-400">Créé par</div>
                      <div className="flex items-center space-x-2 mt-1">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={bet.creator.avatar || undefined} />
                          <AvatarFallback className="text-xs">
                            {bet.creator.username.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-white">{bet.creator.username}</span>
                        <Badge className="bg-gray-700 text-gray-300">
                          Rang {bet.creator.rank}
                        </Badge>
                      </div>
                    </div>
                    
                    {bet.opponent && (
                      <div>
                        <div className="text-sm text-gray-400">Adversaire</div>
                        <div className="flex items-center space-x-2 mt-1">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={bet.opponent.avatar || undefined} />
                            <AvatarFallback className="text-xs">
                              {bet.opponent.username.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-white">{bet.opponent.username}</span>
                          <Badge className="bg-gray-700 text-gray-300">
                            Rang {bet.opponent.rank}
                          </Badge>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-400">Créé</div>
                    <div className="text-white">
                      {formatDistanceToNow(new Date(bet.createdAt), { 
                        addSuffix: true, 
                        locale: fr 
                      })}
                    </div>
                  </div>
                  
                  {bet.rules && (
                    <div>
                      <div className="text-sm text-gray-400">Règles spéciales</div>
                      <div className="text-white bg-gray-700 p-3 rounded-lg mt-1">
                        {bet.rules}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Actions */}
              {bet.status === 'OPEN' && !isCreator && (
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <p className="text-gray-400 mb-4">
                        Ce pari est ouvert et attend un adversaire
                      </p>
                      <Button
                        onClick={handleJoinBet}
                        disabled={isLoading}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Swords className="w-4 h-4 mr-2" />
                        {isLoading ? 'Rejoindre...' : 'Rejoindre le défi'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Preuves */}
              {bet.screenshots && bet.screenshots.length > 0 && (
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Camera className="w-5 h-5 mr-2" />
                      Preuves soumises
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {bet.screenshots.map((screenshot: any) => (
                        <div key={screenshot.id} className="relative">
                          <Image
                            src={screenshot.imageUrl}
                            alt="Preuve de match"
                            width={300}
                            height={200}
                            className="rounded-lg object-cover"
                          />
                          <div className="absolute bottom-2 left-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-sm">
                            {screenshot.userId === bet.creatorId ? bet.creator.username : bet.opponent.username}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>

            {/* Chat */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="lg:col-span-1"
            >
              <Card className="bg-gray-800 border-gray-700 h-96 flex flex-col">
                <CardHeader className="pb-3">
                  <CardTitle className="text-white flex items-center">
                    <MessageCircle className="w-5 h-5 mr-2" />
                    Chat
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Communiquez avec votre adversaire
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto space-y-3 mb-4">
                    {messages.length === 0 ? (
                      <div className="text-center text-gray-400 text-sm">
                        Aucun message pour le moment
                      </div>
                    ) : (
                      messages.map((message: any) => (
                        <div
                          key={message.id}
                          className={`flex ${
                            message.userId === currentUserId ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          <div
                            className={`max-w-xs px-3 py-2 rounded-lg ${
                              message.userId === currentUserId
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-700 text-gray-300'
                            }`}
                          >
                            <div className="text-xs opacity-75 mb-1">
                              {message.user.username}
                            </div>
                            <div className="text-sm">{message.content}</div>
                          </div>
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Formulaire de message */}
                  {isParticipant && (
                    <form onSubmit={handleSendMessage} className="flex space-x-2">
                      <Input
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Tapez votre message..."
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      />
                      <Button
                        type="submit"
                        size="sm"
                        disabled={!newMessage.trim()}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
