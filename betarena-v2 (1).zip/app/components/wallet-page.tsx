
'use client';

import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Sidebar from '@/components/sidebar';
import { Wallet, CreditCard, ArrowUpRight, ArrowDownLeft, Clock, CheckCircle, XCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';

interface WalletData {
  wallet: {
    total: number;
    escrow: number;
    available: number;
  };
  transactions: any[];
}

export default function WalletPage() {
  const [walletData, setWalletData] = useState<WalletData | null>(null);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchWalletData();
  }, []);

  const fetchWalletData = async () => {
    try {
      const response = await fetch('/api/wallet');
      if (response.ok) {
        const data = await response.json();
        setWalletData(data);
      }
    } catch (error) {
      console.error('Erreur lors du chargement du portefeuille:', error);
    }
  };

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(depositAmount);
    
    if (!amount || amount <= 0) {
      toast({
        title: 'Erreur',
        description: 'Veuillez entrer un montant valide',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'deposit', amount }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erreur lors du dépôt');
      }

      toast({
        title: 'Dépôt réussi',
        description: `${amount}€ ont été ajoutés à votre portefeuille`,
      });

      setDepositAmount('');
      fetchWalletData();
    } catch (error) {
      toast({
        title: 'Erreur',
        description: error instanceof Error ? error.message : 'Une erreur est survenue',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    
    if (!amount || amount <= 0) {
      toast({
        title: 'Erreur',
        description: 'Veuillez entrer un montant valide',
        variant: 'destructive',
      });
      return;
    }

    if (walletData && amount > walletData.wallet.available) {
      toast({
        title: 'Erreur',
        description: 'Solde insuffisant',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'withdrawal', amount }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erreur lors du retrait');
      }

      toast({
        title: 'Demande de retrait envoyée',
        description: `Votre demande de retrait de ${amount}€ a été soumise`,
      });

      setWithdrawAmount('');
      fetchWalletData();
    } catch (error) {
      toast({
        title: 'Erreur',
        description: error instanceof Error ? error.message : 'Une erreur est survenue',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'DEPOSIT': return <ArrowDownLeft className="w-4 h-4 text-green-500" />;
      case 'WITHDRAWAL': return <ArrowUpRight className="w-4 h-4 text-red-500" />;
      case 'BET_ESCROW': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'BET_PAYOUT': return <CheckCircle className="w-4 h-4 text-green-500" />;
      default: return <Wallet className="w-4 h-4 text-gray-400" />;
    }
  };

  const getTransactionLabel = (type: string) => {
    switch (type) {
      case 'DEPOSIT': return 'Dépôt';
      case 'WITHDRAWAL': return 'Retrait';
      case 'BET_ESCROW': return 'Pari en cours';
      case 'BET_PAYOUT': return 'Gain de pari';
      default: return type;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <Badge className="bg-green-500 text-white">Terminé</Badge>;
      case 'PENDING':
        return <Badge className="bg-yellow-500 text-white">En attente</Badge>;
      case 'FAILED':
        return <Badge className="bg-red-500 text-white">Échoué</Badge>;
      default:
        return <Badge className="bg-gray-500 text-white">{status}</Badge>;
    }
  };

  if (!walletData) {
    return (
      <div className="flex min-h-screen bg-gray-900">
        <Sidebar />
        <div className="flex-1 lg:ml-64">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-700 rounded w-1/3 mb-4"></div>
              <div className="h-4 bg-gray-700 rounded w-1/2 mb-8"></div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-32 bg-gray-700 rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <h1 className="text-3xl font-bold text-white">Mon Portefeuille</h1>
            <p className="text-gray-400 mt-2">
              Gérez vos fonds et consultez votre historique de transactions
            </p>
          </motion.div>

          {/* Soldes */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center">
                  <Wallet className="w-5 h-5 mr-2 text-green-500" />
                  Solde Total
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {walletData.wallet.total.toFixed(2)}€
                </div>
                <p className="text-sm text-gray-400">
                  Votre solde total
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-yellow-500" />
                  Solde Bloqué
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {walletData.wallet.escrow.toFixed(2)}€
                </div>
                <p className="text-sm text-gray-400">
                  Paris en cours
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-white flex items-center">
                  <CreditCard className="w-5 h-5 mr-2 text-blue-500" />
                  Solde Disponible
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {walletData.wallet.available.toFixed(2)}€
                </div>
                <p className="text-sm text-gray-400">
                  Disponible pour parier
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8"
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Faire un dépôt</CardTitle>
                <CardDescription className="text-gray-400">
                  Ajoutez des fonds à votre portefeuille
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleDeposit} className="space-y-4">
                  <div>
                    <Label htmlFor="depositAmount" className="text-gray-300">
                      Montant (€)
                    </Label>
                    <Input
                      id="depositAmount"
                      type="number"
                      min="10"
                      max="1000"
                      step="0.01"
                      placeholder="50.00"
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    <ArrowDownLeft className="w-4 h-4 mr-2" />
                    {isLoading ? 'Traitement...' : 'Déposer'}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Demander un retrait</CardTitle>
                <CardDescription className="text-gray-400">
                  Retirez vos gains
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleWithdraw} className="space-y-4">
                  <div>
                    <Label htmlFor="withdrawAmount" className="text-gray-300">
                      Montant (€)
                    </Label>
                    <Input
                      id="withdrawAmount"
                      type="number"
                      min="10"
                      max={walletData.wallet.available}
                      step="0.01"
                      placeholder="25.00"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={isLoading || walletData.wallet.available <= 0}
                    className="w-full bg-red-600 hover:bg-red-700 text-white"
                  >
                    <ArrowUpRight className="w-4 h-4 mr-2" />
                    {isLoading ? 'Traitement...' : 'Retirer'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Historique */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Historique des transactions</CardTitle>
                <CardDescription className="text-gray-400">
                  Vos dernières transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {walletData.transactions.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      Aucune transaction pour le moment
                    </div>
                  ) : (
                    walletData.transactions.map((transaction) => (
                      <div
                        key={transaction.id}
                        className="flex items-center justify-between p-4 bg-gray-700 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          {getTransactionIcon(transaction.type)}
                          <div>
                            <div className="font-medium text-white">
                              {getTransactionLabel(transaction.type)}
                            </div>
                            <div className="text-sm text-gray-400">
                              {formatDistanceToNow(new Date(transaction.createdAt), { 
                                addSuffix: true, 
                                locale: fr 
                              })}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <div className={`font-semibold ${
                              transaction.type === 'DEPOSIT' || transaction.type === 'BET_PAYOUT' 
                                ? 'text-green-500' 
                                : 'text-red-500'
                            }`}>
                              {transaction.type === 'DEPOSIT' || transaction.type === 'BET_PAYOUT' ? '+' : '-'}
                              {transaction.amount.toFixed(2)}€
                            </div>
                          </div>
                          {getStatusBadge(transaction.status)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
