
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import Sidebar from '@/components/sidebar';
import { 
  GAMES, 
  PLATFORMS, 
  GENRES, 
  getGameById, 
  getPlatformById, 
  getCompatiblePlatforms, 
  getGamesByGenre,
  getGameRules,
  formatGameRules 
} from '@/lib/games';
import { ArrowLeft, Gamepad2, Euro, AlertCircle, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import Image from 'next/image';

export default function CreateBetPage() {
  const [step, setStep] = useState(1);
  const [selectedGame, setSelectedGame] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState('');
  const [amount, setAmount] = useState('');
  const [customRules, setCustomRules] = useState('');
  const [gameRulesData, setGameRulesData] = useState<any>({});
  const [selectedGenre, setSelectedGenre] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const finalRules = customRules.trim() || formatGameRules(selectedGame, gameRulesData);
      
      const response = await fetch('/api/bets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          game: selectedGame,
          platform: selectedPlatform,
          amount: parseFloat(amount),
          rules: finalRules || undefined,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erreur lors de la création du pari');
      }

      const bet = await response.json();

      toast({
        title: 'Pari créé!',
        description: 'Votre pari a été créé avec succès et est maintenant visible.',
      });

      router.push(`/bets/${bet.id}`);
    } catch (error) {
      toast({
        title: 'Erreur',
        description: error instanceof Error ? error.message : 'Une erreur est survenue',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const selectedGameData = getGameById(selectedGame);
  const selectedPlatformData = getPlatformById(selectedPlatform);
  const compatiblePlatforms = getCompatiblePlatforms(selectedGame);
  const gameRules = getGameRules(selectedGame);

  const handleGameSelect = (gameId: string) => {
    setSelectedGame(gameId);
    setSelectedPlatform('');
    setGameRulesData({});
  };

  const handleRuleChange = (ruleId: string, value: string) => {
    setGameRulesData((prev: any) => ({
      ...prev,
      [ruleId]: value
    }));
  };

  const getGamesByGenreFiltered = (genreId: string) => {
    return getGamesByGenre(genreId).filter(game => 
      selectedGenre === '' || game.genre === selectedGenre
    );
  };

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 lg:ml-64">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <Button
              onClick={() => router.back()}
              variant="outline"
              className="mb-4 border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
            <h1 className="text-3xl font-bold text-white">Créer un Pari</h1>
            <p className="text-gray-400 mt-2">
              Défiez d'autres joueurs et montrez vos compétences
            </p>
          </motion.div>

          {/* Progress */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-400'
                }`}>
                  1
                </div>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-400'
                }`}>
                  2
                </div>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-400'
                }`}>
                  3
                </div>
              </div>
            </div>
            <div className="text-sm text-gray-400">
              Étape {step} sur 3
            </div>
          </motion.div>

          <form onSubmit={handleSubmit}>
            {/* Étape 1: Sélection du jeu */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
              >
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Gamepad2 className="w-5 h-5 mr-2" />
                      Choisissez votre jeu
                    </CardTitle>
                    <CardDescription className="text-gray-400">
                      Sélectionnez le jeu sur lequel vous voulez défier d'autres joueurs
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Filtres par plateforme */}
                    <div className="mb-6">
                      <Label className="text-gray-300 mb-3 block">Filtrer par plateforme</Label>
                      <Tabs value={selectedGenre} onValueChange={setSelectedGenre} className="w-full">
                        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 bg-gray-700">
                          <TabsTrigger value="" className="text-xs">Toutes</TabsTrigger>
                          {PLATFORMS.map(platform => (
                            <TabsTrigger key={platform.id} value={platform.id} className="text-xs">
                              {platform.name.split(' ')[0]}
                            </TabsTrigger>
                          ))}
                        </TabsList>
                      </Tabs>
                    </div>

                    {/* Jeux par genre */}
                    <Accordion type="single" collapsible className="w-full">
                      {GENRES.map(genre => {
                        const gamesInGenre = getGamesByGenre(genre.id);
                        if (gamesInGenre.length === 0) return null;

                        return (
                          <AccordionItem key={genre.id} value={genre.id} className="border-gray-600">
                            <AccordionTrigger className="text-white hover:text-gray-300">
                              <div className="flex items-center space-x-2">
                                <span className="text-xl">{genre.icon}</span>
                                <span>{genre.name}</span>
                                <Badge variant="outline" className="ml-2">
                                  {gamesInGenre.length}
                                </Badge>
                              </div>
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 pt-4">
                                {gamesInGenre.map((game) => (
                                  <div
                                    key={game.id}
                                    onClick={() => handleGameSelect(game.id)}
                                    className={`cursor-pointer p-4 rounded-lg border-2 transition-all ${
                                      selectedGame === game.id
                                        ? 'border-blue-500 bg-blue-500/20'
                                        : 'border-gray-600 hover:border-gray-500 bg-gray-700/50'
                                    }`}
                                  >
                                    <div className="relative w-full h-16 mb-2">
                                      <Image
                                        src={game.logo}
                                        alt={game.name}
                                        fill
                                        className="object-contain"
                                      />
                                    </div>
                                    <div className="text-sm text-white text-center font-medium mb-1">
                                      {game.name}
                                    </div>
                                    <div className="flex flex-wrap gap-1 justify-center">
                                      {game.platforms.map(platformId => {
                                        const platform = getPlatformById(platformId);
                                        return (
                                          <Badge 
                                            key={platformId} 
                                            variant="outline" 
                                            className="text-xs"
                                          >
                                            {platform?.name.split(' ')[0]}
                                          </Badge>
                                        );
                                      })}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        );
                      })}
                    </Accordion>

                    <div className="mt-6 flex justify-end">
                      <Button
                        type="button"
                        onClick={() => setStep(2)}
                        disabled={!selectedGame}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        Suivant
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Étape 2: Paramètres */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
              >
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Paramètres du pari</CardTitle>
                    <CardDescription className="text-gray-400">
                      Définissez les conditions de votre défi
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <Label htmlFor="platform" className="text-gray-300">
                        Plateforme
                      </Label>
                      <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Choisir une plateforme" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {compatiblePlatforms.map(platform => (
                            <SelectItem key={platform.id} value={platform.id}>
                              {platform.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="amount" className="text-gray-300">
                        Montant du pari (€)
                      </Label>
                      <div className="relative">
                        <Euro className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="amount"
                          type="number"
                          min="1"
                          max="1000"
                          step="0.01"
                          placeholder="10.00"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                          required
                        />
                      </div>
                    </div>

                    {/* Règles spécifiques du jeu */}
                    {gameRules.length > 0 && (
                      <div>
                        <Label className="text-gray-300 flex items-center mb-3">
                          <Settings className="w-4 h-4 mr-2" />
                          Règles spécifiques - {selectedGameData?.name}
                        </Label>
                        <div className="bg-gray-700 rounded-lg p-4 space-y-4">
                          {gameRules.map(rule => (
                            <div key={rule.id}>
                              <Label className="text-gray-300 text-sm">
                                {rule.name}
                              </Label>
                              <p className="text-gray-400 text-xs mb-2">{rule.description}</p>
                              <Select 
                                value={gameRulesData[rule.id] || rule.defaultValue || ''}
                                onValueChange={(value) => handleRuleChange(rule.id, value)}
                              >
                                <SelectTrigger className="bg-gray-600 border-gray-500 text-white">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-gray-600 border-gray-500">
                                  {rule.options?.map(option => (
                                    <SelectItem key={option} value={option}>
                                      {option}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <Label htmlFor="rules" className="text-gray-300">
                        Règles personnalisées (optionnel)
                      </Label>
                      <Textarea
                        id="rules"
                        placeholder="Ajoutez des règles spéciales ou des conditions supplémentaires..."
                        value={customRules}
                        onChange={(e) => setCustomRules(e.target.value)}
                        className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                        rows={3}
                      />
                    </div>

                    <div className="flex justify-between">
                      <Button
                        type="button"
                        onClick={() => setStep(1)}
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-800"
                      >
                        Précédent
                      </Button>
                      <Button
                        type="button"
                        onClick={() => setStep(3)}
                        disabled={!selectedPlatform || !amount}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        Suivant
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Étape 3: Récapitulatif */}
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
              >
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Récapitulatif</CardTitle>
                    <CardDescription className="text-gray-400">
                      Vérifiez les détails de votre pari avant de le créer
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="bg-gray-700 rounded-lg p-4">
                      <div className="flex items-center space-x-4 mb-4">
                        {selectedGameData && (
                          <div className="relative w-16 h-16">
                            <Image
                              src={selectedGameData.logo}
                              alt={selectedGameData.name}
                              fill
                              className="object-contain rounded-lg"
                            />
                          </div>
                        )}
                        <div>
                          <h3 className="text-lg font-semibold text-white">
                            {selectedGameData?.name}
                          </h3>
                          <p className="text-gray-400">{selectedPlatformData?.name}</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Montant:</span>
                          <span className="text-white font-semibold">{amount}€</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Règles:</span>
                          <p className="text-white mt-1 text-sm">
                            {customRules.trim() || formatGameRules(selectedGame, gameRulesData)}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-yellow-900/20 border border-yellow-600 rounded-lg p-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <AlertCircle className="w-5 h-5 text-yellow-500" />
                        <span className="text-yellow-500 font-medium">Important</span>
                      </div>
                      <p className="text-gray-300 text-sm">
                        Le montant de {amount}€ sera bloqué dans votre portefeuille jusqu'à ce que le pari soit terminé.
                      </p>
                    </div>

                    <div className="flex justify-between">
                      <Button
                        type="button"
                        onClick={() => setStep(2)}
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-800"
                      >
                        Précédent
                      </Button>
                      <Button
                        type="submit"
                        disabled={isLoading}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        {isLoading ? 'Création...' : 'Créer le pari'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
