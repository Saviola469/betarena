
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Users, 
  Crown, 
  Shield, 
  User, 
  UserPlus, 
  Settings, 
  Trophy, 
  Target,
  MoreHorizontal,
  UserMinus
} from 'lucide-react';
import { motion } from 'framer-motion';
import { ExtendedClanMember } from '@/lib/types';

interface ClanMembersProps {
  clanId: string;
  canManage: boolean;
}

export default function ClanMembers({ clanId, canManage }: ClanMembersProps) {
  const { data: session } = useSession();
  const [members, setMembers] = useState<ExtendedClanMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [inviteUserId, setInviteUserId] = useState('');
  const [inviteRole, setInviteRole] = useState('MEMBER');
  const [showInviteDialog, setShowInviteDialog] = useState(false);

  const fetchMembers = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/clans/${clanId}/members`);
      const data = await response.json();

      if (response.ok) {
        setMembers(data);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des membres:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMembers();
  }, [clanId]);

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      const response = await fetch(`/api/clans/${clanId}/members/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ role: newRole }),
      });

      if (response.ok) {
        fetchMembers();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de la modification du rôle');
      }
    } catch (error) {
      alert('Erreur lors de la modification du rôle');
    }
  };

  const handleRemoveMember = async (userId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir expulser ce membre ?')) {
      return;
    }

    try {
      const response = await fetch(`/api/clans/${clanId}/members/${userId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchMembers();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'expulsion du membre');
      }
    } catch (error) {
      alert('Erreur lors de l\'expulsion du membre');
    }
  };

  const handleInviteMember = async () => {
    if (!inviteUserId.trim()) {
      alert('Veuillez entrer un ID utilisateur');
      return;
    }

    try {
      const response = await fetch(`/api/clans/${clanId}/members`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: inviteUserId,
          role: inviteRole,
        }),
      });

      if (response.ok) {
        setShowInviteDialog(false);
        setInviteUserId('');
        setInviteRole('MEMBER');
        fetchMembers();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'invitation');
      }
    } catch (error) {
      alert('Erreur lors de l\'invitation');
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'CAPTAIN':
        return <Crown className="h-4 w-4 text-yellow-400" />;
      case 'CO_LEADER':
        return <Shield className="h-4 w-4 text-blue-400" />;
      default:
        return <User className="h-4 w-4 text-gray-400" />;
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'CAPTAIN':
        return 'Capitaine';
      case 'CO_LEADER':
        return 'Co-leader';
      default:
        return 'Membre';
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'CAPTAIN':
        return 'bg-yellow-600';
      case 'CO_LEADER':
        return 'bg-blue-600';
      default:
        return 'bg-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
        <p className="text-gray-400">Chargement des membres...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">Membres ({members.length})</h2>
        </div>
        {canManage && (
          <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <UserPlus className="h-4 w-4 mr-2" />
                Inviter un membre
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-800 border-slate-700">
              <DialogHeader>
                <DialogTitle className="text-white">Inviter un nouveau membre</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="userId" className="text-white">
                    ID de l'utilisateur
                  </Label>
                  <Input
                    id="userId"
                    type="text"
                    placeholder="Entrez l'ID de l'utilisateur"
                    value={inviteUserId}
                    onChange={(e) => setInviteUserId(e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Rôle</Label>
                  <Select value={inviteRole} onValueChange={setInviteRole}>
                    <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MEMBER">Membre</SelectItem>
                      <SelectItem value="CO_LEADER">Co-leader</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setShowInviteDialog(false)}
                    className="flex-1 border-slate-600 text-white hover:bg-slate-700"
                  >
                    Annuler
                  </Button>
                  <Button
                    onClick={handleInviteMember}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    Inviter
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Members List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {members.map((member, index) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={member.user.avatar || undefined} alt={member.user.username} />
                      <AvatarFallback className="bg-purple-600 text-white">
                        {member.user.username.substring(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-white">{member.user.username}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className={getRoleBadgeColor(member.role)}>
                          <div className="flex items-center gap-1">
                            {getRoleIcon(member.role)}
                            <span className="text-xs">{getRoleLabel(member.role)}</span>
                          </div>
                        </Badge>
                        {member.user.country && (
                          <span className="text-xs text-gray-400">{member.user.country}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {canManage && member.user.id !== session?.user?.id && member.role !== 'CAPTAIN' && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-slate-800 border-slate-700">
                        <DialogHeader>
                          <DialogTitle className="text-white">Gérer le membre</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label className="text-white">Changer le rôle</Label>
                            <Select
                              value={member.role}
                              onValueChange={(value) => handleRoleChange(member.user.id, value)}
                            >
                              <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="MEMBER">Membre</SelectItem>
                                <SelectItem value="CO_LEADER">Co-leader</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button
                            onClick={() => handleRemoveMember(member.user.id)}
                            variant="outline"
                            className="w-full border-red-600 text-red-400 hover:bg-red-900/20"
                          >
                            <UserMinus className="h-4 w-4 mr-2" />
                            Expulser du clan
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Trophy className="h-3 w-3 text-gray-400" />
                      <span className="text-xs text-gray-400">Victoires</span>
                    </div>
                    <span className="text-white font-semibold">{member.wins}</span>
                  </div>
                  <div>
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Target className="h-3 w-3 text-gray-400" />
                      <span className="text-xs text-gray-400">Défaites</span>
                    </div>
                    <span className="text-white font-semibold">{member.losses}</span>
                  </div>
                  <div>
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <span className="text-xs text-gray-400">Taux</span>
                    </div>
                    <span className="text-white font-semibold">{member.winRate.toFixed(1)}%</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-700">
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <span>Membre depuis</span>
                    <span>{new Date(member.joinedAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-400 mt-1">
                    <span>Rang</span>
                    <span>#{member.user.rank}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {members.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">Aucun membre dans ce clan</p>
        </div>
      )}
    </div>
  );
}
