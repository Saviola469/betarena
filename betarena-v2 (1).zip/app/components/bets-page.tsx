
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import BetCard from '@/components/bet-card';
import Sidebar from '@/components/sidebar';
import { 
  GAMES, 
  PLATFORMS, 
  GENRES, 
  getGameById, 
  getPlatformById, 
  getGenreById,
  getGamesByGenre,
  getGamesByPlatform 
} from '@/lib/games';
import { Search, Filter, PlusCircle, Gamepad2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface BetsPageProps {
  bets: any[];
  currentUserId: string;
}

export default function BetsPage({ bets: initialBets, currentUserId }: BetsPageProps) {
  const [bets, setBets] = useState(initialBets);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGame, setSelectedGame] = useState('all');
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [activeTab, setActiveTab] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const filteredBets = bets.filter(bet => {
    const game = getGameById(bet.game);
    const matchesSearch = searchTerm === '' || 
      game?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bet.creator.username.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesGame = selectedGame === 'all' || bet.game === selectedGame;
    const matchesPlatform = selectedPlatform === 'all' || bet.platform === selectedPlatform;
    const matchesGenre = selectedGenre === 'all' || game?.genre === selectedGenre;
    
    return matchesSearch && matchesGame && matchesPlatform && matchesGenre;
  });

  const getBetsByGenre = (genreId: string) => {
    if (genreId === 'all') return filteredBets;
    return filteredBets.filter(bet => {
      const game = getGameById(bet.game);
      return game?.genre === genreId;
    });
  };

  const getBetsByPlatform = (platformId: string) => {
    if (platformId === 'all') return filteredBets;
    return filteredBets.filter(bet => bet.platform === platformId);
  };

  const handleJoinBet = async (betId: string) => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/bets/${betId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'join' }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erreur lors de la jointure du pari');
      }

      toast({
        title: 'Pari rejoint!',
        description: 'Vous avez rejoint le pari avec succès.',
      });

      // Mettre à jour la liste des paris
      const updatedBets = bets.filter(bet => bet.id !== betId);
      setBets(updatedBets);
    } catch (error) {
      toast({
        title: 'Erreur',
        description: error instanceof Error ? error.message : 'Une erreur est survenue',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewBet = (betId: string) => {
    router.push(`/bets/${betId}`);
  };

  const getGenreStats = (genreId: string) => {
    const genreBets = getBetsByGenre(genreId);
    return genreBets.length;
  };

  const getPlatformStats = (platformId: string) => {
    const platformBets = getBetsByPlatform(platformId);
    return platformBets.length;
  };

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-white">Parcourir les Paris</h1>
                <p className="text-gray-400 mt-2">
                  Trouvez le défi parfait et montrez vos compétences
                </p>
              </div>
              <Button
                onClick={() => router.push('/bets/create')}
                className="mt-4 sm:mt-0 bg-blue-600 hover:bg-blue-700 text-white"
              >
                <PlusCircle className="w-4 h-4 mr-2" />
                Créer un pari
              </Button>
            </div>
          </motion.div>

          {/* Navigation par genre/plateforme */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-8"
          >
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 bg-gray-800 border border-gray-700">
                <TabsTrigger value="all" className="text-white">
                  Tous les paris
                </TabsTrigger>
                <TabsTrigger value="genres" className="text-white">
                  Par genre
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="mt-6">
                {/* Filtres */}
                <div className="bg-gray-800 rounded-xl p-6 mb-8 border border-gray-700">
                  <div className="flex items-center space-x-2 mb-4">
                    <Filter className="w-5 h-5 text-gray-400" />
                    <h2 className="text-lg font-semibold text-white">Filtres</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Rechercher un jeu ou joueur..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      />
                    </div>
                    <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Tous les genres" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        <SelectItem value="all">Tous les genres</SelectItem>
                        {GENRES.map(genre => (
                          <SelectItem key={genre.id} value={genre.id}>
                            {genre.icon} {genre.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={selectedGame} onValueChange={setSelectedGame}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Tous les jeux" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        <SelectItem value="all">Tous les jeux</SelectItem>
                        {GAMES.map(game => (
                          <SelectItem key={game.id} value={game.id}>
                            {game.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Toutes les plateformes" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        <SelectItem value="all">Toutes les plateformes</SelectItem>
                        {PLATFORMS.map(platform => (
                          <SelectItem key={platform.id} value={platform.id}>
                            {platform.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Résultats */}
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-white">
                    Paris disponibles ({filteredBets.length})
                  </h2>
                </div>

                {filteredBets.length === 0 ? (
                  <div className="text-center py-12">
                    <Gamepad2 className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                    <div className="text-gray-400 text-lg mb-4">
                      Aucun pari trouvé avec ces critères
                    </div>
                    <Button
                      onClick={() => router.push('/bets/create')}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <PlusCircle className="w-4 h-4 mr-2" />
                      Créer le premier pari
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredBets.map((bet) => (
                      <BetCard
                        key={bet.id}
                        bet={bet}
                        onJoin={handleJoinBet}
                        onView={handleViewBet}
                        currentUserId={currentUserId}
                      />
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="genres" className="mt-6">
                <div className="space-y-8">
                  {GENRES.map(genre => {
                    const genreBets = getBetsByGenre(genre.id);
                    if (genreBets.length === 0) return null;

                    return (
                      <div key={genre.id} className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="text-xl font-semibold text-white flex items-center">
                            <span className="text-2xl mr-3">{genre.icon}</span>
                            {genre.name}
                            <Badge variant="outline" className="ml-3">
                              {genreBets.length}
                            </Badge>
                          </h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {genreBets.slice(0, 6).map((bet) => (
                            <BetCard
                              key={bet.id}
                              bet={bet}
                              onJoin={handleJoinBet}
                              onView={handleViewBet}
                              currentUserId={currentUserId}
                            />
                          ))}
                        </div>
                        {genreBets.length > 6 && (
                          <div className="mt-4 text-center">
                            <Button
                              variant="outline"
                              onClick={() => {
                                setSelectedGenre(genre.id);
                                setActiveTab('all');
                              }}
                              className="border-gray-600 text-gray-300 hover:bg-gray-700"
                            >
                              Voir tous les paris {genre.name.toLowerCase()}
                            </Button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
