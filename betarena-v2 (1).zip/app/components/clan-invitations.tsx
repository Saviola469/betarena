
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  UserPlus, 
  Mail, 
  Check, 
  X, 
  Clock, 
  Send,
  Trash2,
  Users
} from 'lucide-react';
import { motion } from 'framer-motion';
import { ExtendedClanInvitation } from '@/lib/types';

interface ClanInvitationsProps {
  clanId: string;
}

export default function ClanInvitations({ clanId }: ClanInvitationsProps) {
  const [invitations, setInvitations] = useState<ExtendedClanInvitation[]>([]);
  const [myInvitations, setMyInvitations] = useState<ExtendedClanInvitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [inviteForm, setInviteForm] = useState({
    receiverId: '',
    message: '',
  });

  const fetchInvitations = async () => {
    try {
      setLoading(true);
      const [clanInvitationsRes, myInvitationsRes] = await Promise.all([
        fetch(`/api/clans/${clanId}/invitations`),
        fetch('/api/clans/invitations/received'),
      ]);

      const clanInvitationsData = await clanInvitationsRes.json();
      const myInvitationsData = await myInvitationsRes.json();

      if (clanInvitationsRes.ok) {
        setInvitations(clanInvitationsData);
      }
      if (myInvitationsRes.ok) {
        setMyInvitations(myInvitationsData);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des invitations:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvitations();
  }, [clanId]);

  const handleSendInvitation = async () => {
    if (!inviteForm.receiverId.trim()) {
      alert('Veuillez entrer un ID utilisateur');
      return;
    }

    try {
      const response = await fetch(`/api/clans/${clanId}/invitations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(inviteForm),
      });

      if (response.ok) {
        setShowInviteDialog(false);
        setInviteForm({ receiverId: '', message: '' });
        fetchInvitations();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'envoi de l\'invitation');
      }
    } catch (error) {
      alert('Erreur lors de l\'envoi de l\'invitation');
    }
  };

  const handleInvitationAction = async (invitationId: string, action: 'accept' | 'decline') => {
    try {
      const response = await fetch(`/api/clans/${clanId}/invitations/${invitationId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action }),
      });

      if (response.ok) {
        fetchInvitations();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'action');
      }
    } catch (error) {
      alert('Erreur lors de l\'action');
    }
  };

  const handleDeleteInvitation = async (invitationId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette invitation ?')) {
      return;
    }

    try {
      const response = await fetch(`/api/clans/${clanId}/invitations/${invitationId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchInvitations();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de la suppression');
      }
    } catch (error) {
      alert('Erreur lors de la suppression');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <Badge variant="outline" className="text-yellow-400 border-yellow-400">En attente</Badge>;
      case 'ACCEPTED':
        return <Badge variant="outline" className="text-green-400 border-green-400">Acceptée</Badge>;
      case 'DECLINED':
        return <Badge variant="outline" className="text-red-400 border-red-400">Refusée</Badge>;
      case 'EXPIRED':
        return <Badge variant="outline" className="text-gray-400 border-gray-400">Expirée</Badge>;
      default:
        return <Badge variant="outline">Inconnu</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <Clock className="h-4 w-4 text-yellow-400" />;
      case 'ACCEPTED':
        return <Check className="h-4 w-4 text-green-400" />;
      case 'DECLINED':
        return <X className="h-4 w-4 text-red-400" />;
      case 'EXPIRED':
        return <Clock className="h-4 w-4 text-gray-400" />;
      default:
        return <Mail className="h-4 w-4 text-gray-400" />;
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
        <p className="text-gray-400">Chargement des invitations...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <UserPlus className="h-6 w-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">Invitations</h2>
        </div>
        <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Send className="h-4 w-4 mr-2" />
              Envoyer une invitation
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-800 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">Inviter un joueur</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="receiverId" className="text-white">
                  ID de l'utilisateur *
                </Label>
                <Input
                  id="receiverId"
                  type="text"
                  placeholder="Entrez l'ID de l'utilisateur"
                  value={inviteForm.receiverId}
                  onChange={(e) => setInviteForm({ ...inviteForm, receiverId: e.target.value })}
                  className="mt-2 bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="message" className="text-white">
                  Message personnel (optionnel)
                </Label>
                <Textarea
                  id="message"
                  placeholder="Écrivez un message pour accompagner votre invitation..."
                  value={inviteForm.message}
                  onChange={(e) => setInviteForm({ ...inviteForm, message: e.target.value })}
                  className="mt-2 bg-slate-700 border-slate-600 text-white"
                  rows={4}
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowInviteDialog(false)}
                  className="flex-1 border-slate-600 text-white hover:bg-slate-700"
                >
                  Annuler
                </Button>
                <Button
                  onClick={handleSendInvitation}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Envoyer
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="clan-invitations" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-slate-800/50 border-slate-700">
          <TabsTrigger value="clan-invitations" className="data-[state=active]:bg-blue-600">
            Invitations envoyées
          </TabsTrigger>
          <TabsTrigger value="my-invitations" className="data-[state=active]:bg-blue-600">
            Mes invitations reçues
          </TabsTrigger>
        </TabsList>

        <TabsContent value="clan-invitations" className="space-y-4">
          {invitations.length === 0 ? (
            <div className="text-center py-12">
              <UserPlus className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">Aucune invitation envoyée</p>
              <p className="text-gray-500 text-sm">Commencez par inviter des joueurs à rejoindre votre clan.</p>
            </div>
          ) : (
            invitations.map((invitation, index) => (
              <motion.div
                key={invitation.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className="bg-slate-700 p-2 rounded-lg">
                          {getStatusIcon(invitation.status)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={invitation.receiver.avatar || undefined} alt={invitation.receiver.username} />
                              <AvatarFallback className="bg-purple-600 text-white text-xs">
                                {invitation.receiver.username.substring(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h3 className="font-semibold text-white">{invitation.receiver.username}</h3>
                              <p className="text-sm text-gray-400">
                                Invité par {invitation.sender.username}
                              </p>
                            </div>
                          </div>
                          
                          {invitation.message && (
                            <div className="bg-slate-700/30 p-3 rounded-lg mb-3">
                              <p className="text-sm text-gray-300">{invitation.message}</p>
                            </div>
                          )}
                          
                          <div className="flex items-center gap-4 text-sm text-gray-400">
                            <span>Envoyée le {new Date(invitation.createdAt).toLocaleDateString()}</span>
                            {invitation.expiresAt && (
                              <span>
                                Expire le {new Date(invitation.expiresAt).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {getStatusBadge(invitation.status)}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteInvitation(invitation.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          )}
        </TabsContent>

        <TabsContent value="my-invitations" className="space-y-4">
          {myInvitations.length === 0 ? (
            <div className="text-center py-12">
              <Mail className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">Aucune invitation reçue</p>
              <p className="text-gray-500 text-sm">Vous n'avez reçu aucune invitation de clan pour le moment.</p>
            </div>
          ) : (
            myInvitations.map((invitation, index) => (
              <motion.div
                key={invitation.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={invitation.clan.logo || undefined} alt={invitation.clan.name} />
                          <AvatarFallback className="bg-blue-600 text-white">
                            {invitation.clan.tag || invitation.clan.name.substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-white">{invitation.clan.name}</h3>
                            <Badge variant="outline">[{invitation.clan.tag}]</Badge>
                            <Badge variant={invitation.clan.clanType === 'PUBLIC' ? 'default' : 'secondary'}>
                              {invitation.clan.clanType === 'PUBLIC' ? 'Public' : 'Privé'}
                            </Badge>
                          </div>
                          
                          <div className="flex items-center gap-4 text-sm text-gray-400 mb-2">
                            <div className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              <span>{invitation.clan.memberCount} membres</span>
                            </div>
                            <span>{invitation.clan.platform}</span>
                          </div>
                          
                          {invitation.message && (
                            <div className="bg-slate-700/30 p-3 rounded-lg mb-3">
                              <p className="text-sm text-gray-300">{invitation.message}</p>
                            </div>
                          )}
                          
                          <div className="flex items-center gap-4 text-sm text-gray-400">
                            <span>De {invitation.sender.username}</span>
                            <span>Reçue le {new Date(invitation.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {invitation.status === 'PENDING' ? (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => handleInvitationAction(invitation.id, 'accept')}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <Check className="h-4 w-4 mr-1" />
                              Accepter
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleInvitationAction(invitation.id, 'decline')}
                              className="border-red-600 text-red-400 hover:bg-red-900/20"
                            >
                              <X className="h-4 w-4 mr-1" />
                              Refuser
                            </Button>
                          </div>
                        ) : (
                          getStatusBadge(invitation.status)
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
