
'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Swords, X, GamepadIcon, Euro, MessageCircle, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { GAMES } from '@/lib/games';

interface ChallengeModalProps {
  receiverId: string;
  receiverUsername: string;
  onClose: () => void;
}

export default function ChallengeModal({ receiverId, receiverUsername, onClose }: ChallengeModalProps) {
  const { data: session } = useSession();
  const [formData, setFormData] = useState({
    game: '',
    platform: '',
    amount: '',
    rules: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const platforms = [
    { value: 'ps5', label: 'PlayStation 5' },
    { value: 'ps4', label: 'PlayStation 4' },
    { value: 'xbox', label: 'Xbox' },
    { value: 'pc', label: 'PC' },
    { value: 'switch', label: 'Nintendo Switch' }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      // Validation
      if (!formData.game || !formData.platform || !formData.amount) {
        setError('Veuillez remplir tous les champs obligatoires');
        setIsSubmitting(false);
        return;
      }

      const amount = parseFloat(formData.amount);
      if (isNaN(amount) || amount <= 0) {
        setError('Le montant doit être un nombre positif');
        setIsSubmitting(false);
        return;
      }

      if (amount > 1000) {
        setError('Le montant maximum est de 1000€');
        setIsSubmitting(false);
        return;
      }

      const response = await fetch('/api/challenges', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receiverId,
          game: formData.game,
          platform: formData.platform,
          amount,
          rules: formData.rules,
          message: formData.message
        })
      });

      if (response.ok) {
        // Défi créé avec succès
        onClose();
        // Afficher un message de succès (vous pourriez ajouter un toast ici)
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Erreur lors de la création du défi');
      }
    } catch (error) {
      console.error('Erreur lors de la création du défi:', error);
      setError('Erreur lors de la création du défi');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (error) setError(null);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center text-xl">
            <Swords className="w-6 h-6 mr-3 text-orange-500" />
            Défier {receiverUsername}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Sélection du jeu */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-300">
              Jeu <span className="text-red-500">*</span>
            </Label>
            <Select 
              value={formData.game} 
              onValueChange={(value) => handleInputChange('game', value)}
            >
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <GamepadIcon className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Choisir un jeu" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {GAMES.map(game => (
                  <SelectItem key={game.id} value={game.id}>
                    {game.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Sélection de la plateforme */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-300">
              Plateforme <span className="text-red-500">*</span>
            </Label>
            <Select 
              value={formData.platform} 
              onValueChange={(value) => handleInputChange('platform', value)}
            >
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Choisir une plateforme" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {platforms.map(platform => (
                  <SelectItem key={platform.value} value={platform.value}>
                    {platform.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Montant */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-300">
              Montant du pari <span className="text-red-500">*</span>
            </Label>
            <div className="relative">
              <Euro className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="number"
                min="1"
                max="1000"
                step="0.01"
                placeholder="25.00"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            <p className="text-xs text-gray-500">
              Montant entre 1€ et 1000€
            </p>
          </div>

          {/* Règles */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-300">
              Règles du match
            </Label>
            <Textarea
              placeholder="Ex: Best of 3, 6 minutes par mi-temps, pas d'objets..."
              value={formData.rules}
              onChange={(e) => handleInputChange('rules', e.target.value)}
              className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              rows={3}
            />
          </div>

          {/* Message */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-300">
              Message personnel
            </Label>
            <div className="relative">
              <MessageCircle className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
              <Textarea
                placeholder="Ajouter un message à votre défi..."
                value={formData.message}
                onChange={(e) => handleInputChange('message', e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                rows={2}
              />
            </div>
          </div>

          {/* Affichage des erreurs */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center space-x-2 p-3 bg-red-900/20 border border-red-500/20 rounded-lg"
            >
              <AlertCircle className="w-5 h-5 text-red-500" />
              <span className="text-red-400 text-sm">{error}</span>
            </motion.div>
          )}

          {/* Récapitulatif */}
          {formData.game && formData.platform && formData.amount && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-gray-750 rounded-lg border border-gray-600"
            >
              <h4 className="font-semibold text-white mb-2">Récapitulatif du défi</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Jeu:</span>
                  <span className="text-white">
                    {GAMES.find(g => g.id === formData.game)?.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Plateforme:</span>
                  <span className="text-white">
                    {platforms.find(p => p.value === formData.platform)?.label}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Montant:</span>
                  <span className="text-green-500 font-semibold">
                    {formData.amount}€
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Adversaire:</span>
                  <span className="text-white">{receiverUsername}</span>
                </div>
              </div>
            </motion.div>
          )}

          {/* Boutons */}
          <div className="flex items-center space-x-3 pt-4">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 bg-orange-600 hover:bg-orange-700 text-white"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Envoi...
                </>
              ) : (
                <>
                  <Swords className="w-4 h-4 mr-2" />
                  Envoyer le défi
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
              className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
            >
              Annuler
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
