
'use client';

import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  MessageCircle, 
  Send, 
  Crown, 
  Shield, 
  User,
  Info,
  Trophy,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ExtendedClanMessage } from '@/lib/types';

interface ClanChatProps {
  clanId: string;
}

export default function ClanChat({ clanId }: ClanChatProps) {
  const { data: session } = useSession();
  const [messages, setMessages] = useState<ExtendedClanMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/clans/${clanId}/messages`);
      const data = await response.json();

      if (response.ok) {
        setMessages(data.messages || []);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des messages:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessages();
    
    // Polling pour les nouveaux messages (toutes les 5 secondes)
    const interval = setInterval(fetchMessages, 5000);
    
    return () => clearInterval(interval);
  }, [clanId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || sending) {
      return;
    }

    setSending(true);

    try {
      const response = await fetch(`/api/clans/${clanId}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: newMessage.trim(),
        }),
      });

      if (response.ok) {
        setNewMessage('');
        fetchMessages(); // Actualiser les messages
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'envoi du message');
      }
    } catch (error) {
      alert('Erreur lors de l\'envoi du message');
    } finally {
      setSending(false);
    }
  };

  const getRoleIcon = (role: string | null) => {
    switch (role) {
      case 'CAPTAIN':
        return <Crown className="h-3 w-3 text-yellow-400" />;
      case 'CO_LEADER':
        return <Shield className="h-3 w-3 text-blue-400" />;
      default:
        return <User className="h-3 w-3 text-gray-400" />;
    }
  };

  const getMessageIcon = (type: string) => {
    switch (type) {
      case 'SYSTEM':
        return <Info className="h-4 w-4 text-blue-400" />;
      case 'MATCH_RESULT':
        return <Trophy className="h-4 w-4 text-yellow-400" />;
      default:
        return null;
    }
  };

  const getMessageStyle = (type: string) => {
    switch (type) {
      case 'SYSTEM':
        return 'bg-blue-900/20 border-blue-800';
      case 'MATCH_RESULT':
        return 'bg-yellow-900/20 border-yellow-800';
      default:
        return 'bg-slate-700/30 border-slate-600';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `${days}j`;
    } else if (hours > 0) {
      return `${hours}h`;
    } else if (minutes > 0) {
      return `${minutes}m`;
    } else {
      return 'maintenant';
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
        <p className="text-gray-400">Chargement du chat...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <MessageCircle className="h-6 w-6 text-blue-400" />
        <h2 className="text-xl font-bold text-white">Chat du clan</h2>
      </div>

      {/* Chat Container */}
      <Card className="bg-slate-800/50 border-slate-700 h-[600px] flex flex-col">
        <CardHeader className="pb-4">
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="h-5 w-5" />
            Discussion générale
          </CardTitle>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col p-4">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-4 mb-4">
            <AnimatePresence>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-3 rounded-lg border ${getMessageStyle(message.messageType)}`}
                >
                  <div className="flex items-start gap-3">
                    {message.messageType === 'TEXT' ? (
                      <Avatar className="h-8 w-8 mt-1">
                        <AvatarImage src={message.sender.avatar || undefined} alt={message.sender.username} />
                        <AvatarFallback className="bg-purple-600 text-white text-xs">
                          {message.sender.username.substring(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                    ) : (
                      <div className="bg-slate-600 p-2 rounded-full mt-1">
                        {getMessageIcon(message.messageType)}
                      </div>
                    )}
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-white text-sm">
                          {message.sender.username}
                        </span>
                        {message.sender.clanRole && (
                          <div className="flex items-center gap-1">
                            {getRoleIcon(message.sender.clanRole)}
                          </div>
                        )}
                        <span className="text-xs text-gray-400">
                          {formatTimestamp(message.createdAt.toString())}
                        </span>
                        {message.editedAt && (
                          <Badge variant="secondary" className="text-xs">
                            modifié
                          </Badge>
                        )}
                      </div>
                      <p className="text-gray-300 text-sm break-words">
                        {message.content}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            {messages.length === 0 && (
              <div className="text-center py-12">
                <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400 text-lg">Aucun message dans ce chat</p>
                <p className="text-gray-500 text-sm">Soyez le premier à envoyer un message !</p>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              type="text"
              placeholder="Tapez votre message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              className="flex-1 bg-slate-700 border-slate-600 text-white"
              maxLength={1000}
            />
            <Button
              type="submit"
              disabled={!newMessage.trim() || sending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {sending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </form>
          
          <p className="text-xs text-gray-400 mt-2">
            {newMessage.length}/1000 caractères
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
