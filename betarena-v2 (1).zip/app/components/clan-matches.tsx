
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Swords, 
  Plus, 
  Calendar, 
  Trophy, 
  Target,
  Clock,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  Filter
} from 'lucide-react';
import { motion } from 'framer-motion';
import { ExtendedClanMatch } from '@/lib/types';
import { GAMES } from '@/lib/games';

interface ClanMatchesProps {
  clanId: string;
  canManage: boolean;
}

const PLATFORMS = [
  { value: 'all', label: 'Toutes' },
  { value: 'PS5', label: 'PlayStation 5' },
  { value: 'XBOX', label: 'Xbox Series X/S' },
  { value: 'PC', label: 'PC' },
  { value: 'SWITCH', label: 'Nintendo Switch' },
  { value: 'PS4', label: 'PlayStation 4' },
];

const STATUS_FILTERS = [
  { value: 'all', label: 'Tous' },
  { value: 'PENDING', label: 'En attente' },
  { value: 'ACCEPTED', label: 'Accepté' },
  { value: 'ACTIVE', label: 'En cours' },
  { value: 'COMPLETED', label: 'Terminé' },
  { value: 'CANCELLED', label: 'Annulé' },
];

export default function ClanMatches({ clanId, canManage }: ClanMatchesProps) {
  const [matches, setMatches] = useState<ExtendedClanMatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [gameFilter, setGameFilter] = useState('all');
  const [platformFilter, setPlatformFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [newMatch, setNewMatch] = useState({
    opponentClanId: '',
    game: '',
    platform: '',
    matchType: 'CHALLENGE',
    format: '1v1',
    amount: 0,
    rules: '',
    scheduledAt: '',
  });

  const fetchMatches = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (gameFilter !== 'all') params.append('game', gameFilter);
      if (platformFilter !== 'all') params.append('platform', platformFilter);
      if (statusFilter !== 'all') params.append('status', statusFilter);
      
      const response = await fetch(`/api/clans/${clanId}/matches?${params}`);
      const data = await response.json();

      if (response.ok) {
        setMatches(data.matches || []);
      }
    } catch (error) {
      console.error('Erreur lors du chargement des matchs:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMatches();
  }, [clanId, gameFilter, platformFilter, statusFilter]);

  const handleCreateMatch = async () => {
    try {
      const response = await fetch(`/api/clans/${clanId}/matches`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newMatch),
      });

      if (response.ok) {
        setShowCreateDialog(false);
        setNewMatch({
          opponentClanId: '',
          game: '',
          platform: '',
          matchType: 'CHALLENGE',
          format: '1v1',
          amount: 0,
          rules: '',
          scheduledAt: '',
        });
        fetchMatches();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de la création du match');
      }
    } catch (error) {
      alert('Erreur lors de la création du match');
    }
  };

  const handleMatchAction = async (matchId: string, action: string, data?: any) => {
    try {
      const response = await fetch(`/api/clans/matches/${matchId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action, ...data }),
      });

      if (response.ok) {
        fetchMatches();
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'action');
      }
    } catch (error) {
      alert('Erreur lors de l\'action');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <Badge variant="outline" className="text-yellow-400 border-yellow-400">En attente</Badge>;
      case 'ACCEPTED':
        return <Badge variant="outline" className="text-blue-400 border-blue-400">Accepté</Badge>;
      case 'ACTIVE':
        return <Badge variant="outline" className="text-green-400 border-green-400">En cours</Badge>;
      case 'COMPLETED':
        return <Badge variant="outline" className="text-purple-400 border-purple-400">Terminé</Badge>;
      case 'CANCELLED':
        return <Badge variant="outline" className="text-red-400 border-red-400">Annulé</Badge>;
      default:
        return <Badge variant="outline">Inconnu</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <Clock className="h-4 w-4 text-yellow-400" />;
      case 'ACCEPTED':
        return <CheckCircle className="h-4 w-4 text-blue-400" />;
      case 'ACTIVE':
        return <Play className="h-4 w-4 text-green-400" />;
      case 'COMPLETED':
        return <Trophy className="h-4 w-4 text-purple-400" />;
      case 'CANCELLED':
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return <Target className="h-4 w-4 text-gray-400" />;
    }
  };

  const getGameIcon = (game: string) => {
    const gameObj = GAMES.find(g => g.id === game);
    if (!gameObj) return '🎮';
    
    // Utiliser l'icône du genre
    const genre = gameObj.genre;
    switch (genre) {
      case 'fighting':
        return '🥊';
      case 'fps':
        return '🎯';
      case 'sports':
        return '⚽';
      case 'racing':
        return '🏎️';
      case 'party':
        return '🎉';
      case 'moba':
        return '🏰';
      case 'strategy':
        return '♟️';
      default:
        return '🎮';
    }
  };

  const getGameName = (game: string) => {
    const gameObj = GAMES.find(g => g.id === game);
    return gameObj?.name || game;
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
        <p className="text-gray-400">Chargement des matchs...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Swords className="h-6 w-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">Matchs du clan</h2>
        </div>
        {canManage && (
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Créer un match
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-white">Créer un nouveau match</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Clan adversaire (ID)</Label>
                    <Input
                      type="text"
                      placeholder="ID du clan adversaire"
                      value={newMatch.opponentClanId}
                      onChange={(e) => setNewMatch({ ...newMatch, opponentClanId: e.target.value })}
                      className="mt-2 bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-white">Jeu</Label>
                    <Select value={newMatch.game} onValueChange={(value) => setNewMatch({ ...newMatch, game: value })}>
                      <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Sélectionnez un jeu" />
                      </SelectTrigger>
                      <SelectContent>
                        {GAMES.map(game => (
                          <SelectItem key={game.id} value={game.id}>
                            <div className="flex items-center gap-2">
                              <span>{getGameIcon(game.id)}</span>
                              <span>{game.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-white">Plateforme</Label>
                    <Select value={newMatch.platform} onValueChange={(value) => setNewMatch({ ...newMatch, platform: value })}>
                      <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Sélectionnez une plateforme" />
                      </SelectTrigger>
                      <SelectContent>
                        {PLATFORMS.slice(1).map(platform => (
                          <SelectItem key={platform.value} value={platform.value}>
                            {platform.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-white">Format</Label>
                    <Select value={newMatch.format} onValueChange={(value) => setNewMatch({ ...newMatch, format: value })}>
                      <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1v1">1v1</SelectItem>
                        <SelectItem value="2v2">2v2</SelectItem>
                        <SelectItem value="3v3">3v3</SelectItem>
                        <SelectItem value="5v5">5v5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Mise (€)</Label>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={newMatch.amount}
                      onChange={(e) => setNewMatch({ ...newMatch, amount: parseFloat(e.target.value) || 0 })}
                      className="mt-2 bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-white">Date programmée (optionnel)</Label>
                    <Input
                      type="datetime-local"
                      value={newMatch.scheduledAt}
                      onChange={(e) => setNewMatch({ ...newMatch, scheduledAt: e.target.value })}
                      className="mt-2 bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-white">Règles (optionnel)</Label>
                  <Textarea
                    placeholder="Règles spécifiques du match..."
                    value={newMatch.rules}
                    onChange={(e) => setNewMatch({ ...newMatch, rules: e.target.value })}
                    className="mt-2 bg-slate-700 border-slate-600 text-white"
                    rows={3}
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setShowCreateDialog(false)}
                    className="flex-1 border-slate-600 text-white hover:bg-slate-700"
                  >
                    Annuler
                  </Button>
                  <Button
                    onClick={handleCreateMatch}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    disabled={!newMatch.opponentClanId || !newMatch.game || !newMatch.platform}
                  >
                    Créer le match
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtres
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="text-white">Jeu</Label>
              <Select value={gameFilter} onValueChange={setGameFilter}>
                <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les jeux</SelectItem>
                  {GAMES.map(game => (
                    <SelectItem key={game.id} value={game.id}>
                      <div className="flex items-center gap-2">
                        <span>{getGameIcon(game.id)}</span>
                        <span>{game.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-white">Plateforme</Label>
              <Select value={platformFilter} onValueChange={setPlatformFilter}>
                <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PLATFORMS.map(platform => (
                    <SelectItem key={platform.value} value={platform.value}>
                      {platform.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-white">Statut</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="mt-2 bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_FILTERS.map(status => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Matches List */}
      <div className="space-y-4">
        {matches.map((match, index) => (
          <motion.div
            key={match.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-colors">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-slate-700 p-2 rounded-lg">
                      {getStatusIcon(match.status)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getGameIcon(match.game)}</span>
                        <h3 className="font-semibold text-white">{getGameName(match.game)}</h3>
                        <Badge variant="outline">{match.format}</Badge>
                      </div>
                      <p className="text-sm text-gray-400">{match.platform}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getStatusBadge(match.status)}
                    {match.amount > 0 && (
                      <Badge className="bg-green-600">
                        {match.amount}€
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={match.clanA.logo || undefined} alt={match.clanA.name} />
                        <AvatarFallback className="bg-blue-600 text-white text-xs">
                          {match.clanA.tag}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-white font-medium">{match.clanA.name}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-gray-400">vs</span>
                      {match.status === 'COMPLETED' && (
                        <div className="flex items-center gap-1 text-sm">
                          <span className="text-white">{match.scoreA}</span>
                          <span className="text-gray-400">-</span>
                          <span className="text-white">{match.scoreB}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={match.clanB.logo || undefined} alt={match.clanB.name} />
                        <AvatarFallback className="bg-purple-600 text-white text-xs">
                          {match.clanB.tag}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-white font-medium">{match.clanB.name}</span>
                    </div>
                  </div>
                  
                  {match.winner && (
                    <div className="flex items-center gap-2">
                      <Trophy className="h-4 w-4 text-yellow-400" />
                      <span className="text-yellow-400 font-medium">
                        {match.winner.name} a gagné !
                      </span>
                    </div>
                  )}
                </div>

                {match.rules && (
                  <div className="mb-4 p-3 bg-slate-700/30 rounded-lg">
                    <p className="text-sm text-gray-300">{match.rules}</p>
                  </div>
                )}

                <div className="flex items-center justify-between text-sm text-gray-400">
                  <div className="flex items-center gap-4">
                    <span>Créé le {new Date(match.createdAt).toLocaleDateString()}</span>
                    {match.scheduledAt && (
                      <span>Programmé le {new Date(match.scheduledAt).toLocaleString()}</span>
                    )}
                  </div>
                  
                  {canManage && match.status === 'PENDING' && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleMatchAction(match.id, 'accept')}
                        className="border-green-600 text-green-400 hover:bg-green-900/20"
                      >
                        Accepter
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleMatchAction(match.id, 'decline')}
                        className="border-red-600 text-red-400 hover:bg-red-900/20"
                      >
                        Refuser
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {matches.length === 0 && (
        <div className="text-center py-12">
          <Swords className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">Aucun match trouvé</p>
          <p className="text-gray-500 text-sm">
            {canManage ? 'Créez le premier match pour votre clan !' : 'Aucun match disponible pour le moment.'}
          </p>
        </div>
      )}
    </div>
  );
}
