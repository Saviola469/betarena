
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Trophy, Users, Calendar, Filter, Plus, Search, Crown, Target } from 'lucide-react';
import { ExtendedTournament } from '@/lib/types';
import { GAMES } from '@/lib/games';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default function TournamentsPage() {
  const { data: session } = useSession();
  const [tournaments, setTournaments] = useState<ExtendedTournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGame, setSelectedGame] = useState('all');
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('OPEN');

  useEffect(() => {
    fetchTournaments();
  }, [selectedGame, selectedPlatform, selectedStatus]);

  const fetchTournaments = async () => {
    try {
      const params = new URLSearchParams({
        game: selectedGame,
        platform: selectedPlatform,
        status: selectedStatus,
      });

      const response = await fetch(`/api/tournaments?${params}`);
      if (response.ok) {
        const data = await response.json();
        setTournaments(data);
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des tournois:', error);
    } finally {
      setLoading(false);
    }
  };

  const joinTournament = async (tournamentId: string) => {
    try {
      const response = await fetch(`/api/tournaments/${tournamentId}/join`, {
        method: 'POST',
      });

      if (response.ok) {
        fetchTournaments();
      } else {
        const error = await response.json();
        alert(error.error || 'Erreur lors de l\'inscription');
      }
    } catch (error) {
      console.error('Erreur lors de l\'inscription:', error);
      alert('Erreur lors de l\'inscription');
    }
  };

  const filteredTournaments = tournaments.filter(tournament =>
    tournament.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tournament.game.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN': return 'bg-green-500';
      case 'ACTIVE': return 'bg-blue-500';
      case 'COMPLETED': return 'bg-gray-500';
      case 'CANCELLED': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'OPEN': return 'Ouvert';
      case 'ACTIVE': return 'En cours';
      case 'COMPLETED': return 'Terminé';
      case 'CANCELLED': return 'Annulé';
      default: return status;
    }
  };

  const getGameDisplayName = (gameId: string) => {
    const game = GAMES.find((g: any) => g.id === gameId);
    return game?.name || gameId;
  };

  const isParticipating = (tournament: ExtendedTournament) => {
    return tournament.participants.some(p => p.userId === session?.user?.id);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center text-white">Chargement des tournois...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-8"
        >
          <div className="flex items-center gap-3">
            <Trophy className="w-8 h-8 text-yellow-400" />
            <h1 className="text-3xl font-bold text-white">Tournois</h1>
          </div>
          <Link href="/tournaments/create">
            <Button className="bg-blue-600 hover:bg-blue-700 gap-2">
              <Plus className="w-4 h-4" />
              Créer un tournoi
            </Button>
          </Link>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-blue-400" />
                <CardTitle className="text-white">Filtres</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Rechercher un tournoi..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <Select value={selectedGame} onValueChange={setSelectedGame}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Sélectionner un jeu" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les jeux</SelectItem>
                    {GAMES.map((game: any) => (
                      <SelectItem key={game.id} value={game.id}>
                        {game.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Sélectionner une plateforme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes les plateformes</SelectItem>
                    <SelectItem value="ps5">PlayStation 5</SelectItem>
                    <SelectItem value="ps4">PlayStation 4</SelectItem>
                    <SelectItem value="xbox">Xbox</SelectItem>
                    <SelectItem value="pc">PC</SelectItem>
                    <SelectItem value="switch">Nintendo Switch</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Statut" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="OPEN">Ouvert</SelectItem>
                    <SelectItem value="ACTIVE">En cours</SelectItem>
                    <SelectItem value="COMPLETED">Terminé</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Tournaments Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTournaments.map((tournament, index) => (
            <motion.div
              key={tournament.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-slate-800 border-slate-700 hover:bg-slate-750 transition-colors">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-white text-lg mb-2">
                        {tournament.name}
                      </CardTitle>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={`${getStatusColor(tournament.status)} text-white`}>
                          {getStatusText(tournament.status)}
                        </Badge>
                        {tournament.isPrivate && (
                          <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                            Privé
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Trophy className="w-6 h-6 text-yellow-400" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-blue-400" />
                    <span className="text-gray-300">{getGameDisplayName(tournament.game)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-green-400" />
                    <span className="text-gray-300">
                      {tournament.participants.length}/{tournament.maxParticipants} participants
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Crown className="w-4 h-4 text-purple-400" />
                    <span className="text-gray-300">
                      Frais: {tournament.entryFee > 0 ? `${tournament.entryFee}€` : 'Gratuit'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={tournament.creator.avatar || undefined} />
                      <AvatarFallback>{tournament.creator.username[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-gray-300">Par {tournament.creator.username}</span>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Link href={`/tournaments/${tournament.id}`} className="flex-1">
                      <Button variant="outline" className="w-full">
                        Voir détails
                      </Button>
                    </Link>
                    {tournament.status === 'OPEN' && !isParticipating(tournament) && (
                      <Button
                        onClick={() => joinTournament(tournament.id)}
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={tournament.participants.length >= tournament.maxParticipants}
                      >
                        {tournament.participants.length >= tournament.maxParticipants ? 'Complet' : 'Rejoindre'}
                      </Button>
                    )}
                    {isParticipating(tournament) && (
                      <Badge className="bg-green-600 text-white px-3 py-1">
                        Inscrit
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {filteredTournaments.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Trophy className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-300 mb-2">
              Aucun tournoi trouvé
            </h3>
            <p className="text-gray-400 mb-4">
              Aucun tournoi ne correspond à vos critères de recherche.
            </p>
            <Link href="/tournaments/create">
              <Button className="bg-blue-600 hover:bg-blue-700">
                Créer le premier tournoi
              </Button>
            </Link>
          </motion.div>
        )}
      </div>
    </div>
  );
}
