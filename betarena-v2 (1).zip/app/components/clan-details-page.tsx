
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Shield, 
  Users, 
  Trophy, 
  Target, 
  Crown,
  Settings,
  UserPlus,
  MessageCircle,
  Swords,
  ArrowLeft,
  Globe,
  Lock,
  Calendar,
  DollarSign,
  TrendingUp,
  Activity
} from 'lucide-react';
import { motion } from 'framer-motion';
import { ExtendedClan } from '@/lib/types';
import ClanMembers from '@/components/clan-members';
import ClanChat from '@/components/clan-chat';
import ClanMatches from '@/components/clan-matches';
import ClanInvitations from '@/components/clan-invitations';

interface ClanDetailsPageProps {
  clanId: string;
}

export default function ClanDetailsPage({ clanId }: ClanDetailsPageProps) {
  const { data: session } = useSession();
  const [clan, setClan] = useState<ExtendedClan | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const router = useRouter();

  const fetchClan = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/clans/${clanId}`);
      const data = await response.json();

      if (response.ok) {
        setClan(data);
      } else {
        setError(data.error || 'Erreur lors du chargement du clan');
      }
    } catch (error) {
      setError('Erreur lors du chargement du clan');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClan();
  }, [clanId]);

  const joinClan = async () => {
    try {
      const response = await fetch(`/api/clans/${clanId}/join`, {
        method: 'POST',
      });

      if (response.ok) {
        fetchClan(); // Refresh clan data
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de l\'adhésion au clan');
      }
    } catch (error) {
      alert('Erreur lors de l\'adhésion au clan');
    }
  };

  const leaveClan = async () => {
    if (!confirm('Êtes-vous sûr de vouloir quitter ce clan ?')) {
      return;
    }

    try {
      const response = await fetch(`/api/clans/${clanId}/leave`, {
        method: 'POST',
      });

      if (response.ok) {
        router.push('/clans');
      } else {
        const data = await response.json();
        alert(data.error || 'Erreur lors de la sortie du clan');
      }
    } catch (error) {
      alert('Erreur lors de la sortie du clan');
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'PS5':
      case 'PS4':
        return '🎮';
      case 'XBOX':
        return '🎮';
      case 'PC':
        return '💻';
      case 'SWITCH':
        return '🎮';
      default:
        return '🎮';
    }
  };

  const isUserMember = clan?.members?.some(member => member.id === session?.user?.id);
  const userRole = clan?.memberships?.find(m => m.user.id === session?.user?.id)?.role;
  const canManage = userRole === 'CAPTAIN' || userRole === 'CO_LEADER';

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-white">Chargement du clan...</p>
        </div>
      </div>
    );
  }

  if (error || !clan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Shield className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <p className="text-white text-lg mb-4">{error || 'Clan non trouvé'}</p>
          <Button onClick={() => router.push('/clans')} className="bg-blue-600 hover:bg-blue-700">
            Retour aux clans
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            variant="ghost"
            onClick={() => router.push('/clans')}
            className="text-white hover:bg-slate-800 mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour aux clans
          </Button>
        </motion.div>

        {/* Clan Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                <div className="flex items-center gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={clan.logo || undefined} alt={clan.name} />
                    <AvatarFallback className="bg-blue-600 text-white text-xl">
                      {clan.tag || clan.name.substring(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h1 className="text-3xl font-bold text-white">{clan.name}</h1>
                      <Badge variant="outline" className="text-blue-400 border-blue-400">
                        [{clan.tag}]
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-300">
                      <div className="flex items-center gap-1">
                        {clan.clanType === 'PUBLIC' ? (
                          <Globe className="h-4 w-4" />
                        ) : (
                          <Lock className="h-4 w-4" />
                        )}
                        <span>{clan.clanType === 'PUBLIC' ? 'Public' : 'Privé'}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-lg">{getPlatformIcon(clan.platform)}</span>
                        <span>{clan.platform}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        <span>Créé le {new Date(clan.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex-1" />

                <div className="flex items-center gap-3">
                  {!isUserMember && clan.clanType === 'PUBLIC' && (
                    <Button onClick={joinClan} className="bg-blue-600 hover:bg-blue-700">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Rejoindre
                    </Button>
                  )}
                  {isUserMember && (
                    <Button
                      variant="outline"
                      onClick={leaveClan}
                      className="border-red-600 text-red-400 hover:bg-red-900/20"
                    >
                      Quitter le clan
                    </Button>
                  )}
                  {canManage && (
                    <Button variant="outline" className="border-slate-600 text-white hover:bg-slate-700">
                      <Settings className="h-4 w-4 mr-2" />
                      Gérer
                    </Button>
                  )}
                </div>
              </div>

              {clan.description && (
                <div className="mt-6 pt-6 border-t border-slate-700">
                  <p className="text-gray-300">{clan.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
        >
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="bg-blue-600/20 p-2 rounded-lg">
                  <Users className="h-6 w-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Membres</p>
                  <p className="text-2xl font-bold text-white">
                    {clan.memberCount}/{clan.maxMembers}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="bg-green-600/20 p-2 rounded-lg">
                  <Trophy className="h-6 w-6 text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Victoires</p>
                  <p className="text-2xl font-bold text-white">{clan.totalWins}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="bg-purple-600/20 p-2 rounded-lg">
                  <Target className="h-6 w-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Taux de victoire</p>
                  <p className="text-2xl font-bold text-white">{clan.winRate.toFixed(1)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="bg-yellow-600/20 p-2 rounded-lg">
                  <DollarSign className="h-6 w-6 text-yellow-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Gains totaux</p>
                  <p className="text-2xl font-bold text-white">{clan.totalEarnings.toFixed(0)}€</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-slate-800/50 border-slate-700">
              <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600">
                <Activity className="h-4 w-4 mr-2" />
                Aperçu
              </TabsTrigger>
              <TabsTrigger value="members" className="data-[state=active]:bg-blue-600">
                <Users className="h-4 w-4 mr-2" />
                Membres
              </TabsTrigger>
              <TabsTrigger value="matches" className="data-[state=active]:bg-blue-600">
                <Swords className="h-4 w-4 mr-2" />
                Matchs
              </TabsTrigger>
              {isUserMember && (
                <TabsTrigger value="chat" className="data-[state=active]:bg-blue-600">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Chat
                </TabsTrigger>
              )}
              {canManage && (
                <TabsTrigger value="invitations" className="data-[state=active]:bg-blue-600">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Invitations
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Recent Activity */}
                <div className="lg:col-span-2">
                  <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="h-5 w-5" />
                        Activité récente
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {clan.recentActivity?.slice(0, 10).map((activity, index) => (
                          <div key={index} className="flex items-center gap-3 p-3 bg-slate-700/30 rounded-lg">
                            <div className="flex-1">
                              <p className="text-white text-sm">{activity.description}</p>
                              <p className="text-gray-400 text-xs">
                                {new Date(activity.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))}
                        {!clan.recentActivity?.length && (
                          <p className="text-gray-400 text-center py-8">
                            Aucune activité récente
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Clan Leader */}
                <div>
                  <Card className="bg-slate-800/50 border-slate-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Crown className="h-5 w-5" />
                        Capitaine
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={clan.creator.avatar || undefined} alt={clan.creator.username} />
                          <AvatarFallback className="bg-purple-600 text-white">
                            {clan.creator.username.substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-white font-semibold">{clan.creator.username}</h3>
                          <p className="text-gray-400 text-sm">Fondateur du clan</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="members" className="mt-6">
              <ClanMembers clanId={clanId} canManage={canManage} />
            </TabsContent>

            <TabsContent value="matches" className="mt-6">
              <ClanMatches clanId={clanId} canManage={canManage} />
            </TabsContent>

            {isUserMember && (
              <TabsContent value="chat" className="mt-6">
                <ClanChat clanId={clanId} />
              </TabsContent>
            )}

            {canManage && (
              <TabsContent value="invitations" className="mt-6">
                <ClanInvitations clanId={clanId} />
              </TabsContent>
            )}
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
