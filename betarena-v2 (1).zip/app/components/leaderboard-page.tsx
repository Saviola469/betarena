
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import Sidebar from '@/components/sidebar';
import { Trophy, Medal, Award, TrendingUp, GamepadIcon, Crown, Search, Filter, ChevronLeft, ChevronRight, User, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { GAMES } from '@/lib/games';

interface LeaderboardUser {
  id: string;
  username: string;
  avatar: string | null;
  rank: number;
  score: number;
  wins: number;
  losses: number;
  tournamentWins: number;
  country: string | null;
  gamesPlayed: number;
  gamesWon: number;
  totalEarnings: number;
  winRate: number;
  globalRank?: number;
  gameSpecificStats?: {
    wins: number;
    losses: number;
    tournamentWins: number;
    score: number;
    totalEarnings: number;
    winRate: number;
    gamesPlayed: number;
    lastPlayed?: Date;
  };
}

interface LeaderboardResponse {
  users: LeaderboardUser[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export default function LeaderboardPage() {
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardResponse>({
    users: [],
    pagination: { page: 1, limit: 50, total: 0, totalPages: 1 }
  });
  const [selectedGame, setSelectedGame] = useState('all');
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchLeaderboard();
  }, [selectedGame, selectedPlatform, searchQuery, currentPage]);

  const fetchLeaderboard = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams({
        game: selectedGame,
        platform: selectedPlatform,
        page: currentPage.toString(),
        limit: '50'
      });
      
      if (searchQuery.trim()) {
        params.append('search', searchQuery.trim());
      }

      const response = await fetch(`/api/leaderboard?${params}`);
      if (response.ok) {
        const data = await response.json();
        setLeaderboardData(data);
      }
    } catch (error) {
      console.error('Erreur lors du chargement du classement:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1);
    fetchLeaderboard();
  };

  const handleGameChange = (value: string) => {
    setSelectedGame(value);
    setSelectedPlatform('all');
    setCurrentPage(1);
  };

  const handlePlatformChange = (value: string) => {
    setSelectedPlatform(value);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const platforms = [
    { value: 'all', label: 'Toutes les plateformes' },
    { value: 'ps5', label: 'PlayStation 5' },
    { value: 'ps4', label: 'PlayStation 4' },
    { value: 'xbox', label: 'Xbox' },
    { value: 'pc', label: 'PC' },
    { value: 'switch', label: 'Nintendo Switch' }
  ];

  const getRankIcon = (position: number) => {
    switch (position) {
      case 1: return <Crown className="w-5 h-5 text-yellow-500" />;
      case 2: return <Medal className="w-5 h-5 text-gray-400" />;
      case 3: return <Award className="w-5 h-5 text-orange-500" />;
      default: return <Trophy className="w-5 h-5 text-gray-600" />;
    }
  };

  const getRankBadge = (position: number) => {
    switch (position) {
      case 1: return <Badge className="bg-yellow-500 text-white">1er</Badge>;
      case 2: return <Badge className="bg-gray-500 text-white">2e</Badge>;
      case 3: return <Badge className="bg-orange-500 text-white">3e</Badge>;
      default: return <Badge className="bg-gray-700 text-white">{position}e</Badge>;
    }
  };

  const getWinRateColor = (winRate: number) => {
    if (winRate >= 80) return 'text-green-500';
    if (winRate >= 60) return 'text-yellow-500';
    if (winRate >= 40) return 'text-orange-500';
    return 'text-red-500';
  };

  const getScoreColor = (score: number) => {
    if (score >= 100) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    if (score >= 20) return 'text-orange-500';
    return 'text-red-500';
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-gray-900">
        <Sidebar />
        <div className="flex-1 lg:ml-64">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-700 rounded w-1/3 mb-4"></div>
              <div className="h-4 bg-gray-700 rounded w-1/2 mb-8"></div>
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="h-16 bg-gray-700 rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const users = leaderboardData.users;
  const pagination = leaderboardData.pagination;

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-white flex items-center">
                  <Trophy className="w-8 h-8 mr-3 text-yellow-500" />
                  Classement
                </h1>
                <p className="text-gray-400 mt-2">
                  Découvrez les meilleurs joueurs de Betarena
                </p>
              </div>
            </div>
          </motion.div>

          {/* Filtres et recherche */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="mb-8"
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="pt-6">
                <div className="flex flex-col lg:flex-row gap-4 items-center">
                  {/* Recherche */}
                  <div className="flex-1 min-w-0">
                    <form onSubmit={handleSearch} className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        type="text"
                        placeholder="Rechercher un joueur..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                      />
                    </form>
                  </div>
                  
                  {/* Filtres */}
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Select value={selectedGame} onValueChange={handleGameChange}>
                      <SelectTrigger className="w-48 bg-gray-700 border-gray-600 text-white">
                        <GamepadIcon className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Filtrer par jeu" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="all">Classement global</SelectItem>
                        {GAMES.map(game => (
                          <SelectItem key={game.id} value={game.id}>
                            {game.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    {selectedGame !== 'all' && (
                      <Select value={selectedPlatform} onValueChange={handlePlatformChange}>
                        <SelectTrigger className="w-48 bg-gray-700 border-gray-600 text-white">
                          <Filter className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Plateforme" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-800 border-gray-600">
                          {platforms.map(platform => (
                            <SelectItem key={platform.value} value={platform.value}>
                              {platform.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Podium */}
          {users.length >= 3 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mb-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* 2e place */}
                <div className="order-2 md:order-1">
                  <Card className="bg-gray-800 border-gray-700 text-center hover:bg-gray-750 transition-colors">
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center space-y-4">
                        <Medal className="w-12 h-12 text-gray-400" />
                        <Link href={`/users/${users[1].id}`}>
                          <Avatar className="w-16 h-16 hover:ring-2 hover:ring-gray-400 transition-all cursor-pointer">
                            <AvatarImage src={users[1].avatar || undefined} />
                            <AvatarFallback>
                              {users[1].username.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        </Link>
                        <div>
                          <Link href={`/users/${users[1].id}`}>
                            <h3 className="font-bold text-white hover:text-gray-300 transition-colors cursor-pointer">
                              {users[1].username}
                            </h3>
                          </Link>
                          <p className="text-sm text-gray-400">2e place</p>
                          {users[1].country && (
                            <p className="text-xs text-gray-500">{users[1].country}</p>
                          )}
                        </div>
                        <div className="text-sm text-gray-300">
                          Score: <span className={getScoreColor(users[1].score)}>{users[1].score}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* 1er place */}
                <div className="order-1 md:order-2">
                  <Card className="bg-gradient-to-b from-yellow-900 to-gray-800 border-yellow-500 text-center hover:from-yellow-800 transition-colors">
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center space-y-4">
                        <Crown className="w-16 h-16 text-yellow-500" />
                        <Link href={`/users/${users[0].id}`}>
                          <Avatar className="w-20 h-20 ring-4 ring-yellow-500 hover:ring-yellow-400 transition-all cursor-pointer">
                            <AvatarImage src={users[0].avatar || undefined} />
                            <AvatarFallback>
                              {users[0].username.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        </Link>
                        <div>
                          <Link href={`/users/${users[0].id}`}>
                            <h3 className="text-lg font-bold text-white hover:text-gray-300 transition-colors cursor-pointer">
                              {users[0].username}
                            </h3>
                          </Link>
                          <p className="text-sm text-yellow-400">Champion</p>
                          {users[0].country && (
                            <p className="text-xs text-gray-400">{users[0].country}</p>
                          )}
                        </div>
                        <div className="text-sm text-gray-300">
                          Score: <span className="text-yellow-400 font-bold">{users[0].score}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* 3e place */}
                <div className="order-3">
                  <Card className="bg-gray-800 border-gray-700 text-center hover:bg-gray-750 transition-colors">
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center space-y-4">
                        <Award className="w-12 h-12 text-orange-500" />
                        <Link href={`/users/${users[2].id}`}>
                          <Avatar className="w-16 h-16 hover:ring-2 hover:ring-orange-400 transition-all cursor-pointer">
                            <AvatarImage src={users[2].avatar || undefined} />
                            <AvatarFallback>
                              {users[2].username.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        </Link>
                        <div>
                          <Link href={`/users/${users[2].id}`}>
                            <h3 className="font-bold text-white hover:text-gray-300 transition-colors cursor-pointer">
                              {users[2].username}
                            </h3>
                          </Link>
                          <p className="text-sm text-gray-400">3e place</p>
                          {users[2].country && (
                            <p className="text-xs text-gray-500">{users[2].country}</p>
                          )}
                        </div>
                        <div className="text-sm text-gray-300">
                          Score: <span className={getScoreColor(users[2].score)}>{users[2].score}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </motion.div>
          )}

          {/* Classement complet */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Classement complet</CardTitle>
                <CardDescription className="text-gray-400">
                  {pagination.total} joueurs • Page {pagination.page} sur {pagination.totalPages}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <Trophy className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                      <p>Aucun joueur trouvé</p>
                      <p className="text-sm">Essayez de modifier vos filtres de recherche</p>
                    </div>
                  ) : (
                    users.map((user, index) => (
                      <div
                        key={user.id}
                        className={`flex items-center justify-between p-4 rounded-lg transition-colors hover:bg-gray-700 ${
                          index < 3 ? 'bg-gray-700' : 'bg-gray-750'
                        }`}
                      >
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-3">
                            {getRankIcon(user.globalRank || index + 1)}
                            {getRankBadge(user.globalRank || index + 1)}
                          </div>
                          <Link href={`/users/${user.id}`}>
                            <Avatar className="w-12 h-12 hover:ring-2 hover:ring-blue-400 transition-all cursor-pointer">
                              <AvatarImage src={user.avatar || undefined} />
                              <AvatarFallback>
                                {user.username.charAt(0).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                          </Link>
                          <div>
                            <Link href={`/users/${user.id}`}>
                              <div className="font-semibold text-white hover:text-blue-400 transition-colors cursor-pointer">
                                {user.username}
                              </div>
                            </Link>
                            <div className="text-sm text-gray-400 flex items-center space-x-2">
                              <span>Score: {user.score}</span>
                              {user.country && (
                                <>
                                  <span>•</span>
                                  <span>{user.country}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-6">
                          <div className="text-center">
                            <div className="text-sm text-gray-400">Victoires</div>
                            <div className="font-semibold text-white">{user.wins}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-gray-400">Défaites</div>
                            <div className="font-semibold text-white">{user.losses}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-gray-400">Tournois</div>
                            <div className="font-semibold text-white">{user.tournamentWins}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-gray-400">Taux</div>
                            <div className={`font-semibold ${getWinRateColor(user.winRate)}`}>
                              {user.winRate.toFixed(1)}%
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-gray-400">Gains</div>
                            <div className="font-semibold text-green-500">
                              {user.totalEarnings.toFixed(2)}€
                            </div>
                          </div>
                          <Link href={`/users/${user.id}`}>
                            <Button size="sm" variant="outline" className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600">
                              <Eye className="w-4 h-4 mr-2" />
                              Voir
                            </Button>
                          </Link>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Pagination */}
                {pagination.totalPages > 1 && (
                  <div className="flex justify-center items-center mt-8 space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePageChange(pagination.page - 1)}
                      disabled={pagination.page === 1}
                      className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    
                    {[...Array(pagination.totalPages)].map((_, i) => {
                      const pageNumber = i + 1;
                      const isCurrentPage = pageNumber === pagination.page;
                      
                      // Afficher seulement les pages pertinentes
                      if (
                        pageNumber === 1 ||
                        pageNumber === pagination.totalPages ||
                        (pageNumber >= pagination.page - 2 && pageNumber <= pagination.page + 2)
                      ) {
                        return (
                          <Button
                            key={pageNumber}
                            variant={isCurrentPage ? "default" : "outline"}
                            size="sm"
                            onClick={() => handlePageChange(pageNumber)}
                            className={isCurrentPage 
                              ? "bg-blue-600 border-blue-600 text-white hover:bg-blue-700"
                              : "bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                            }
                          >
                            {pageNumber}
                          </Button>
                        );
                      } else if (
                        pageNumber === pagination.page - 3 ||
                        pageNumber === pagination.page + 3
                      ) {
                        return <span key={pageNumber} className="text-gray-400">...</span>;
                      }
                      
                      return null;
                    })}
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePageChange(pagination.page + 1)}
                      disabled={pagination.page === pagination.totalPages}
                      className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
