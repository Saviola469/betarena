
'use client';

import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import BetCard from '@/components/bet-card';
import Sidebar from '@/components/sidebar';
import { PlusCircle, Swords, Trophy, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

interface HomePageProps {
  featuredBets: any[];
  recentBets: any[];
  currentUserId: string;
}

export default function HomePage({ featuredBets, recentBets, currentUserId }: HomePageProps) {
  const router = useRouter();
  const { toast } = useToast();

  const handleJoinBet = async (betId: string) => {
    try {
      const response = await fetch(`/api/bets/${betId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'join' }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erreur lors de la jointure du pari');
      }

      toast({
        title: 'Pari rejoint!',
        description: 'Vous avez rejoint le pari avec succès.',
      });

      router.refresh();
    } catch (error) {
      toast({
        title: 'Erreur',
        description: error instanceof Error ? error.message : 'Une erreur est survenue',
        variant: 'destructive',
      });
    }
  };

  const handleViewBet = (betId: string) => {
    router.push(`/bets/${betId}`);
  };

  return (
    <div className="flex min-h-screen bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 lg:ml-64">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Hero Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600 p-8 mb-12"
          >
            <div className="relative z-10">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                La compétition à votre portée
              </h1>
              <p className="text-xl text-blue-100 mb-8 max-w-2xl">
                Défiez d'autres joueurs, pariez sur vos talents et dominez le classement sur la meilleure plateforme de paris gaming 1v1.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={() => router.push('/bets/create')}
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-gray-100 font-semibold"
                >
                  <PlusCircle className="w-5 h-5 mr-2" />
                  Créer un Pari
                </Button>
                <Button
                  onClick={() => router.push('/bets')}
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white hover:text-blue-600"
                >
                  <Swords className="w-5 h-5 mr-2" />
                  Voir les défis
                </Button>
              </div>
            </div>
            <div className="absolute inset-0 bg-black bg-opacity-20"></div>
          </motion.div>

          {/* Stats Cards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
          >
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Paris Actifs</p>
                  <p className="text-2xl font-bold text-white">{recentBets.length}</p>
                </div>
                <Swords className="w-8 h-8 text-blue-500" />
              </div>
            </div>
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Gains Potentiels</p>
                  <p className="text-2xl font-bold text-white">
                    {featuredBets.reduce((sum, bet) => sum + bet.amount, 0)}€
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
            </div>
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Joueurs Actifs</p>
                  <p className="text-2xl font-bold text-white">
                    {new Set([...featuredBets.map(bet => bet.creator.id), ...recentBets.map(bet => bet.creator.id)]).size}
                  </p>
                </div>
                <Trophy className="w-8 h-8 text-yellow-500" />
              </div>
            </div>
          </motion.div>

          {/* Paris à la Une */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mb-12"
          >
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-white">Paris à la Une</h2>
              <Button
                onClick={() => router.push('/bets')}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Voir tous les paris
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredBets.slice(0, 6).map((bet) => (
                <BetCard
                  key={bet.id}
                  bet={bet}
                  onJoin={handleJoinBet}
                  onView={handleViewBet}
                  currentUserId={currentUserId}
                />
              ))}
            </div>
          </motion.section>

          {/* Derniers Paris */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-white">Derniers Paris</h2>
              <Button
                onClick={() => router.push('/leaderboard')}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <Trophy className="w-4 h-4 mr-2" />
                Classement
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {recentBets.slice(0, 8).map((bet) => (
                <BetCard
                  key={bet.id}
                  bet={bet}
                  onJoin={handleJoinBet}
                  onView={handleViewBet}
                  currentUserId={currentUserId}
                />
              ))}
            </div>
          </motion.section>
        </div>
      </div>
    </div>
  );
}
