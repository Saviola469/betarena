
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import ClanDetailsPage from '@/components/clan-details-page';

export const dynamic = 'force-dynamic';

export default async function ClanDetailsPageRoute({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  return <ClanDetailsPage clanId={params.id} />;
}
