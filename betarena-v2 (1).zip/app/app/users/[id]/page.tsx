
import { Suspense } from 'react';
import PlayerProfilePage from '@/components/player-profile-page';

interface PageProps {
  params: {
    id: string;
  };
}

export default function PlayerProfilePageRoute({ params }: PageProps) {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <PlayerProfilePage userId={params.id} />
    </Suspense>
  );
}
