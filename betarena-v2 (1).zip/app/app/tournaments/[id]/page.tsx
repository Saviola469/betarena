
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import TournamentDetailsPage from '@/components/tournament-details-page';

export default async function TournamentDetails({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  
  if (!session) {
    redirect('/login');
  }

  return <TournamentDetailsPage tournamentId={params.id} />;
}
