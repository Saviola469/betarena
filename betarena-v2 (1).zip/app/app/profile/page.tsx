
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';
import ProfilePage from '@/components/profile-page';

export default async function Profile() {
  const session = await getServerSession(authOptions);
  
  if (!session) {
    redirect('/login');
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      betsCreated: {
        include: {
          opponent: {
            select: {
              username: true,
              avatar: true,
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: 10,
      },
      betsJoined: {
        include: {
          creator: {
            select: {
              username: true,
              avatar: true,
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: 10,
      },
    },
  });

  if (!user) {
    redirect('/login');
  }

  return <ProfilePage user={user} />;
}
