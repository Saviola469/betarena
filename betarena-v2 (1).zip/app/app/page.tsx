
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/db';
import HomePage from '@/components/home-page';

export default async function Home() {
  const session = await getServerSession();
  
  if (!session) {
    redirect('/login');
  }

  // Récupérer les paris récents et à la une
  const [featuredBets, recentBets] = await Promise.all([
    prisma.bet.findMany({
      where: { status: 'OPEN' },
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        }
      },
      orderBy: { amount: 'desc' },
      take: 6,
    }),
    prisma.bet.findMany({
      where: { status: 'OPEN' },
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 8,
    })
  ]);

  return (
    <HomePage 
      featuredBets={featuredBets}
      recentBets={recentBets}
      currentUserId={session.user.id}
    />
  );
}
