
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import WalletPage from '@/components/wallet-page';

export default async function Wallet() {
  const session = await getServerSession();
  
  if (!session) {
    redirect('/login');
  }

  return <WalletPage />;
}
