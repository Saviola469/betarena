
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/db';
import BetDetailsPage from '@/components/bet-details-page';

export default async function BetDetails({ params }: { params: { id: string } }) {
  const session = await getServerSession();
  
  if (!session) {
    redirect('/login');
  }

  const bet = await prisma.bet.findUnique({
    where: { id: params.id },
    include: {
      creator: {
        select: {
          id: true,
          username: true,
          avatar: true,
          rank: true,
        }
      },
      opponent: {
        select: {
          id: true,
          username: true,
          avatar: true,
          rank: true,
        }
      },
      screenshots: {
        orderBy: {
          createdAt: 'desc'
        }
      },
      messages: {
        include: {
          user: {
            select: {
              id: true,
              username: true,
              avatar: true,
            }
          }
        },
        orderBy: {
          createdAt: 'asc'
        }
      }
    }
  });

  if (!bet) {
    redirect('/bets');
  }

  return <BetDetailsPage bet={bet} currentUserId={session.user.id} />;
}
