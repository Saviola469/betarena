
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/db';
import BetsPage from '@/components/bets-page';

export default async function Bets() {
  const session = await getServerSession();
  
  if (!session) {
    redirect('/login');
  }

  const bets = await prisma.bet.findMany({
    where: { status: 'OPEN' },
    include: {
      creator: {
        select: {
          id: true,
          username: true,
          avatar: true,
          rank: true,
        }
      }
    },
    orderBy: { createdAt: 'desc' }
  });

  return (
    <BetsPage 
      bets={bets}
      currentUserId={session.user.id}
    />
  );
}
