
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import CreateBetPage from '@/components/create-bet-page';

export default async function CreateBet() {
  const session = await getServerSession();
  
  if (!session) {
    redirect('/login');
  }

  return <CreateBetPage />;
}
