
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    const userId = params.id;
    const { searchParams } = new URL(request.url);
    const game = searchParams.get('game');
    const platform = searchParams.get('platform');

    // Vérifier si l'utilisateur existe et si son profil est public
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        isProfilePublic: true
      }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier les permissions d'accès
    const isOwnProfile = session?.user?.id === userId;
    if (!user.isProfilePublic && !isOwnProfile) {
      return NextResponse.json(
        { error: 'Profil privé' },
        { status: 403 }
      );
    }

    // Construire les filtres
    const whereClause: any = { userId };
    if (game && game !== 'all') {
      whereClause.game = game;
    }
    if (platform && platform !== 'all') {
      whereClause.platform = platform;
    }

    // Récupérer les statistiques
    const playerStats = await prisma.playerStats.findMany({
      where: whereClause,
      select: {
        id: true,
        game: true,
        platform: true,
        wins: true,
        losses: true,
        tournamentWins: true,
        score: true,
        totalEarnings: true,
        lastPlayed: true,
        createdAt: true,
        updatedAt: true
      },
      orderBy: [
        { score: 'desc' },
        { lastPlayed: 'desc' }
      ]
    });

    // Calculer les statistiques étendues
    const extendedStats = playerStats.map((stat, index) => {
      const gamesPlayed = stat.wins + stat.losses;
      const winRate = gamesPlayed > 0 ? (stat.wins / gamesPlayed) * 100 : 0;
      
      return {
        ...stat,
        user: {
          id: user.id,
          username: user.username,
          avatar: null,
          country: null
        },
        rank: index + 1,
        winRate,
        gamesPlayed
      };
    });

    // Calculer les statistiques agrégées
    const totalStats = playerStats.reduce((acc, stat) => ({
      totalWins: acc.totalWins + stat.wins,
      totalLosses: acc.totalLosses + stat.losses,
      totalTournamentWins: acc.totalTournamentWins + stat.tournamentWins,
      totalScore: acc.totalScore + stat.score,
      totalEarnings: acc.totalEarnings + stat.totalEarnings
    }), {
      totalWins: 0,
      totalLosses: 0,
      totalTournamentWins: 0,
      totalScore: 0,
      totalEarnings: 0
    });

    const totalGamesPlayed = totalStats.totalWins + totalStats.totalLosses;
    const overallWinRate = totalGamesPlayed > 0 ? (totalStats.totalWins / totalGamesPlayed) * 100 : 0;

    return NextResponse.json({
      playerStats: extendedStats,
      aggregatedStats: {
        ...totalStats,
        totalGamesPlayed,
        overallWinRate
      },
      filters: {
        game,
        platform
      }
    });
  } catch (error) {
    console.error('Erreur lors de la récupération des statistiques:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des statistiques' },
      { status: 500 }
    );
  }
}
