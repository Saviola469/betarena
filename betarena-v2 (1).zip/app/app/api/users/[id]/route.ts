
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    const userId = params.id;

    // Récupérer l'utilisateur
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        avatar: true,
        country: true,
        rank: true,
        score: true,
        wins: true,
        losses: true,
        tournamentWins: true,
        gamesPlayed: true,
        gamesWon: true,
        createdAt: true,
        isProfilePublic: true,
        playerStats: {
          select: {
            id: true,
            game: true,
            platform: true,
            wins: true,
            losses: true,
            tournamentWins: true,
            score: true,
            totalEarnings: true,
            lastPlayed: true,
            updatedAt: true
          },
          orderBy: {
            lastPlayed: 'desc'
          }
        }
      }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier si le profil est public ou si c'est le propre profil de l'utilisateur
    const isOwnProfile = session?.user?.id === userId;
    if (!user.isProfilePublic && !isOwnProfile) {
      return NextResponse.json(
        { error: 'Profil privé' },
        { status: 403 }
      );
    }

    // Calculer les statistiques
    const winRate = user.gamesPlayed > 0 ? (user.gamesWon / user.gamesPlayed) * 100 : 0;

    // Préparer les jeux récents
    const recentGames = user.playerStats.map(stat => {
      const gamesPlayed = stat.wins + stat.losses;
      const winRate = gamesPlayed > 0 ? (stat.wins / gamesPlayed) * 100 : 0;
      
      return {
        game: stat.game,
        platform: stat.platform,
        lastPlayed: stat.lastPlayed || stat.updatedAt,
        wins: stat.wins,
        losses: stat.losses,
        winRate
      };
    }).slice(0, 5); // Limiter aux 5 jeux les plus récents

    // Préparer les statistiques étendues
    const extendedPlayerStats = user.playerStats.map(stat => {
      const gamesPlayed = stat.wins + stat.losses;
      const winRate = gamesPlayed > 0 ? (stat.wins / gamesPlayed) * 100 : 0;
      
      return {
        ...stat,
        user: {
          id: user.id,
          username: user.username,
          avatar: user.avatar,
          country: user.country
        },
        winRate,
        gamesPlayed
      };
    });

    const publicProfile = {
      id: user.id,
      username: user.username,
      avatar: user.avatar,
      country: user.country,
      rank: user.rank,
      score: user.score,
      wins: user.wins,
      losses: user.losses,
      tournamentWins: user.tournamentWins,
      winRate,
      gamesPlayed: user.gamesPlayed,
      createdAt: user.createdAt,
      isProfilePublic: user.isProfilePublic,
      playerStats: extendedPlayerStats,
      recentGames
    };

    return NextResponse.json(publicProfile);
  } catch (error) {
    console.error('Erreur lors de la récupération du profil:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du profil' },
      { status: 500 }
    );
  }
}

// Mettre à jour les paramètres de confidentialité
export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Non authentifié' },
        { status: 401 }
      );
    }

    const userId = params.id;
    
    // Vérifier que l'utilisateur modifie son propre profil
    if (session.user.id !== userId) {
      return NextResponse.json(
        { error: 'Non autorisé' },
        { status: 403 }
      );
    }

    const { isProfilePublic } = await request.json();

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: { isProfilePublic },
      select: {
        id: true,
        username: true,
        isProfilePublic: true
      }
    });

    return NextResponse.json(updatedUser);
  } catch (error) {
    console.error('Erreur lors de la mise à jour du profil:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la mise à jour du profil' },
      { status: 500 }
    );
  }
}
