
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const conversation = await prisma.conversation.findUnique({
      where: { id: params.id },
      include: {
        userA: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        userB: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        messages: {
          include: {
            sender: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          },
          orderBy: {
            createdAt: 'asc'
          }
        }
      }
    });

    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation non trouvée' },
        { status: 404 }
      );
    }

    // Vérifier que l'utilisateur fait partie de la conversation
    if (conversation.userAId !== session.user.id && conversation.userBId !== session.user.id) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas accès à cette conversation' },
        { status: 403 }
      );
    }

    const otherUser = conversation.userA.id === session.user.id 
      ? conversation.userB 
      : conversation.userA;

    return NextResponse.json({
      ...conversation,
      otherUser
    });
  } catch (error) {
    console.error('Erreur lors de la récupération de la conversation:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération de la conversation' },
      { status: 500 }
    );
  }
}
