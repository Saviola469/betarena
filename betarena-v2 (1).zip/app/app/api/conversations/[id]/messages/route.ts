
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { content } = await request.json();

    if (!content || content.trim() === '') {
      return NextResponse.json(
        { error: 'Le message ne peut pas être vide' },
        { status: 400 }
      );
    }

    // Vérifier que la conversation existe et que l'utilisateur y a accès
    const conversation = await prisma.conversation.findUnique({
      where: { id: params.id },
    });

    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation non trouvée' },
        { status: 404 }
      );
    }

    if (conversation.userAId !== session.user.id && conversation.userBId !== session.user.id) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas accès à cette conversation' },
        { status: 403 }
      );
    }

    // Créer le message et mettre à jour la conversation
    const result = await prisma.$transaction(async (prisma) => {
      // Créer le message
      const message = await prisma.directMessage.create({
        data: {
          conversationId: params.id,
          senderId: session.user.id,
          content: content.trim(),
        },
        include: {
          sender: {
            select: {
              id: true,
              username: true,
              avatar: true,
            }
          }
        }
      });

      // Mettre à jour la conversation
      await prisma.conversation.update({
        where: { id: params.id },
        data: {
          lastMessage: content.trim(),
          lastMessageAt: new Date(),
        }
      });

      return message;
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Erreur lors de l\'envoi du message:', error);
    return NextResponse.json(
      { error: 'Erreur lors de l\'envoi du message' },
      { status: 500 }
    );
  }
}

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const skip = (page - 1) * limit;

    // Vérifier que l'utilisateur a accès à la conversation
    const conversation = await prisma.conversation.findUnique({
      where: { id: params.id },
    });

    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation non trouvée' },
        { status: 404 }
      );
    }

    if (conversation.userAId !== session.user.id && conversation.userBId !== session.user.id) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas accès à cette conversation' },
        { status: 403 }
      );
    }

    const messages = await prisma.directMessage.findMany({
      where: {
        conversationId: params.id,
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      skip,
      take: limit
    });

    // Retourner les messages dans l'ordre chronologique
    return NextResponse.json(messages.reverse());
  } catch (error) {
    console.error('Erreur lors de la récupération des messages:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des messages' },
      { status: 500 }
    );
  }
}
