
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const conversations = await prisma.conversation.findMany({
      where: {
        OR: [
          { userAId: session.user.id },
          { userBId: session.user.id }
        ]
      },
      include: {
        userA: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        userB: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        messages: {
          orderBy: {
            createdAt: 'desc'
          },
          take: 1,
          include: {
            sender: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        }
      },
      orderBy: {
        lastMessageAt: 'desc'
      }
    });

    // Transformer les conversations pour inclure l'autre utilisateur
    const transformedConversations = conversations.map(conversation => {
      const otherUser = conversation.userA.id === session.user.id 
        ? conversation.userB 
        : conversation.userA;

      return {
        ...conversation,
        otherUser,
        lastMessage: conversation.messages[0]?.content || null
      };
    });

    return NextResponse.json(transformedConversations);
  } catch (error) {
    console.error('Erreur lors de la récupération des conversations:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des conversations' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { otherUserId } = await request.json();

    if (!otherUserId) {
      return NextResponse.json(
        { error: 'ID utilisateur requis' },
        { status: 400 }
      );
    }

    if (otherUserId === session.user.id) {
      return NextResponse.json(
        { error: 'Vous ne pouvez pas créer une conversation avec vous-même' },
        { status: 400 }
      );
    }

    // Vérifier si l'autre utilisateur existe
    const otherUser = await prisma.user.findUnique({
      where: { id: otherUserId },
      select: {
        id: true,
        username: true,
        avatar: true,
      }
    });

    if (!otherUser) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier si une conversation existe déjà
    const existingConversation = await prisma.conversation.findFirst({
      where: {
        OR: [
          { userAId: session.user.id, userBId: otherUserId },
          { userAId: otherUserId, userBId: session.user.id }
        ]
      },
      include: {
        userA: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        userB: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    });

    if (existingConversation) {
      const otherUser = existingConversation.userA.id === session.user.id 
        ? existingConversation.userB 
        : existingConversation.userA;

      return NextResponse.json({
        ...existingConversation,
        otherUser
      });
    }

    // Créer une nouvelle conversation
    const conversation = await prisma.conversation.create({
      data: {
        userAId: session.user.id,
        userBId: otherUserId,
      },
      include: {
        userA: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        userB: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    });

    return NextResponse.json({
      ...conversation,
      otherUser
    });
  } catch (error) {
    console.error('Erreur lors de la création de la conversation:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création de la conversation' },
      { status: 500 }
    );
  }
}
