
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const game = searchParams.get('game');
    const platform = searchParams.get('platform');
    const status = searchParams.get('status') || 'OPEN';

    const where: any = { status };

    if (game && game !== 'all') {
      where.game = game;
    }

    if (platform && platform !== 'all') {
      where.platform = platform;
    }

    const bets = await prisma.bet.findMany({
      where,
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        },
        opponent: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        },
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    return NextResponse.json(bets);
  } catch (error) {
    console.error('Erreur lors de la récupération des paris:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des paris' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { game, platform, amount, rules } = await request.json();

    if (!game || !platform || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Données invalides' },
        { status: 400 }
      );
    }

    // Vérifier le solde de l'utilisateur
    const user = await prisma.user.findUnique({
      where: { id: session.user.id }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      );
    }

    const availableBalance = user.walletTotal - user.walletEscrow;
    if (availableBalance < amount) {
      return NextResponse.json(
        { error: 'Solde insuffisant' },
        { status: 400 }
      );
    }

    // Créer le pari et mettre à jour le solde en escrow
    const bet = await prisma.$transaction(async (prisma) => {
      // Créer le pari
      const newBet = await prisma.bet.create({
        data: {
          game,
          platform,
          amount,
          rules: rules || '',
          creatorId: session.user.id,
        },
        include: {
          creator: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
            }
          }
        }
      });

      // Mettre à jour le solde en escrow
      await prisma.user.update({
        where: { id: session.user.id },
        data: {
          walletEscrow: {
            increment: amount
          }
        }
      });

      return newBet;
    });

    return NextResponse.json(bet);
  } catch (error) {
    console.error('Erreur lors de la création du pari:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création du pari' },
      { status: 500 }
    );
  }
}
