
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { content } = await request.json();

    if (!content || content.trim() === '') {
      return NextResponse.json(
        { error: 'Le message ne peut pas être vide' },
        { status: 400 }
      );
    }

    // Vérifier que l'utilisateur fait partie du pari
    const bet = await prisma.bet.findUnique({
      where: { id: params.id },
    });

    if (!bet) {
      return NextResponse.json(
        { error: 'Pari non trouvé' },
        { status: 404 }
      );
    }

    if (bet.creatorId !== session.user.id && bet.opponentId !== session.user.id) {
      return NextResponse.json(
        { error: 'Vous n\'êtes pas autorisé à envoyer des messages dans ce pari' },
        { status: 403 }
      );
    }

    // Créer le message
    const message = await prisma.message.create({
      data: {
        betId: params.id,
        userId: session.user.id,
        content: content.trim(),
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    });

    return NextResponse.json(message);
  } catch (error) {
    console.error('Erreur lors de l\'envoi du message:', error);
    return NextResponse.json(
      { error: 'Erreur lors de l\'envoi du message' },
      { status: 500 }
    );
  }
}
