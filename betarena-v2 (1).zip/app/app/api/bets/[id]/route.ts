
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const bet = await prisma.bet.findUnique({
      where: { id: params.id },
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        },
        opponent: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        },
        screenshots: {
          include: {
            bet: {
              select: {
                id: true
              }
            }
          },
          orderBy: {
            createdAt: 'desc'
          }
        },
        messages: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          },
          orderBy: {
            createdAt: 'asc'
          }
        }
      }
    });

    if (!bet) {
      return NextResponse.json(
        { error: 'Pari non trouvé' },
        { status: 404 }
      );
    }

    return NextResponse.json(bet);
  } catch (error) {
    console.error('Erreur lors de la récupération du pari:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du pari' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { action } = await request.json();

    if (action === 'join') {
      const bet = await prisma.bet.findUnique({
        where: { id: params.id },
        include: { creator: true }
      });

      if (!bet) {
        return NextResponse.json(
          { error: 'Pari non trouvé' },
          { status: 404 }
        );
      }

      if (bet.status !== 'OPEN') {
        return NextResponse.json(
          { error: 'Ce pari n\'est plus disponible' },
          { status: 400 }
        );
      }

      if (bet.creatorId === session.user.id) {
        return NextResponse.json(
          { error: 'Vous ne pouvez pas rejoindre votre propre pari' },
          { status: 400 }
        );
      }

      // Vérifier le solde de l'utilisateur
      const user = await prisma.user.findUnique({
        where: { id: session.user.id }
      });

      if (!user) {
        return NextResponse.json(
          { error: 'Utilisateur non trouvé' },
          { status: 404 }
        );
      }

      const availableBalance = user.walletTotal - user.walletEscrow;
      if (availableBalance < bet.amount) {
        return NextResponse.json(
          { error: 'Solde insuffisant' },
          { status: 400 }
        );
      }

      // Rejoindre le pari
      const updatedBet = await prisma.$transaction(async (prisma) => {
        // Mettre à jour le pari
        const bet = await prisma.bet.update({
          where: { id: params.id },
          data: {
            opponentId: session.user.id,
            status: 'ACTIVE'
          },
          include: {
            creator: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
              }
            },
            opponent: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
              }
            }
          }
        });

        // Mettre à jour le solde en escrow
        await prisma.user.update({
          where: { id: session.user.id },
          data: {
            walletEscrow: {
              increment: bet.amount
            }
          }
        });

        return bet;
      });

      return NextResponse.json(updatedBet);
    }

    return NextResponse.json(
      { error: 'Action non valide' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Erreur lors de la modification du pari:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la modification du pari' },
      { status: 500 }
    );
  }
}
