
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const platform = searchParams.get('platform');
    const clanType = searchParams.get('clanType');
    const search = searchParams.get('search');
    const sortBy = searchParams.get('sortBy') || 'createdAt';
    const sortOrder = searchParams.get('sortOrder') || 'desc';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');

    const where: any = {};

    if (platform && platform !== 'all') {
      where.platform = platform;
    }

    if (clanType) {
      where.clanType = clanType;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { tag: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const orderBy: any = {};
    if (sortBy === 'members') {
      orderBy.members = { _count: sortOrder };
    } else if (sortBy === 'winRate') {
      orderBy.totalWins = sortOrder;
    } else if (sortBy === 'totalEarnings') {
      orderBy.totalEarnings = sortOrder;
    } else {
      orderBy[sortBy] = sortOrder;
    }

    const clans = await prisma.clan.findMany({
      where,
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        members: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
            clanRole: true,
          }
        },
        memberships: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
              }
            }
          }
        },
        _count: {
          select: { members: true }
        }
      },
      orderBy,
      skip: (page - 1) * limit,
      take: limit,
    });

    const total = await prisma.clan.count({ where });

    const clansWithStats = clans.map(clan => ({
      ...clan,
      memberCount: clan._count.members,
      winRate: clan.totalMatches > 0 ? (clan.totalWins / clan.totalMatches) * 100 : 0,
    }));

    return NextResponse.json({
      clans: clansWithStats,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Erreur lors de la récupération des clans:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des clans' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { name, tag, description, platform, clanType, maxMembers } = await request.json();

    if (!name || !tag || !platform) {
      return NextResponse.json(
        { error: 'Nom, tag et plateforme sont requis' },
        { status: 400 }
      );
    }

    // Vérifier si l'utilisateur est déjà dans un clan
    const existingUser = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { clanId: true }
    });

    if (existingUser?.clanId) {
      return NextResponse.json(
        { error: 'Vous êtes déjà membre d\'un clan' },
        { status: 400 }
      );
    }

    // Vérifier l'unicité du nom et du tag
    const existingClan = await prisma.clan.findFirst({
      where: {
        OR: [
          { name: { equals: name, mode: 'insensitive' } },
          { tag: { equals: tag, mode: 'insensitive' } }
        ]
      }
    });

    if (existingClan) {
      return NextResponse.json(
        { error: 'Ce nom ou ce tag de clan existe déjà' },
        { status: 400 }
      );
    }

    // Créer le clan et ajouter le créateur comme membre
    const clan = await prisma.$transaction(async (prisma) => {
      const newClan = await prisma.clan.create({
        data: {
          name,
          tag: tag.toUpperCase(),
          description,
          platform,
          clanType: clanType || 'PUBLIC',
          maxMembers: maxMembers || 50,
          creatorId: session.user.id,
        },
        include: {
          creator: {
            select: {
              id: true,
              username: true,
              avatar: true,
            }
          },
          members: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
              clanRole: true,
            }
          },
          memberships: {
            include: {
              user: {
                select: {
                  id: true,
                  username: true,
                  avatar: true,
                  rank: true,
                }
              }
            }
          }
        }
      });

      // Ajouter le créateur comme membre avec le rôle CAPTAIN
      await prisma.user.update({
        where: { id: session.user.id },
        data: {
          clanId: newClan.id,
          clanRole: 'CAPTAIN'
        }
      });

      await prisma.clanMember.create({
        data: {
          clanId: newClan.id,
          userId: session.user.id,
          role: 'CAPTAIN'
        }
      });

      // Ajouter un message système
      await prisma.clanMessage.create({
        data: {
          clanId: newClan.id,
          senderId: session.user.id,
          content: `Clan ${name} créé avec succès !`,
          messageType: 'SYSTEM'
        }
      });

      return newClan;
    });

    return NextResponse.json(clan);
  } catch (error) {
    console.error('Erreur lors de la création du clan:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création du clan' },
      { status: 500 }
    );
  }
}
