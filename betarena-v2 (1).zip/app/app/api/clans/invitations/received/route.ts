
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || 'PENDING';

    const invitations = await prisma.clanInvitation.findMany({
      where: {
        receiverId: session.user.id,
        status: status as any,
      },
      include: {
        clan: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
            clanType: true,
            _count: { select: { members: true } }
          }
        },
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            clanRole: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const invitationsWithMemberCount = invitations.map(inv => ({
      ...inv,
      clan: {
        ...inv.clan,
        memberCount: inv.clan._count.members
      }
    }));

    return NextResponse.json(invitationsWithMemberCount);
  } catch (error) {
    console.error('Erreur lors de la récupération des invitations reçues:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des invitations reçues' },
      { status: 500 }
    );
  }
}
