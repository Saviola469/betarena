
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const platform = searchParams.get('platform');
    const sortBy = searchParams.get('sortBy') || 'winRate';
    const sortOrder = searchParams.get('sortOrder') || 'desc';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where: any = {};

    if (platform && platform !== 'all') {
      where.platform = platform;
    }

    // Calculer le classement avec les statistiques
    const clans = await prisma.clan.findMany({
      where,
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        _count: {
          select: { members: true }
        }
      },
      orderBy: [
        { totalWins: 'desc' },
        { totalEarnings: 'desc' },
        { createdAt: 'asc' }
      ],
      skip: (page - 1) * limit,
      take: limit,
    });

    const total = await prisma.clan.count({ where });

    const leaderboard = clans.map((clan, index) => ({
      id: clan.id,
      name: clan.name,
      tag: clan.tag,
      logo: clan.logo,
      platform: clan.platform,
      memberCount: clan._count.members,
      totalWins: clan.totalWins,
      totalLosses: clan.totalLosses,
      totalMatches: clan.totalMatches,
      winRate: clan.totalMatches > 0 ? (clan.totalWins / clan.totalMatches) * 100 : 0,
      totalEarnings: clan.totalEarnings,
      rank: (page - 1) * limit + index + 1,
      creator: clan.creator,
    }));

    // Trier selon le critère demandé
    if (sortBy === 'winRate') {
      leaderboard.sort((a, b) => {
        if (sortOrder === 'desc') {
          return b.winRate - a.winRate;
        } else {
          return a.winRate - b.winRate;
        }
      });
    } else if (sortBy === 'totalEarnings') {
      leaderboard.sort((a, b) => {
        if (sortOrder === 'desc') {
          return b.totalEarnings - a.totalEarnings;
        } else {
          return a.totalEarnings - b.totalEarnings;
        }
      });
    } else if (sortBy === 'members') {
      leaderboard.sort((a, b) => {
        if (sortOrder === 'desc') {
          return b.memberCount - a.memberCount;
        } else {
          return a.memberCount - b.memberCount;
        }
      });
    }

    // Recalculer les rangs après le tri
    leaderboard.forEach((clan, index) => {
      clan.rank = (page - 1) * limit + index + 1;
    });

    // Statistiques globales
    const stats = await prisma.clan.aggregate({
      where,
      _count: { id: true },
      _avg: { 
        totalWins: true,
        totalMatches: true,
        totalEarnings: true
      },
      _sum: { 
        totalMatches: true,
        totalEarnings: true
      }
    });

    const totalMembers = await prisma.clanMember.count({
      where: {
        clan: where
      }
    });

    const globalStats = {
      totalClans: stats._count.id,
      totalMatches: stats._sum.totalMatches || 0,
      totalMembers,
      averageWinRate: stats._avg.totalWins && stats._avg.totalMatches 
        ? (stats._avg.totalWins / stats._avg.totalMatches) * 100 
        : 0,
      totalEarnings: stats._sum.totalEarnings || 0,
    };

    // Clans les plus actifs (plus de matchs)
    const mostActiveClans = await prisma.clan.findMany({
      where,
      select: {
        id: true,
        name: true,
        tag: true,
        logo: true,
        totalMatches: true,
      },
      orderBy: { totalMatches: 'desc' },
      take: 5,
    });

    // Clans avec le plus de gains
    const topEarningClans = await prisma.clan.findMany({
      where,
      select: {
        id: true,
        name: true,
        tag: true,
        logo: true,
        totalEarnings: true,
      },
      orderBy: { totalEarnings: 'desc' },
      take: 5,
    });

    return NextResponse.json({
      leaderboard,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      stats: {
        ...globalStats,
        mostActiveClans,
        topEarningClans,
      },
    });
  } catch (error) {
    console.error('Erreur lors de la récupération du classement des clans:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du classement des clans' },
      { status: 500 }
    );
  }
}
