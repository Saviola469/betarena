
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const clanId = params.id;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const game = searchParams.get('game');
    const platform = searchParams.get('platform');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');

    const where: any = {
      OR: [
        { clanAId: clanId },
        { clanBId: clanId }
      ]
    };

    if (status) {
      where.status = status;
    }

    if (game && game !== 'all') {
      where.game = game;
    }

    if (platform && platform !== 'all') {
      where.platform = platform;
    }

    const matches = await prisma.clanMatch.findMany({
      where,
      include: {
        clanA: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
          }
        },
        clanB: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
          }
        },
        winner: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
          }
        },
        playerA: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        playerB: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    });

    const total = await prisma.clanMatch.count({ where });

    return NextResponse.json({
      matches,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Erreur lors de la récupération des matchs:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des matchs' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const { 
      opponentClanId, 
      game, 
      platform, 
      matchType, 
      format, 
      amount, 
      rules, 
      scheduledAt 
    } = await request.json();

    if (!opponentClanId || !game || !platform || !format) {
      return NextResponse.json(
        { error: 'Clan adversaire, jeu, plateforme et format sont requis' },
        { status: 400 }
      );
    }

    // Vérifier si l'utilisateur est capitaine ou co-leader du clan
    const membership = await prisma.clanMember.findFirst({
      where: {
        clanId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    if (!membership) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour créer des matchs' },
        { status: 403 }
      );
    }

    // Vérifier si le clan adversaire existe
    const opponentClan = await prisma.clan.findUnique({
      where: { id: opponentClanId },
      select: { id: true, name: true }
    });

    if (!opponentClan) {
      return NextResponse.json(
        { error: 'Clan adversaire non trouvé' },
        { status: 404 }
      );
    }

    if (opponentClanId === clanId) {
      return NextResponse.json(
        { error: 'Un clan ne peut pas se défier lui-même' },
        { status: 400 }
      );
    }

    // Créer le match
    const match = await prisma.clanMatch.create({
      data: {
        clanAId: clanId,
        clanBId: opponentClanId,
        game,
        platform,
        matchType: matchType || 'CHALLENGE',
        format,
        amount: amount || 0,
        rules,
        status: 'PENDING',
        playerAId: session.user.id,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
      },
      include: {
        clanA: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
          }
        },
        clanB: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
          }
        },
        playerA: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    });

    // Ajouter un message dans le chat du clan organisateur
    await prisma.clanMessage.create({
      data: {
        clanId,
        senderId: session.user.id,
        content: `Match ${game} créé contre ${opponentClan.name}`,
        messageType: 'SYSTEM'
      }
    });

    return NextResponse.json(match);
  } catch (error) {
    console.error('Erreur lors de la création du match:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création du match' },
      { status: 500 }
    );
  }
}
