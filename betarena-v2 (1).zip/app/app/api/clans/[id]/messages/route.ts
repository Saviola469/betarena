
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    // Vérifier si l'utilisateur est membre du clan
    const membership = await prisma.clanMember.findUnique({
      where: {
        clanId_userId: {
          clanId,
          userId: session.user.id
        }
      }
    });

    if (!membership) {
      return NextResponse.json(
        { error: 'Vous n\'êtes pas membre de ce clan' },
        { status: 403 }
      );
    }

    const messages = await prisma.clanMessage.findMany({
      where: { clanId },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            clanRole: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    });

    const total = await prisma.clanMessage.count({
      where: { clanId }
    });

    return NextResponse.json({
      messages: messages.reverse(), // Inverser pour avoir les plus récents en bas
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Erreur lors de la récupération des messages:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des messages' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const { content } = await request.json();

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Le contenu du message est requis' },
        { status: 400 }
      );
    }

    if (content.length > 1000) {
      return NextResponse.json(
        { error: 'Le message ne peut pas dépasser 1000 caractères' },
        { status: 400 }
      );
    }

    // Vérifier si l'utilisateur est membre du clan
    const membership = await prisma.clanMember.findUnique({
      where: {
        clanId_userId: {
          clanId,
          userId: session.user.id
        }
      }
    });

    if (!membership) {
      return NextResponse.json(
        { error: 'Vous n\'êtes pas membre de ce clan' },
        { status: 403 }
      );
    }

    // Créer le message
    const message = await prisma.clanMessage.create({
      data: {
        clanId,
        senderId: session.user.id,
        content: content.trim(),
        messageType: 'TEXT'
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            clanRole: true,
          }
        },
        clan: {
          select: {
            id: true,
            name: true,
            tag: true,
          }
        }
      }
    });

    return NextResponse.json(message);
  } catch (error) {
    console.error('Erreur lors de la création du message:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création du message' },
      { status: 500 }
    );
  }
}
