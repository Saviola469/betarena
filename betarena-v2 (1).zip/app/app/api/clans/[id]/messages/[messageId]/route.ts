
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function PUT(request: Request, { params }: { params: { id: string; messageId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const messageId = params.messageId;
    const { content } = await request.json();

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Le contenu du message est requis' },
        { status: 400 }
      );
    }

    if (content.length > 1000) {
      return NextResponse.json(
        { error: 'Le message ne peut pas dépasser 1000 caractères' },
        { status: 400 }
      );
    }

    // Vérifier si le message existe et si l'utilisateur est l'auteur
    const message = await prisma.clanMessage.findUnique({
      where: { id: messageId },
      select: {
        id: true,
        senderId: true,
        messageType: true,
        createdAt: true
      }
    });

    if (!message) {
      return NextResponse.json(
        { error: 'Message non trouvé' },
        { status: 404 }
      );
    }

    if (message.senderId !== session.user.id) {
      return NextResponse.json(
        { error: 'Vous ne pouvez modifier que vos propres messages' },
        { status: 403 }
      );
    }

    if (message.messageType !== 'TEXT') {
      return NextResponse.json(
        { error: 'Seuls les messages texte peuvent être modifiés' },
        { status: 400 }
      );
    }

    // Vérifier si le message n'est pas trop ancien (15 minutes)
    const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000);
    if (message.createdAt < fifteenMinutesAgo) {
      return NextResponse.json(
        { error: 'Vous ne pouvez modifier un message que dans les 15 minutes suivant sa création' },
        { status: 400 }
      );
    }

    // Mettre à jour le message
    const updatedMessage = await prisma.clanMessage.update({
      where: { id: messageId },
      data: {
        content: content.trim(),
        editedAt: new Date()
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            clanRole: true,
          }
        },
        clan: {
          select: {
            id: true,
            name: true,
            tag: true,
          }
        }
      }
    });

    return NextResponse.json(updatedMessage);
  } catch (error) {
    console.error('Erreur lors de la modification du message:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la modification du message' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string; messageId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const messageId = params.messageId;

    // Vérifier si le message existe
    const message = await prisma.clanMessage.findUnique({
      where: { id: messageId },
      select: {
        id: true,
        senderId: true,
        messageType: true,
        clanId: true
      }
    });

    if (!message) {
      return NextResponse.json(
        { error: 'Message non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier si l'utilisateur est l'auteur ou un leader du clan
    let canDelete = message.senderId === session.user.id;

    if (!canDelete) {
      const membership = await prisma.clanMember.findFirst({
        where: {
          clanId,
          userId: session.user.id,
          role: { in: ['CAPTAIN', 'CO_LEADER'] }
        }
      });
      canDelete = !!membership;
    }

    if (!canDelete) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour supprimer ce message' },
        { status: 403 }
      );
    }

    // Les messages système ne peuvent pas être supprimés par les utilisateurs normaux
    if (message.messageType === 'SYSTEM' && message.senderId !== session.user.id) {
      const membership = await prisma.clanMember.findFirst({
        where: {
          clanId,
          userId: session.user.id,
          role: 'CAPTAIN'
        }
      });

      if (!membership) {
        return NextResponse.json(
          { error: 'Seul le capitaine peut supprimer les messages système' },
          { status: 403 }
        );
      }
    }

    // Supprimer le message
    await prisma.clanMessage.delete({
      where: { id: messageId }
    });

    return NextResponse.json({ message: 'Message supprimé avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression du message:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la suppression du message' },
      { status: 500 }
    );
  }
}
