
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;

    // Vérifier si l'utilisateur n'est pas déjà dans un clan
    const existingUser = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { clanId: true }
    });

    if (existingUser?.clanId) {
      return NextResponse.json(
        { error: 'Vous êtes déjà membre d\'un clan' },
        { status: 400 }
      );
    }

    // Vérifier si le clan existe et est public
    const clan = await prisma.clan.findUnique({
      where: { id: clanId },
      select: { 
        id: true, 
        name: true, 
        clanType: true, 
        maxMembers: true, 
        _count: { select: { members: true } } 
      }
    });

    if (!clan) {
      return NextResponse.json(
        { error: 'Clan non trouvé' },
        { status: 404 }
      );
    }

    if (clan.clanType === 'PRIVATE') {
      return NextResponse.json(
        { error: 'Ce clan est privé. Vous devez être invité pour le rejoindre' },
        { status: 403 }
      );
    }

    // Vérifier la limite de membres
    if (clan._count.members >= clan.maxMembers) {
      return NextResponse.json(
        { error: 'Le clan a atteint sa limite de membres' },
        { status: 400 }
      );
    }

    // Ajouter l'utilisateur au clan
    const newMember = await prisma.$transaction(async (prisma) => {
      await prisma.user.update({
        where: { id: session.user.id },
        data: {
          clanId,
          clanRole: 'MEMBER'
        }
      });

      const member = await prisma.clanMember.create({
        data: {
          clanId,
          userId: session.user.id,
          role: 'MEMBER'
        },
        include: {
          user: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
              country: true,
            }
          },
          clan: {
            select: {
              id: true,
              name: true,
              tag: true,
              logo: true,
              platform: true,
            }
          }
        }
      });

      // Ajouter un message système
      await prisma.clanMessage.create({
        data: {
          clanId,
          senderId: session.user.id,
          content: `${member.user.username} a rejoint le clan`,
          messageType: 'SYSTEM'
        }
      });

      return member;
    });

    return NextResponse.json(newMember);
  } catch (error) {
    console.error('Erreur lors de l\'adhésion au clan:', error);
    return NextResponse.json(
      { error: 'Erreur lors de l\'adhésion au clan' },
      { status: 500 }
    );
  }
}
