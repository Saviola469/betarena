
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const clanId = params.id;

    const clan = await prisma.clan.findUnique({
      where: { id: clanId },
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        members: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
            clanRole: true,
          }
        },
        memberships: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
                country: true,
              }
            }
          },
          orderBy: [
            { role: 'asc' },
            { joinedAt: 'asc' }
          ]
        },
        messages: {
          include: {
            sender: {
              select: {
                id: true,
                username: true,
                avatar: true,
                clanRole: true,
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          take: 50
        },
        matchesA: {
          include: {
            clanA: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
                platform: true,
              }
            },
            clanB: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
                platform: true,
              }
            },
            winner: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
              }
            },
            playerA: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            playerB: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          take: 10
        },
        matchesB: {
          include: {
            clanA: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
                platform: true,
              }
            },
            clanB: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
                platform: true,
              }
            },
            winner: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
              }
            },
            playerA: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            playerB: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          take: 10
        },
        _count: {
          select: { members: true }
        }
      }
    });

    if (!clan) {
      return NextResponse.json(
        { error: 'Clan non trouvé' },
        { status: 404 }
      );
    }

    // Calculer les statistiques
    const allMatches = [...clan.matchesA, ...clan.matchesB];
    const winRate = clan.totalMatches > 0 ? (clan.totalWins / clan.totalMatches) * 100 : 0;
    const memberCount = clan._count.members;

    // Créer l'activité récente
    const recentActivity = [
      ...clan.messages.slice(0, 5).map(msg => ({
        type: msg.messageType === 'SYSTEM' ? 'system' : 'message' as const,
        description: msg.messageType === 'SYSTEM' ? msg.content : `${msg.sender.username}: ${msg.content.substring(0, 50)}...`,
        timestamp: msg.createdAt
      })),
      ...allMatches.slice(0, 5).map(match => ({
        type: 'match' as const,
        description: `Match ${match.game} vs ${match.clanA.id === clan.id ? match.clanB.name : match.clanA.name} - ${match.status}`,
        timestamp: match.createdAt
      }))
    ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10);

    const extendedClan = {
      ...clan,
      winRate,
      memberCount,
      recentActivity,
      matches: allMatches
    };

    return NextResponse.json(extendedClan);
  } catch (error) {
    console.error('Erreur lors de la récupération du clan:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du clan' },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const { name, description, platform, clanType, maxMembers } = await request.json();

    // Vérifier si l'utilisateur est capitaine ou co-leader du clan
    const userMembership = await prisma.clanMember.findFirst({
      where: {
        clanId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    if (!userMembership) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour modifier ce clan' },
        { status: 403 }
      );
    }

    // Vérifier l'unicité du nom si modifié
    if (name) {
      const existingClan = await prisma.clan.findFirst({
        where: {
          AND: [
            { name: { equals: name, mode: 'insensitive' } },
            { id: { not: clanId } }
          ]
        }
      });

      if (existingClan) {
        return NextResponse.json(
          { error: 'Ce nom de clan existe déjà' },
          { status: 400 }
        );
      }
    }

    const updatedClan = await prisma.clan.update({
      where: { id: clanId },
      data: {
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(platform && { platform }),
        ...(clanType && { clanType }),
        ...(maxMembers && { maxMembers }),
      },
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        members: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
            clanRole: true,
          }
        },
        memberships: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
              }
            }
          }
        }
      }
    });

    return NextResponse.json(updatedClan);
  } catch (error) {
    console.error('Erreur lors de la mise à jour du clan:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la mise à jour du clan' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;

    // Vérifier si l'utilisateur est le créateur du clan
    const clan = await prisma.clan.findUnique({
      where: { id: clanId },
      select: { creatorId: true }
    });

    if (!clan) {
      return NextResponse.json(
        { error: 'Clan non trouvé' },
        { status: 404 }
      );
    }

    if (clan.creatorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Seul le créateur peut supprimer le clan' },
        { status: 403 }
      );
    }

    // Supprimer le clan (cascade supprimera les relations)
    await prisma.$transaction(async (prisma) => {
      // Retirer tous les membres du clan
      await prisma.user.updateMany({
        where: { clanId },
        data: { clanId: null, clanRole: null }
      });

      // Supprimer le clan
      await prisma.clan.delete({
        where: { id: clanId }
      });
    });

    return NextResponse.json({ message: 'Clan supprimé avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression du clan:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la suppression du clan' },
      { status: 500 }
    );
  }
}
