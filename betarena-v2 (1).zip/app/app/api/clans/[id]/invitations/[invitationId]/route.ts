
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function PUT(request: Request, { params }: { params: { id: string; invitationId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const invitationId = params.invitationId;
    const { action } = await request.json(); // 'accept' ou 'decline'

    if (!['accept', 'decline'].includes(action)) {
      return NextResponse.json(
        { error: 'Action invalide' },
        { status: 400 }
      );
    }

    // Récupérer l'invitation
    const invitation = await prisma.clanInvitation.findUnique({
      where: { id: invitationId },
      include: {
        clan: {
          select: {
            id: true,
            name: true,
            maxMembers: true,
            _count: { select: { members: true } }
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            clanId: true
          }
        }
      }
    });

    if (!invitation) {
      return NextResponse.json(
        { error: 'Invitation non trouvée' },
        { status: 404 }
      );
    }

    // Vérifier que l'utilisateur est le destinataire
    if (invitation.receiverId !== session.user.id) {
      return NextResponse.json(
        { error: 'Vous n\'êtes pas autorisé à modifier cette invitation' },
        { status: 403 }
      );
    }

    // Vérifier si l'invitation est toujours en attente
    if (invitation.status !== 'PENDING') {
      return NextResponse.json(
        { error: 'Cette invitation n\'est plus valide' },
        { status: 400 }
      );
    }

    // Vérifier si l'invitation n'est pas expirée
    if (invitation.expiresAt && invitation.expiresAt < new Date()) {
      await prisma.clanInvitation.update({
        where: { id: invitationId },
        data: { status: 'EXPIRED' }
      });

      return NextResponse.json(
        { error: 'Cette invitation a expiré' },
        { status: 400 }
      );
    }

    if (action === 'accept') {
      // Vérifier si l'utilisateur n'est pas déjà dans un clan
      if (invitation.receiver.clanId) {
        return NextResponse.json(
          { error: 'Vous êtes déjà membre d\'un clan' },
          { status: 400 }
        );
      }

      // Vérifier la limite de membres
      if (invitation.clan._count.members >= invitation.clan.maxMembers) {
        return NextResponse.json(
          { error: 'Le clan a atteint sa limite de membres' },
          { status: 400 }
        );
      }

      // Accepter l'invitation
      await prisma.$transaction(async (prisma) => {
        // Mettre à jour le statut de l'invitation
        await prisma.clanInvitation.update({
          where: { id: invitationId },
          data: { status: 'ACCEPTED' }
        });

        // Ajouter l'utilisateur au clan
        await prisma.user.update({
          where: { id: session.user.id },
          data: {
            clanId: invitation.clanId,
            clanRole: 'MEMBER'
          }
        });

        await prisma.clanMember.create({
          data: {
            clanId: invitation.clanId,
            userId: session.user.id,
            role: 'MEMBER'
          }
        });

        // Ajouter un message système
        await prisma.clanMessage.create({
          data: {
            clanId: invitation.clanId,
            senderId: session.user.id,
            content: `${invitation.receiver.username} a rejoint le clan`,
            messageType: 'SYSTEM'
          }
        });
      });

      return NextResponse.json({ message: 'Invitation acceptée avec succès' });
    } else {
      // Refuser l'invitation
      await prisma.clanInvitation.update({
        where: { id: invitationId },
        data: { status: 'DECLINED' }
      });

      return NextResponse.json({ message: 'Invitation refusée' });
    }
  } catch (error) {
    console.error('Erreur lors de la réponse à l\'invitation:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la réponse à l\'invitation' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string; invitationId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const invitationId = params.invitationId;

    // Récupérer l'invitation
    const invitation = await prisma.clanInvitation.findUnique({
      where: { id: invitationId },
      select: {
        id: true,
        senderId: true,
        receiverId: true,
        clanId: true,
        status: true
      }
    });

    if (!invitation) {
      return NextResponse.json(
        { error: 'Invitation non trouvée' },
        { status: 404 }
      );
    }

    // Vérifier que l'utilisateur est l'expéditeur ou le destinataire
    if (invitation.senderId !== session.user.id && invitation.receiverId !== session.user.id) {
      // Vérifier si l'utilisateur est un leader du clan
      const membership = await prisma.clanMember.findFirst({
        where: {
          clanId: invitation.clanId,
          userId: session.user.id,
          role: { in: ['CAPTAIN', 'CO_LEADER'] }
        }
      });

      if (!membership) {
        return NextResponse.json(
          { error: 'Vous n\'êtes pas autorisé à supprimer cette invitation' },
          { status: 403 }
        );
      }
    }

    // Supprimer l'invitation
    await prisma.clanInvitation.delete({
      where: { id: invitationId }
    });

    return NextResponse.json({ message: 'Invitation supprimée avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression de l\'invitation:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la suppression de l\'invitation' },
      { status: 500 }
    );
  }
}
