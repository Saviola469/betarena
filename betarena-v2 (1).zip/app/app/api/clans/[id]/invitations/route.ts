
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');

    // Vérifier si l'utilisateur est membre du clan
    const membership = await prisma.clanMember.findUnique({
      where: {
        clanId_userId: {
          clanId,
          userId: session.user.id
        }
      }
    });

    if (!membership) {
      return NextResponse.json(
        { error: 'Vous n\'êtes pas membre de ce clan' },
        { status: 403 }
      );
    }

    const where: any = { clanId };
    if (status) {
      where.status = status;
    }

    const invitations = await prisma.clanInvitation.findMany({
      where,
      include: {
        clan: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
            clanType: true,
            _count: { select: { members: true } }
          }
        },
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            clanRole: true,
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const invitationsWithMemberCount = invitations.map(inv => ({
      ...inv,
      clan: {
        ...inv.clan,
        memberCount: inv.clan._count.members
      }
    }));

    return NextResponse.json(invitationsWithMemberCount);
  } catch (error) {
    console.error('Erreur lors de la récupération des invitations:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des invitations' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const { receiverId, message } = await request.json();

    if (!receiverId) {
      return NextResponse.json(
        { error: 'ID du destinataire requis' },
        { status: 400 }
      );
    }

    // Vérifier si l'utilisateur a les permissions pour inviter
    const membership = await prisma.clanMember.findFirst({
      where: {
        clanId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    if (!membership) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour inviter des membres' },
        { status: 403 }
      );
    }

    // Vérifier si le destinataire existe et n'est pas déjà dans un clan
    const receiver = await prisma.user.findUnique({
      where: { id: receiverId },
      select: { id: true, username: true, clanId: true }
    });

    if (!receiver) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      );
    }

    if (receiver.clanId) {
      return NextResponse.json(
        { error: 'Cet utilisateur est déjà membre d\'un clan' },
        { status: 400 }
      );
    }

    // Vérifier s'il y a déjà une invitation en attente
    const existingInvitation = await prisma.clanInvitation.findFirst({
      where: {
        clanId,
        receiverId,
        status: 'PENDING'
      }
    });

    if (existingInvitation) {
      return NextResponse.json(
        { error: 'Une invitation est déjà en attente pour cet utilisateur' },
        { status: 400 }
      );
    }

    // Créer l'invitation
    const invitation = await prisma.clanInvitation.create({
      data: {
        clanId,
        senderId: session.user.id,
        receiverId,
        message,
        status: 'PENDING',
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 jours
      },
      include: {
        clan: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
            clanType: true,
            _count: { select: { members: true } }
          }
        },
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            clanRole: true,
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    });

    return NextResponse.json({
      ...invitation,
      clan: {
        ...invitation.clan,
        memberCount: invitation.clan._count.members
      }
    });
  } catch (error) {
    console.error('Erreur lors de la création de l\'invitation:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création de l\'invitation' },
      { status: 500 }
    );
  }
}
