
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const clanId = params.id;

    const members = await prisma.clanMember.findMany({
      where: { clanId },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
            country: true,
          }
        }
      },
      orderBy: [
        { role: 'asc' },
        { joinedAt: 'asc' }
      ]
    });

    const membersWithStats = members.map(member => ({
      ...member,
      winRate: member.totalMatches > 0 ? (member.wins / member.totalMatches) * 100 : 0,
      gamesPlayed: member.totalMatches,
    }));

    return NextResponse.json(membersWithStats);
  } catch (error) {
    console.error('Erreur lors de la récupération des membres:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des membres' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const { userId, role } = await request.json();

    // Vérifier si l'utilisateur a les permissions pour ajouter des membres
    const userMembership = await prisma.clanMember.findFirst({
      where: {
        clanId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    if (!userMembership) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour ajouter des membres' },
        { status: 403 }
      );
    }

    // Vérifier si l'utilisateur à ajouter n'est pas déjà dans un clan
    const targetUser = await prisma.user.findUnique({
      where: { id: userId },
      select: { clanId: true }
    });

    if (!targetUser) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      );
    }

    if (targetUser.clanId) {
      return NextResponse.json(
        { error: 'Cet utilisateur est déjà membre d\'un clan' },
        { status: 400 }
      );
    }

    // Vérifier la limite de membres
    const clan = await prisma.clan.findUnique({
      where: { id: clanId },
      select: { maxMembers: true, _count: { select: { members: true } } }
    });

    if (clan && clan._count.members >= clan.maxMembers) {
      return NextResponse.json(
        { error: 'Le clan a atteint sa limite de membres' },
        { status: 400 }
      );
    }

    // Ajouter le membre
    const newMember = await prisma.$transaction(async (prisma) => {
      await prisma.user.update({
        where: { id: userId },
        data: {
          clanId,
          clanRole: role || 'MEMBER'
        }
      });

      const member = await prisma.clanMember.create({
        data: {
          clanId,
          userId,
          role: role || 'MEMBER'
        },
        include: {
          user: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
              country: true,
            }
          }
        }
      });

      // Ajouter un message système
      await prisma.clanMessage.create({
        data: {
          clanId,
          senderId: session.user.id,
          content: `${member.user.username} a rejoint le clan`,
          messageType: 'SYSTEM'
        }
      });

      return member;
    });

    return NextResponse.json(newMember);
  } catch (error) {
    console.error('Erreur lors de l\'ajout du membre:', error);
    return NextResponse.json(
      { error: 'Erreur lors de l\'ajout du membre' },
      { status: 500 }
    );
  }
}
