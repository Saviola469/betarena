
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function PUT(request: Request, { params }: { params: { id: string; userId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const userId = params.userId;
    const { role } = await request.json();

    // Vérifier si l'utilisateur a les permissions pour modifier les rôles
    const userMembership = await prisma.clanMember.findFirst({
      where: {
        clanId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    if (!userMembership) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour modifier les rôles' },
        { status: 403 }
      );
    }

    // Seul le CAPTAIN peut nommer d'autres CAPTAIN ou CO_LEADER
    if (role === 'CAPTAIN' && userMembership.role !== 'CAPTAIN') {
      return NextResponse.json(
        { error: 'Seul le capitaine peut nommer d\'autres capitaines' },
        { status: 403 }
      );
    }

    // Mettre à jour le rôle du membre
    const updatedMember = await prisma.$transaction(async (prisma) => {
      await prisma.user.update({
        where: { id: userId },
        data: { clanRole: role }
      });

      const member = await prisma.clanMember.update({
        where: {
          clanId_userId: {
            clanId,
            userId
          }
        },
        data: { role },
        include: {
          user: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
              country: true,
            }
          }
        }
      });

      // Ajouter un message système
      await prisma.clanMessage.create({
        data: {
          clanId,
          senderId: session.user.id,
          content: `${member.user.username} a été promu ${role}`,
          messageType: 'SYSTEM'
        }
      });

      return member;
    });

    return NextResponse.json(updatedMember);
  } catch (error) {
    console.error('Erreur lors de la mise à jour du rôle:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la mise à jour du rôle' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string; userId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;
    const userId = params.userId;

    // Vérifier si l'utilisateur a les permissions pour expulser des membres
    const userMembership = await prisma.clanMember.findFirst({
      where: {
        clanId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    // Ou si l'utilisateur veut quitter le clan lui-même
    const isSelfLeaving = userId === session.user.id;

    if (!userMembership && !isSelfLeaving) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour expulser des membres' },
        { status: 403 }
      );
    }

    // Le créateur ne peut pas être expulsé
    const clan = await prisma.clan.findUnique({
      where: { id: clanId },
      select: { creatorId: true }
    });

    if (clan?.creatorId === userId && !isSelfLeaving) {
      return NextResponse.json(
        { error: 'Le créateur du clan ne peut pas être expulsé' },
        { status: 403 }
      );
    }

    // Obtenir les infos du membre avant suppression
    const memberToRemove = await prisma.clanMember.findUnique({
      where: {
        clanId_userId: {
          clanId,
          userId
        }
      },
      include: {
        user: {
          select: {
            username: true
          }
        }
      }
    });

    if (!memberToRemove) {
      return NextResponse.json(
        { error: 'Membre non trouvé' },
        { status: 404 }
      );
    }

    // Supprimer le membre
    await prisma.$transaction(async (prisma) => {
      await prisma.user.update({
        where: { id: userId },
        data: { clanId: null, clanRole: null }
      });

      await prisma.clanMember.delete({
        where: {
          clanId_userId: {
            clanId,
            userId
          }
        }
      });

      // Ajouter un message système
      const action = isSelfLeaving ? 'a quitté' : 'a été expulsé du';
      await prisma.clanMessage.create({
        data: {
          clanId,
          senderId: session.user.id,
          content: `${memberToRemove.user.username} ${action} clan`,
          messageType: 'SYSTEM'
        }
      });
    });

    return NextResponse.json({ message: 'Membre supprimé avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression du membre:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la suppression du membre' },
      { status: 500 }
    );
  }
}
