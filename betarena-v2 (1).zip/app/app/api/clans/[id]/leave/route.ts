
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const clanId = params.id;

    // Vérifier si l'utilisateur est membre du clan
    const membership = await prisma.clanMember.findUnique({
      where: {
        clanId_userId: {
          clanId,
          userId: session.user.id
        }
      },
      include: {
        user: {
          select: {
            username: true
          }
        }
      }
    });

    if (!membership) {
      return NextResponse.json(
        { error: 'Vous n\'êtes pas membre de ce clan' },
        { status: 400 }
      );
    }

    // Vérifier si l'utilisateur est le créateur du clan
    const clan = await prisma.clan.findUnique({
      where: { id: clanId },
      select: { creatorId: true, _count: { select: { members: true } } }
    });

    if (clan?.creatorId === session.user.id) {
      // Si c'est le créateur et qu'il y a d'autres membres, transférer le leadership
      if (clan?._count?.members && clan._count.members > 1) {
        return NextResponse.json(
          { error: 'Vous devez transférer le leadership avant de quitter le clan' },
          { status: 400 }
        );
      }
      // Si c'est le seul membre, supprimer le clan
      await prisma.clan.delete({
        where: { id: clanId }
      });
    } else {
      // Supprimer le membre
      await prisma.$transaction(async (prisma) => {
        await prisma.user.update({
          where: { id: session.user.id },
          data: { clanId: null, clanRole: null }
        });

        await prisma.clanMember.delete({
          where: {
            clanId_userId: {
              clanId,
              userId: session.user.id
            }
          }
        });

        // Ajouter un message système
        await prisma.clanMessage.create({
          data: {
            clanId,
            senderId: session.user.id,
            content: `${membership.user.username} a quitté le clan`,
            messageType: 'SYSTEM'
          }
        });
      });
    }

    return NextResponse.json({ message: 'Vous avez quitté le clan avec succès' });
  } catch (error) {
    console.error('Erreur lors de la sortie du clan:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la sortie du clan' },
      { status: 500 }
    );
  }
}
