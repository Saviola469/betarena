
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request, { params }: { params: { matchId: string } }) {
  try {
    const matchId = params.matchId;

    const match = await prisma.clanMatch.findUnique({
      where: { id: matchId },
      include: {
        clanA: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
          }
        },
        clanB: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
            platform: true,
          }
        },
        winner: {
          select: {
            id: true,
            name: true,
            tag: true,
            logo: true,
          }
        },
        playerA: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        },
        playerB: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    });

    if (!match) {
      return NextResponse.json(
        { error: 'Match non trouvé' },
        { status: 404 }
      );
    }

    return NextResponse.json(match);
  } catch (error) {
    console.error('Erreur lors de la récupération du match:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du match' },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request, { params }: { params: { matchId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const matchId = params.matchId;
    const { action, scoreA, scoreB, screenshotUrl, playerBId } = await request.json();

    const match = await prisma.clanMatch.findUnique({
      where: { id: matchId },
      include: {
        clanA: { select: { id: true, name: true } },
        clanB: { select: { id: true, name: true } }
      }
    });

    if (!match) {
      return NextResponse.json(
        { error: 'Match non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier si l'utilisateur a les permissions pour modifier ce match
    const userClanA = await prisma.clanMember.findFirst({
      where: {
        clanId: match.clanAId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    const userClanB = await prisma.clanMember.findFirst({
      where: {
        clanId: match.clanBId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    if (!userClanA && !userClanB) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour modifier ce match' },
        { status: 403 }
      );
    }

    let updatedMatch;

    if (action === 'accept') {
      // Accepter le match (clan B)
      if (!userClanB) {
        return NextResponse.json(
          { error: 'Seul le clan défié peut accepter le match' },
          { status: 403 }
        );
      }

      updatedMatch = await prisma.clanMatch.update({
        where: { id: matchId },
        data: {
          status: 'ACCEPTED',
          playerBId: playerBId || session.user.id,
        },
        include: {
          clanA: {
            select: {
              id: true,
              name: true,
              tag: true,
              logo: true,
              platform: true,
            }
          },
          clanB: {
            select: {
              id: true,
              name: true,
              tag: true,
              logo: true,
              platform: true,
            }
          }
        }
      });

      // Ajouter des messages système dans les deux clans
      await Promise.all([
        prisma.clanMessage.create({
          data: {
            clanId: match.clanAId,
            senderId: session.user.id,
            content: `Match contre ${match.clanB.name} accepté`,
            messageType: 'SYSTEM'
          }
        }),
        prisma.clanMessage.create({
          data: {
            clanId: match.clanBId,
            senderId: session.user.id,
            content: `Match contre ${match.clanA.name} accepté`,
            messageType: 'SYSTEM'
          }
        })
      ]);

    } else if (action === 'decline') {
      // Refuser le match (clan B)
      if (!userClanB) {
        return NextResponse.json(
          { error: 'Seul le clan défié peut refuser le match' },
          { status: 403 }
        );
      }

      updatedMatch = await prisma.clanMatch.update({
        where: { id: matchId },
        data: { status: 'CANCELLED' },
        include: {
          clanA: {
            select: {
              id: true,
              name: true,
              tag: true,
              logo: true,
              platform: true,
            }
          },
          clanB: {
            select: {
              id: true,
              name: true,
              tag: true,
              logo: true,
              platform: true,
            }
          }
        }
      });

    } else if (action === 'start') {
      // Commencer le match
      if (match.status !== 'ACCEPTED') {
        return NextResponse.json(
          { error: 'Le match doit être accepté avant de pouvoir commencer' },
          { status: 400 }
        );
      }

      updatedMatch = await prisma.clanMatch.update({
        where: { id: matchId },
        data: {
          status: 'ACTIVE',
          startedAt: new Date(),
        },
        include: {
          clanA: {
            select: {
              id: true,
              name: true,
              tag: true,
              logo: true,
              platform: true,
            }
          },
          clanB: {
            select: {
              id: true,
              name: true,
              tag: true,
              logo: true,
              platform: true,
            }
          }
        }
      });

    } else if (action === 'complete') {
      // Terminer le match avec résultats
      if (match.status !== 'ACTIVE') {
        return NextResponse.json(
          { error: 'Le match doit être en cours pour être terminé' },
          { status: 400 }
        );
      }

      if (scoreA === undefined || scoreB === undefined) {
        return NextResponse.json(
          { error: 'Les scores sont requis pour terminer le match' },
          { status: 400 }
        );
      }

      const winnerId = scoreA > scoreB ? match.clanAId : scoreB > scoreA ? match.clanBId : null;

      updatedMatch = await prisma.$transaction(async (prisma) => {
        // Mettre à jour le match
        const match = await prisma.clanMatch.update({
          where: { id: matchId },
          data: {
            status: 'COMPLETED',
            scoreA: parseInt(scoreA),
            scoreB: parseInt(scoreB),
            winnerId,
            screenshotUrl,
            completedAt: new Date(),
          },
          include: {
            clanA: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
                platform: true,
              }
            },
            clanB: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
                platform: true,
              }
            },
            winner: {
              select: {
                id: true,
                name: true,
                tag: true,
                logo: true,
              }
            }
          }
        });

        // Mettre à jour les statistiques des clans
        if (winnerId) {
          await prisma.clan.update({
            where: { id: winnerId },
            data: {
              totalWins: { increment: 1 },
              totalMatches: { increment: 1 },
              totalEarnings: { increment: match.amount }
            }
          });

          const loserId = winnerId === match.clanAId ? match.clanBId : match.clanAId;
          await prisma.clan.update({
            where: { id: loserId },
            data: {
              totalLosses: { increment: 1 },
              totalMatches: { increment: 1 }
            }
          });
        } else {
          // Match nul
          await Promise.all([
            prisma.clan.update({
              where: { id: match.clanAId },
              data: { totalMatches: { increment: 1 } }
            }),
            prisma.clan.update({
              where: { id: match.clanBId },
              data: { totalMatches: { increment: 1 } }
            })
          ]);
        }

        return match;
      });

      // Ajouter des messages système avec résultats
      const resultMessage = winnerId 
        ? `Match terminé ! ${winnerId === match.clanAId ? match.clanA.name : match.clanB.name} a gagné ${scoreA}-${scoreB}`
        : `Match terminé ! Match nul ${scoreA}-${scoreB}`;

      await Promise.all([
        prisma.clanMessage.create({
          data: {
            clanId: match.clanAId,
            senderId: session.user.id,
            content: resultMessage,
            messageType: 'MATCH_RESULT'
          }
        }),
        prisma.clanMessage.create({
          data: {
            clanId: match.clanBId,
            senderId: session.user.id,
            content: resultMessage,
            messageType: 'MATCH_RESULT'
          }
        })
      ]);

    } else {
      return NextResponse.json(
        { error: 'Action invalide' },
        { status: 400 }
      );
    }

    return NextResponse.json(updatedMatch);
  } catch (error) {
    console.error('Erreur lors de la mise à jour du match:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la mise à jour du match' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request, { params }: { params: { matchId: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const matchId = params.matchId;

    const match = await prisma.clanMatch.findUnique({
      where: { id: matchId },
      select: {
        id: true,
        clanAId: true,
        clanBId: true,
        status: true,
        playerAId: true,
        playerBId: true
      }
    });

    if (!match) {
      return NextResponse.json(
        { error: 'Match non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier si l'utilisateur a les permissions pour supprimer ce match
    const userClanA = await prisma.clanMember.findFirst({
      where: {
        clanId: match.clanAId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    const userClanB = await prisma.clanMember.findFirst({
      where: {
        clanId: match.clanBId,
        userId: session.user.id,
        role: { in: ['CAPTAIN', 'CO_LEADER'] }
      }
    });

    if (!userClanA && !userClanB) {
      return NextResponse.json(
        { error: 'Vous n\'avez pas les permissions pour supprimer ce match' },
        { status: 403 }
      );
    }

    // Seuls les matchs PENDING ou CANCELLED peuvent être supprimés
    if (!['PENDING', 'CANCELLED'].includes(match.status)) {
      return NextResponse.json(
        { error: 'Seuls les matchs en attente ou annulés peuvent être supprimés' },
        { status: 400 }
      );
    }

    // Supprimer le match
    await prisma.clanMatch.delete({
      where: { id: matchId }
    });

    return NextResponse.json({ message: 'Match supprimé avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression du match:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la suppression du match' },
      { status: 500 }
    );
  }
}
