
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: {
        walletTotal: true,
        walletEscrow: true,
      }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      );
    }

    const transactions = await prisma.transaction.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    return NextResponse.json({
      wallet: {
        total: user.walletTotal,
        escrow: user.walletEscrow,
        available: user.walletTotal - user.walletEscrow,
      },
      transactions,
    });
  } catch (error) {
    console.error('Erreur lors de la récupération du portefeuille:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du portefeuille' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { type, amount } = await request.json();

    if (!type || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Données invalides' },
        { status: 400 }
      );
    }

    if (type === 'deposit') {
      // Simuler un dépôt Stripe réussi
      const result = await prisma.$transaction(async (prisma) => {
        // Créer la transaction
        const transaction = await prisma.transaction.create({
          data: {
            userId: session.user.id,
            type: 'DEPOSIT',
            amount,
            status: 'COMPLETED',
          }
        });

        // Mettre à jour le solde
        await prisma.user.update({
          where: { id: session.user.id },
          data: {
            walletTotal: {
              increment: amount
            }
          }
        });

        return transaction;
      });

      return NextResponse.json(result);
    }

    if (type === 'withdrawal') {
      // Vérifier le solde disponible
      const user = await prisma.user.findUnique({
        where: { id: session.user.id }
      });

      if (!user) {
        return NextResponse.json(
          { error: 'Utilisateur non trouvé' },
          { status: 404 }
        );
      }

      const availableBalance = user.walletTotal - user.walletEscrow;
      if (availableBalance < amount) {
        return NextResponse.json(
          { error: 'Solde insuffisant' },
          { status: 400 }
        );
      }

      // Créer la demande de retrait
      const result = await prisma.$transaction(async (prisma) => {
        // Créer la transaction
        const transaction = await prisma.transaction.create({
          data: {
            userId: session.user.id,
            type: 'WITHDRAWAL',
            amount,
            status: 'PENDING',
          }
        });

        // Déduire le montant du solde
        await prisma.user.update({
          where: { id: session.user.id },
          data: {
            walletTotal: {
              decrement: amount
            }
          }
        });

        return transaction;
      });

      return NextResponse.json(result);
    }

    return NextResponse.json(
      { error: 'Type de transaction non valide' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Erreur lors de la transaction:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la transaction' },
      { status: 500 }
    );
  }
}
