
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

// Récupérer un défi spécifique
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Non authentifié' },
        { status: 401 }
      );
    }

    const challengeId = params.id;

    const challenge = await prisma.challenge.findUnique({
      where: { id: challengeId },
      select: {
        id: true,
        game: true,
        platform: true,
        amount: true,
        rules: true,
        message: true,
        status: true,
        expiresAt: true,
        createdAt: true,
        updatedAt: true,
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            country: true
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            avatar: true,
            country: true
          }
        }
      }
    });

    if (!challenge) {
      return NextResponse.json(
        { error: 'Défi non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier les permissions d'accès
    const hasAccess = challenge.sender.id === session.user.id || 
                     challenge.receiver.id === session.user.id;
    
    if (!hasAccess) {
      return NextResponse.json(
        { error: 'Accès non autorisé' },
        { status: 403 }
      );
    }

    return NextResponse.json(challenge);
  } catch (error) {
    console.error('Erreur lors de la récupération du défi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du défi' },
      { status: 500 }
    );
  }
}

// Mettre à jour un défi (accepter/refuser)
export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Non authentifié' },
        { status: 401 }
      );
    }

    const challengeId = params.id;
    const { action } = await request.json(); // 'accept' | 'decline'

    if (!action || !['accept', 'decline'].includes(action)) {
      return NextResponse.json(
        { error: 'Action invalide' },
        { status: 400 }
      );
    }

    // Récupérer le défi
    const challenge = await prisma.challenge.findUnique({
      where: { id: challengeId },
      select: {
        id: true,
        senderId: true,
        receiverId: true,
        status: true,
        amount: true,
        expiresAt: true,
        game: true,
        platform: true
      }
    });

    if (!challenge) {
      return NextResponse.json(
        { error: 'Défi non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier que l'utilisateur est le destinataire
    if (challenge.receiverId !== session.user.id) {
      return NextResponse.json(
        { error: 'Seul le destinataire peut répondre au défi' },
        { status: 403 }
      );
    }

    // Vérifier que le défi est toujours en attente
    if (challenge.status !== 'PENDING') {
      return NextResponse.json(
        { error: 'Le défi n\'est plus en attente' },
        { status: 400 }
      );
    }

    // Vérifier l'expiration
    if (challenge.expiresAt && challenge.expiresAt < new Date()) {
      await prisma.challenge.update({
        where: { id: challengeId },
        data: { status: 'EXPIRED' }
      });
      
      return NextResponse.json(
        { error: 'Le défi a expiré' },
        { status: 400 }
      );
    }

    let updatedChallenge;

    if (action === 'accept') {
      // Vérifier les fonds des deux utilisateurs
      const [sender, receiver] = await Promise.all([
        prisma.user.findUnique({
          where: { id: challenge.senderId },
          select: { walletTotal: true, walletEscrow: true }
        }),
        prisma.user.findUnique({
          where: { id: challenge.receiverId },
          select: { walletTotal: true, walletEscrow: true }
        })
      ]);

      if (!sender || !receiver) {
        return NextResponse.json(
          { error: 'Utilisateur non trouvé' },
          { status: 404 }
        );
      }

      const senderAvailable = sender.walletTotal - sender.walletEscrow;
      const receiverAvailable = receiver.walletTotal - receiver.walletEscrow;

      if (senderAvailable < challenge.amount || receiverAvailable < challenge.amount) {
        return NextResponse.json(
          { error: 'Fonds insuffisants' },
          { status: 400 }
        );
      }

      // Créer un pari basé sur le défi accepté
      await prisma.$transaction(async (tx) => {
        // Créer le pari
        const bet = await tx.bet.create({
          data: {
            game: challenge.game,
            platform: challenge.platform,
            amount: challenge.amount,
            rules: `Défi accepté - ${challenge.game} sur ${challenge.platform}`,
            status: 'ACTIVE',
            creatorId: challenge.senderId,
            opponentId: challenge.receiverId
          }
        });

        // Mettre à jour les escrows
        await tx.user.update({
          where: { id: challenge.senderId },
          data: { walletEscrow: { increment: challenge.amount } }
        });

        await tx.user.update({
          where: { id: challenge.receiverId },
          data: { walletEscrow: { increment: challenge.amount } }
        });

        // Mettre à jour le défi
        await tx.challenge.update({
          where: { id: challengeId },
          data: { status: 'ACCEPTED' }
        });
      });

      updatedChallenge = await prisma.challenge.findUnique({
        where: { id: challengeId },
        select: {
          id: true,
          game: true,
          platform: true,
          amount: true,
          rules: true,
          message: true,
          status: true,
          expiresAt: true,
          createdAt: true,
          updatedAt: true,
          sender: {
            select: {
              id: true,
              username: true,
              avatar: true,
              country: true
            }
          },
          receiver: {
            select: {
              id: true,
              username: true,
              avatar: true,
              country: true
            }
          }
        }
      });
    } else {
      // Refuser le défi
      updatedChallenge = await prisma.challenge.update({
        where: { id: challengeId },
        data: { status: 'DECLINED' },
        select: {
          id: true,
          game: true,
          platform: true,
          amount: true,
          rules: true,
          message: true,
          status: true,
          expiresAt: true,
          createdAt: true,
          updatedAt: true,
          sender: {
            select: {
              id: true,
              username: true,
              avatar: true,
              country: true
            }
          },
          receiver: {
            select: {
              id: true,
              username: true,
              avatar: true,
              country: true
            }
          }
        }
      });
    }

    return NextResponse.json(updatedChallenge);
  } catch (error) {
    console.error('Erreur lors de la mise à jour du défi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la mise à jour du défi' },
      { status: 500 }
    );
  }
}

// Supprimer un défi
export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Non authentifié' },
        { status: 401 }
      );
    }

    const challengeId = params.id;

    // Récupérer le défi
    const challenge = await prisma.challenge.findUnique({
      where: { id: challengeId },
      select: {
        id: true,
        senderId: true,
        status: true
      }
    });

    if (!challenge) {
      return NextResponse.json(
        { error: 'Défi non trouvé' },
        { status: 404 }
      );
    }

    // Vérifier que l'utilisateur est l'expéditeur
    if (challenge.senderId !== session.user.id) {
      return NextResponse.json(
        { error: 'Seul l\'expéditeur peut supprimer le défi' },
        { status: 403 }
      );
    }

    // Vérifier que le défi peut être supprimé
    if (!['PENDING', 'DECLINED', 'EXPIRED'].includes(challenge.status)) {
      return NextResponse.json(
        { error: 'Le défi ne peut pas être supprimé' },
        { status: 400 }
      );
    }

    // Supprimer le défi
    await prisma.challenge.delete({
      where: { id: challengeId }
    });

    return NextResponse.json({ message: 'Défi supprimé avec succès' });
  } catch (error) {
    console.error('Erreur lors de la suppression du défi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la suppression du défi' },
      { status: 500 }
    );
  }
}
