
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

// Récupérer les défis
export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Non authentifié' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') as any;
    const game = searchParams.get('game');
    const platform = searchParams.get('platform');
    const type = searchParams.get('type'); // 'sent' | 'received' | 'all'
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const skip = (page - 1) * limit;

    // Construire les filtres
    const whereClause: any = {};
    
    if (type === 'sent') {
      whereClause.senderId = session.user.id;
    } else if (type === 'received') {
      whereClause.receiverId = session.user.id;
    } else {
      whereClause.OR = [
        { senderId: session.user.id },
        { receiverId: session.user.id }
      ];
    }

    if (status && status !== 'all') {
      whereClause.status = status;
    }

    if (game && game !== 'all') {
      whereClause.game = game;
    }

    if (platform && platform !== 'all') {
      whereClause.platform = platform;
    }

    // Récupérer les défis
    const challenges = await prisma.challenge.findMany({
      where: whereClause,
      select: {
        id: true,
        game: true,
        platform: true,
        amount: true,
        rules: true,
        message: true,
        status: true,
        expiresAt: true,
        createdAt: true,
        updatedAt: true,
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            country: true
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            avatar: true,
            country: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      skip,
      take: limit
    });

    // Compter le total pour la pagination
    const totalChallenges = await prisma.challenge.count({
      where: whereClause
    });

    return NextResponse.json({
      challenges,
      pagination: {
        page,
        limit,
        total: totalChallenges,
        totalPages: Math.ceil(totalChallenges / limit)
      }
    });
  } catch (error) {
    console.error('Erreur lors de la récupération des défis:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des défis' },
      { status: 500 }
    );
  }
}

// Créer un nouveau défi
export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Non authentifié' },
        { status: 401 }
      );
    }

    const { receiverId, game, platform, amount, rules, message } = await request.json();

    // Vérifications
    if (!receiverId || !game || !platform || !amount) {
      return NextResponse.json(
        { error: 'Champs requis manquants' },
        { status: 400 }
      );
    }

    if (receiverId === session.user.id) {
      return NextResponse.json(
        { error: 'Vous ne pouvez pas vous défier vous-même' },
        { status: 400 }
      );
    }

    // Vérifier que le destinataire existe et a un profil public
    const receiver = await prisma.user.findUnique({
      where: { id: receiverId },
      select: {
        id: true,
        username: true,
        isProfilePublic: true
      }
    });

    if (!receiver) {
      return NextResponse.json(
        { error: 'Utilisateur destinataire non trouvé' },
        { status: 404 }
      );
    }

    if (!receiver.isProfilePublic) {
      return NextResponse.json(
        { error: 'Impossible de défier un utilisateur avec un profil privé' },
        { status: 403 }
      );
    }

    // Vérifier les fonds disponibles
    const sender = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: {
        walletTotal: true,
        walletEscrow: true
      }
    });

    if (!sender) {
      return NextResponse.json(
        { error: 'Utilisateur expéditeur non trouvé' },
        { status: 404 }
      );
    }

    const availableFunds = sender.walletTotal - sender.walletEscrow;
    if (availableFunds < amount) {
      return NextResponse.json(
        { error: 'Fonds insuffisants' },
        { status: 400 }
      );
    }

    // Créer le défi
    const challenge = await prisma.challenge.create({
      data: {
        senderId: session.user.id,
        receiverId,
        game,
        platform,
        amount,
        rules: rules || '',
        message: message || '',
        status: 'PENDING',
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 heures
      },
      select: {
        id: true,
        game: true,
        platform: true,
        amount: true,
        rules: true,
        message: true,
        status: true,
        expiresAt: true,
        createdAt: true,
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
            country: true
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            avatar: true,
            country: true
          }
        }
      }
    });

    return NextResponse.json(challenge, { status: 201 });
  } catch (error) {
    console.error('Erreur lors de la création du défi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création du défi' },
      { status: 500 }
    );
  }
}
