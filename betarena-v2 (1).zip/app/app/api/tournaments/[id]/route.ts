
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const tournament = await prisma.tournament.findUnique({
      where: { id: params.id },
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        },
        participants: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
              }
            }
          },
          orderBy: {
            joinedAt: 'asc'
          }
        },
        matches: {
          include: {
            playerA: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            playerB: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            winner: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          },
          orderBy: [
            { round: 'asc' },
            { createdAt: 'asc' }
          ]
        }
      }
    });

    if (!tournament) {
      return NextResponse.json(
        { error: 'Tournoi non trouvé' },
        { status: 404 }
      );
    }

    return NextResponse.json(tournament);
  } catch (error) {
    console.error('Erreur lors de la récupération du tournoi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du tournoi' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { action, matchId, winnerId } = await request.json();

    const tournament = await prisma.tournament.findUnique({
      where: { id: params.id },
      include: {
        creator: true,
        participants: true,
        matches: true
      }
    });

    if (!tournament) {
      return NextResponse.json(
        { error: 'Tournoi non trouvé' },
        { status: 404 }
      );
    }

    // Seul le créateur peut modifier le tournoi
    if (tournament.creatorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Seul le créateur peut modifier le tournoi' },
        { status: 403 }
      );
    }

    if (action === 'start') {
      if (tournament.status !== 'OPEN') {
        return NextResponse.json(
          { error: 'Le tournoi ne peut pas être démarré' },
          { status: 400 }
        );
      }

      if (tournament.participants.length < 2) {
        return NextResponse.json(
          { error: 'Il faut au moins 2 participants pour démarrer le tournoi' },
          { status: 400 }
        );
      }

      // Générer les brackets et démarrer le tournoi
      const updatedTournament = await generateBrackets(tournament);
      return NextResponse.json(updatedTournament);
    }

    if (action === 'complete_match') {
      if (!matchId || !winnerId) {
        return NextResponse.json(
          { error: 'Match ID et Winner ID requis' },
          { status: 400 }
        );
      }

      const match = await prisma.tournamentMatch.findUnique({
        where: { id: matchId },
        include: { tournament: true }
      });

      if (!match || match.tournamentId !== params.id) {
        return NextResponse.json(
          { error: 'Match non trouvé' },
          { status: 404 }
        );
      }

      if (match.winnerId !== winnerId && match.playerAId !== winnerId && match.playerBId !== winnerId) {
        return NextResponse.json(
          { error: 'Winner ID invalide' },
          { status: 400 }
        );
      }

      // Mettre à jour le match
      const updatedMatch = await prisma.tournamentMatch.update({
        where: { id: matchId },
        data: {
          winnerId,
          status: 'COMPLETED'
        }
      });

      // Vérifier si le tournoi est terminé et générer le prochain round
      const updatedTournament = await advanceTournament(params.id);
      return NextResponse.json(updatedTournament);
    }

    return NextResponse.json(
      { error: 'Action non valide' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Erreur lors de la modification du tournoi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la modification du tournoi' },
      { status: 500 }
    );
  }
}

// Fonction pour générer les brackets
async function generateBrackets(tournament: any) {
  const participants = tournament.participants;
  
  if (tournament.tournamentType === 'SINGLE_ELIMINATION') {
    // Mélanger les participants
    const shuffled = [...participants].sort(() => Math.random() - 0.5);
    
    // Créer les matches du premier round
    const matches = [];
    for (let i = 0; i < shuffled.length; i += 2) {
      if (i + 1 < shuffled.length) {
        matches.push({
          tournamentId: tournament.id,
          round: 1,
          playerAId: shuffled[i].userId,
          playerBId: shuffled[i + 1].userId,
          status: 'PENDING' as const
        });
      }
    }

    // Créer les matches en base
    await prisma.tournamentMatch.createMany({
      data: matches
    });

    // Mettre à jour le statut du tournoi
    const updatedTournament = await prisma.tournament.update({
      where: { id: tournament.id },
      data: { status: 'ACTIVE' },
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        },
        participants: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
              }
            }
          }
        },
        matches: {
          include: {
            playerA: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            playerB: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            winner: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        }
      }
    });

    return updatedTournament;
  }

  // Pour les autres types de tournoi, on peut ajouter la logique plus tard
  return tournament;
}

// Fonction pour faire avancer le tournoi
async function advanceTournament(tournamentId: string) {
  const tournament = await prisma.tournament.findUnique({
    where: { id: tournamentId },
    include: {
      matches: {
        orderBy: [
          { round: 'desc' },
          { createdAt: 'asc' }
        ]
      }
    }
  });

  if (!tournament) return null;

  const currentRoundMatches = tournament.matches.filter(m => 
    m.round === Math.max(...tournament.matches.map(m => m.round))
  );

  // Vérifier si tous les matches du round actuel sont terminés
  const allMatchesComplete = currentRoundMatches.every(m => m.status === 'COMPLETED');

  if (allMatchesComplete) {
    const winners = currentRoundMatches.map(m => m.winnerId).filter(Boolean);
    
    if (winners.length === 1) {
      // Tournoi terminé
      await prisma.tournament.update({
        where: { id: tournamentId },
        data: { status: 'COMPLETED' }
      });
    } else if (winners.length > 1) {
      // Créer le prochain round
      const nextRound = Math.max(...tournament.matches.map(m => m.round)) + 1;
      const nextMatches = [];
      
      for (let i = 0; i < winners.length; i += 2) {
        if (i + 1 < winners.length) {
          nextMatches.push({
            tournamentId: tournamentId,
            round: nextRound,
            playerAId: winners[i],
            playerBId: winners[i + 1],
            status: 'PENDING' as const
          });
        }
      }

      await prisma.tournamentMatch.createMany({
        data: nextMatches
      });
    }
  }

  // Retourner le tournoi mis à jour
  return await prisma.tournament.findUnique({
    where: { id: tournamentId },
    include: {
      creator: {
        select: {
          id: true,
          username: true,
          avatar: true,
          rank: true,
        }
      },
      participants: {
        include: {
          user: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
            }
          }
        }
      },
      matches: {
        include: {
          playerA: {
            select: {
              id: true,
              username: true,
              avatar: true,
            }
          },
          playerB: {
            select: {
              id: true,
              username: true,
              avatar: true,
            }
          },
          winner: {
            select: {
              id: true,
              username: true,
              avatar: true,
            }
          }
        }
      }
    }
  });
}
