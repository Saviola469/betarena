
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const tournament = await prisma.tournament.findUnique({
      where: { id: params.id },
      include: {
        participants: true
      }
    });

    if (!tournament) {
      return NextResponse.json(
        { error: 'Tournoi non trouvé' },
        { status: 404 }
      );
    }

    if (tournament.status !== 'OPEN') {
      return NextResponse.json(
        { error: 'Ce tournoi n\'est plus ouvert aux inscriptions' },
        { status: 400 }
      );
    }

    if (tournament.participants.length >= tournament.maxParticipants) {
      return NextResponse.json(
        { error: 'Ce tournoi est complet' },
        { status: 400 }
      );
    }

    // Vérifier si l'utilisateur n'est pas déjà inscrit
    const alreadyParticipating = tournament.participants.some(
      p => p.userId === session.user.id
    );

    if (alreadyParticipating) {
      return NextResponse.json(
        { error: 'Vous participez déjà à ce tournoi' },
        { status: 400 }
      );
    }

    // Vérifier le solde de l'utilisateur pour le frais d'entrée
    if (tournament.entryFee > 0) {
      const user = await prisma.user.findUnique({
        where: { id: session.user.id }
      });

      if (!user) {
        return NextResponse.json(
          { error: 'Utilisateur non trouvé' },
          { status: 404 }
        );
      }

      const availableBalance = user.walletTotal - user.walletEscrow;
      if (availableBalance < tournament.entryFee) {
        return NextResponse.json(
          { error: 'Solde insuffisant pour le frais d\'entrée' },
          { status: 400 }
        );
      }
    }

    // Rejoindre le tournoi
    const updatedTournament = await prisma.$transaction(async (prisma) => {
      // Ajouter le participant
      await prisma.tournamentParticipant.create({
        data: {
          tournamentId: params.id,
          userId: session.user.id,
        }
      });

      // Mettre à jour le solde en escrow si frais d'entrée
      if (tournament.entryFee > 0) {
        await prisma.user.update({
          where: { id: session.user.id },
          data: {
            walletEscrow: {
              increment: tournament.entryFee
            }
          }
        });
      }

      // Retourner le tournoi mis à jour
      return await prisma.tournament.findUnique({
        where: { id: params.id },
        include: {
          creator: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
            }
          },
          participants: {
            include: {
              user: {
                select: {
                  id: true,
                  username: true,
                  avatar: true,
                  rank: true,
                }
              }
            }
          }
        }
      });
    });

    return NextResponse.json(updatedTournament);
  } catch (error) {
    console.error('Erreur lors de l\'inscription au tournoi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de l\'inscription au tournoi' },
      { status: 500 }
    );
  }
}
