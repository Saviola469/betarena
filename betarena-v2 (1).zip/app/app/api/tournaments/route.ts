
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const game = searchParams.get('game');
    const platform = searchParams.get('platform');
    const status = searchParams.get('status') || 'OPEN';
    const isPrivate = searchParams.get('private') === 'true';

    const where: any = { status };

    if (game && game !== 'all') {
      where.game = game;
    }

    if (platform && platform !== 'all') {
      where.platform = platform;
    }

    if (!isPrivate) {
      where.isPrivate = false;
    }

    const tournaments = await prisma.tournament.findMany({
      where,
      include: {
        creator: {
          select: {
            id: true,
            username: true,
            avatar: true,
            rank: true,
          }
        },
        participants: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
                rank: true,
              }
            }
          }
        },
        matches: {
          include: {
            playerA: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            playerB: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            },
            winner: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    return NextResponse.json(tournaments);
  } catch (error) {
    console.error('Erreur lors de la récupération des tournois:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des tournois' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Vous devez être connecté' },
        { status: 401 }
      );
    }

    const { 
      name, 
      game, 
      platform, 
      maxParticipants, 
      entryFee, 
      format, 
      tournamentType, 
      startDate, 
      isPrivate 
    } = await request.json();

    if (!name || !game || !platform || !maxParticipants || maxParticipants < 2) {
      return NextResponse.json(
        { error: 'Données invalides' },
        { status: 400 }
      );
    }

    // Vérifier le solde de l'utilisateur pour le frais d'entrée
    if (entryFee > 0) {
      const user = await prisma.user.findUnique({
        where: { id: session.user.id }
      });

      if (!user) {
        return NextResponse.json(
          { error: 'Utilisateur non trouvé' },
          { status: 404 }
        );
      }

      const availableBalance = user.walletTotal - user.walletEscrow;
      if (availableBalance < entryFee) {
        return NextResponse.json(
          { error: 'Solde insuffisant pour le frais d\'entrée' },
          { status: 400 }
        );
      }
    }

    // Créer le tournoi
    const tournament = await prisma.$transaction(async (prisma) => {
      const newTournament = await prisma.tournament.create({
        data: {
          name,
          game,
          platform,
          maxParticipants,
          entryFee: entryFee || 0,
          format: format || 'BO1',
          tournamentType: tournamentType || 'SINGLE_ELIMINATION',
          startDate: startDate ? new Date(startDate) : null,
          isPrivate: isPrivate || false,
          creatorId: session.user.id,
        },
        include: {
          creator: {
            select: {
              id: true,
              username: true,
              avatar: true,
              rank: true,
            }
          },
          participants: {
            include: {
              user: {
                select: {
                  id: true,
                  username: true,
                  avatar: true,
                  rank: true,
                }
              }
            }
          }
        }
      });

      // Ajouter automatiquement le créateur comme participant
      await prisma.tournamentParticipant.create({
        data: {
          tournamentId: newTournament.id,
          userId: session.user.id,
        }
      });

      // Mettre à jour le solde en escrow si frais d'entrée
      if (entryFee > 0) {
        await prisma.user.update({
          where: { id: session.user.id },
          data: {
            walletEscrow: {
              increment: entryFee
            }
          }
        });
      }

      return newTournament;
    });

    return NextResponse.json(tournament);
  } catch (error) {
    console.error('Erreur lors de la création du tournoi:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la création du tournoi' },
      { status: 500 }
    );
  }
}
