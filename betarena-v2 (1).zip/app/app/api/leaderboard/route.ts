
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const game = searchParams.get('game');
    const platform = searchParams.get('platform');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '100');
    const search = searchParams.get('search');

    const skip = (page - 1) * limit;

    let users;

    if (game && game !== 'all') {
      // Classement par jeu spécifique avec filtres
      const whereClause: any = {};

      if (search) {
        whereClause.username = {
          contains: search,
          mode: 'insensitive'
        };
      }

      // Obtenir les statistiques spécifiques au jeu/plateforme
      const playerStatsWhere: any = { game };
      if (platform && platform !== 'all') {
        playerStatsWhere.platform = platform;
      }

      users = await prisma.user.findMany({
        where: whereClause,
        select: {
          id: true,
          username: true,
          avatar: true,
          rank: true,
          score: true,
          wins: true,
          losses: true,
          tournamentWins: true,
          country: true,
          gamesPlayed: true,
          gamesWon: true,
          isProfilePublic: true,
          playerStats: {
            where: playerStatsWhere,
            select: {
              wins: true,
              losses: true,
              tournamentWins: true,
              score: true,
              totalEarnings: true,
              lastPlayed: true,
              game: true,
              platform: true
            }
          }
        },
        orderBy: {
          score: 'desc'
        },
        skip,
        take: limit
      });

      // Calculer les stats agrégées pour le jeu/plateforme
      users = users.map((user, index) => {
        const stats = user.playerStats.reduce((acc, stat) => ({
          wins: acc.wins + stat.wins,
          losses: acc.losses + stat.losses,
          tournamentWins: acc.tournamentWins + stat.tournamentWins,
          score: acc.score + stat.score,
          totalEarnings: acc.totalEarnings + stat.totalEarnings,
          lastPlayed: stat.lastPlayed && (!acc.lastPlayed || stat.lastPlayed > acc.lastPlayed) ? stat.lastPlayed : acc.lastPlayed
        }), {
          wins: 0,
          losses: 0,
          tournamentWins: 0,
          score: 0,
          totalEarnings: 0,
          lastPlayed: null as Date | null
        });

        const gamesPlayed = stats.wins + stats.losses;
        const winRate = gamesPlayed > 0 ? (stats.wins / gamesPlayed) * 100 : 0;

        return {
          ...user,
          globalRank: skip + index + 1,
          gameSpecificStats: {
            ...stats,
            gamesPlayed,
            winRate
          },
          gamesPlayed,
          gamesWon: stats.wins,
          totalEarnings: stats.totalEarnings,
          winRate
        };
      }).filter(user => user.gameSpecificStats.gamesPlayed > 0);
    } else {
      // Classement global
      const whereClause: any = {};

      if (search) {
        whereClause.username = {
          contains: search,
          mode: 'insensitive'
        };
      }

      users = await prisma.user.findMany({
        where: whereClause,
        select: {
          id: true,
          username: true,
          avatar: true,
          rank: true,
          score: true,
          wins: true,
          losses: true,
          tournamentWins: true,
          country: true,
          gamesPlayed: true,
          gamesWon: true,
          isProfilePublic: true,
          playerStats: {
            select: {
              wins: true,
              losses: true,
              tournamentWins: true,
              score: true,
              totalEarnings: true,
              lastPlayed: true,
              game: true,
              platform: true
            }
          }
        },
        orderBy: {
          score: 'desc'
        },
        skip,
        take: limit
      });

      users = users.map((user, index) => {
        const totalEarnings = user.playerStats.reduce((sum, stat) => sum + stat.totalEarnings, 0);
        const winRate = user.gamesPlayed > 0 ? (user.gamesWon / user.gamesPlayed) * 100 : 0;

        return {
          ...user,
          globalRank: skip + index + 1,
          totalEarnings,
          winRate
        };
      });
    }

    // Obtenir le count total pour la pagination
    const totalUsers = await prisma.user.count({
      where: search ? {
        username: {
          contains: search,
          mode: 'insensitive'
        }
      } : undefined
    });

    return NextResponse.json({
      users,
      pagination: {
        page,
        limit,
        total: totalUsers,
        totalPages: Math.ceil(totalUsers / limit)
      }
    });
  } catch (error) {
    console.error('Erreur lors de la récupération du classement:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération du classement' },
      { status: 500 }
    );
  }
}
